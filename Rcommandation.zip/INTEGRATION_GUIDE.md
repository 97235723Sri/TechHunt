# Complete Integration Guide

## End-to-End Flow

```
┌─────────────────────────────────────────────────────────────┐
│ 1. USER OPENS REACT APP                                     │
│    http://localhost:3000                                    │
└────────────────┬────────────────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────────────────┐
│ 2. REACT COMPONENT MOUNTS                                   │
│    useEffect(() => fetchRecommendations(), [portfolioId])  │
└────────────────┬────────────────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────────────────┐
│ 3. API CALL TO ML SERVICE                                   │
│    POST http://localhost:5000/api/ml/recommendations/...    │
│    Body: { portfolio, holdings, targets, market_data }     │
└────────────────┬────────────────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────────────────┐
│ 4. ML ENSEMBLE RUNS                                         │
│    ├─ CVXPY Optimizer (40%) → Optimal weights              │
│    ├─ XGBoost Predictor (30%) → Market regime              │
│    ├─ LSTM Forecaster (20%) → Return forecast              │
│    └─ Claude LLM (10%) → Strategic insights                │
└────────────────┬────────────────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────────────────┐
│ 5. GENERATE TRADE RECOMMENDATIONS                           │
│    - Convert optimal weights to buy/sell orders            │
│    - Calculate priorities (HIGH/MEDIUM/LOW)                │
│    - Estimate tax impact                                   │
│    - Combine all model insights                            │
└────────────────┬────────────────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────────────────┐
│ 6. RETURN JSON RESPONSE                                     │
│    {                                                        │
│      recommendation_id,                                     │
│      sell_orders: [...],                                   │
│      buy_orders: [...],                                    │
│      model_contributions: [...],                           │
│      ensemble_confidence: 0.87                             │
│    }                                                        │
└────────────────┬────────────────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────────────────┐
│ 7. REACT UI UPDATES                                         │
│    ├─ Portfolio Health Dashboard (gradient card)           │
│    ├─ AI Summary (alert box)                               │
│    ├─ Model Contributions (4 colored cards)                │
│    ├─ Trade Table (sell/buy tabs)                          │
│    ├─ Expected Impact (before/after)                       │
│    └─ AI Insights (from Claude)                            │
└─────────────────────────────────────────────────────────────┘
```

## Component Mapping

### ML Service (Python) → React UI

| ML Output | UI Component | Description |
|-----------|--------------|-------------|
| `ensemble_confidence` | PageHeader badge | 87% Confidence badge |
| `current_drift` + `expected_drift_reduction` | Health Dashboard | Red → Green metrics |
| `model_contributions[]` | ModelContributions | 4 colored cards |
| `sell_orders[]` | TradeRecommendations | Sell tab table |
| `buy_orders[]` | TradeRecommendations | Buy tab table |
| `expected_sharpe_change` | ExpectedImpact | Before/After Sharpe |
| `insights[]` | AIInsights | Green insight cards |
| `warnings[]` | AIInsights | Yellow warning cards |

## Data Flow Example

### Input (React → Python):
```javascript
{
  portfolio: {
    portfolio_id: "PORT-001",
    total_value: 524830,
    current_drift: 5.2
  },
  holdings: [
    {ticker: "AAPL", quantity: 125, ...}
  ]
}
```

### Processing (Python ML):
```python
# CVXPY
optimal_weights = [0.30, 0.28, 0.42]

# XGBoost
market_regime = "FAVORABLE"

# LSTM
predicted_return = 0.082

# Claude
insights = ["Tax optimization opportunity..."]
```

### Output (Python → React):
```json
{
  "sell_orders": [
    {
      "ticker": "AAPL",
      "action": "SELL",
      "recommended_quantity": 28,
      "priority": "HIGH",
      "confidence": 0.87,
      "reason": "Overweight by 1.3%"
    }
  ]
}
```

### Rendering (React UI):
```
┌────────────────────────────────────┐
│ Trade Recommendations              │
│ [Sell Orders (8)] [Buy Orders (7)] │
│                                    │
│ HIGH  AAPL  28 shares  ▓▓▓▓▓ 87%  │
│ Overweight by 1.3%. Reduce to...  │
└────────────────────────────────────┘
```

## Customization Points

### 1. Connect Real Portfolio Data

Replace `buildRequestPayload()` in React:

```javascript
const fetchPortfolioData = async (portfolioId) => {
  // Call your backend API
  const response = await fetch(`/api/portfolios/${portfolioId}`);
  const data = await response.json();
  
  return {
    portfolio: data.portfolio,
    holdings: data.holdings,
    target_allocations: data.targets,
    market_data: await fetchMarketData()
  };
};
```

### 2. Train Real ML Models

In Python service:

```python
# Replace simulated XGBoost
import xgboost as xgb

model = xgb.XGBRegressor()
model.load_model('trained_model.json')

predictions = model.predict(features)
```

### 3. Add Authentication

```python
# ML Service
from fastapi.security import HTTPBearer

security = HTTPBearer()

@app.post("/api/ml/recommendations/ensemble")
async def get_recommendations(
    request: RebalanceRequest,
    token: str = Depends(security)
):
    # Validate token
    user = validate_token(token)
    ...
```

### 4. Database Integration

```python
# Save recommendations
@app.post("/api/ml/recommendations/ensemble")
async def get_recommendations(request: RebalanceRequest):
    result = ensemble.generate_recommendations(request)
    
    # Save to database
    db.save_recommendation(result)
    
    return result
```

## Testing Flow

### 1. Test ML Service Alone

```bash
# Start service
cd ml-service
python app.py

# Test in another terminal
curl http://localhost:5000/health

curl -X POST http://localhost:5000/api/ml/recommendations/ensemble \
  -H "Content-Type: application/json" \
  -d '{
    "portfolio": {"portfolio_id": "TEST", "total_value": 100000, ...},
    "holdings": [...],
    ...
  }'
```

### 2. Test Frontend Alone

```bash
cd frontend
npm start

# Opens http://localhost:3000
# Uses sample data in buildRequestPayload()
```

### 3. Test Full Integration

```bash
# Terminal 1: ML Service
cd ml-service && python app.py

# Terminal 2: Frontend
cd frontend && npm start

# Browser: http://localhost:3000
# Should show recommendations automatically!
```

## Deployment Checklist

- [ ] ML Service deployed (AWS/GCP/Azure)
- [ ] Frontend deployed (Vercel/Netlify)
- [ ] Environment variables configured
- [ ] CORS settings updated
- [ ] Authentication enabled
- [ ] Rate limiting configured
- [ ] Monitoring/logging enabled
- [ ] HTTPS enabled
- [ ] Database connected
- [ ] Backup strategy in place

## Performance Tips

1. **Cache ML results** for same portfolio (Redis)
2. **Batch requests** if processing multiple portfolios
3. **Use async** for ML model calls
4. **CDN for frontend** assets
5. **Database indexes** on portfolio_id
6. **Load balancing** for ML service
7. **Lazy load** UI components
8. **Optimize bundle** size (code splitting)

## Troubleshooting

### ML Service not starting?
- Check Python version (3.8+)
- Install all requirements
- Check port 5000 is free

### Frontend can't connect?
- Check ML service is running
- Verify API_URL in code
- Check CORS settings
- Look at browser console

### No recommendations appearing?
- Check browser console for errors
- Verify request payload format
- Check ML service logs
- Test API directly with curl

### Low confidence scores?
- Check input data quality
- Verify market data is current
- Review model weights
- Check for data anomalies

---

**You now have a complete, working ML-powered portfolio rebalancer!** 🎉
