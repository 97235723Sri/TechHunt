# Complete Portfolio Rebalancer - ML Ensemble Integration

Complete end-to-end implementation: ML Backend + React Frontend

## 🎯 Architecture

```
┌─────────────────────────────────────────────────┐
│          React Frontend (Port 3000)             │
│  Beautiful UI showing ML recommendations        │
└────────────────┬────────────────────────────────┘
                 │ HTTP POST
                 ▼
┌─────────────────────────────────────────────────┐
│        Python ML Service (Port 5000)            │
│  Ensemble: CVXPY + XGBoost + LSTM + Claude     │
└─────────────────────────────────────────────────┘
```

## 🚀 Quick Start

### 1. Start ML Service

```bash
cd ml-service

# Install dependencies
pip install fastapi uvicorn numpy cvxpy anthropic

# Set API key (optional - works without it)
export ANTHROPIC_API_KEY=your_key_here

# Run service
python app.py
```

ML service runs on http://localhost:5000

### 2. Start React Frontend

```bash
cd frontend

# Install dependencies
npm install

# Start development server
npm start
```

Frontend runs on http://localhost:3000

### 3. View Recommendations

Open http://localhost:3000 in your browser!

## 📊 Features

### ML Ensemble (4 Models)

1. **CVXPY Optimizer (40%)** - Mathematical optimization
2. **XGBoost Predictor (30%)** - ML market regime prediction  
3. **LSTM Forecaster (20%)** - Deep learning time series
4. **Claude LLM (10%)** - AI strategic reasoning

### UI Components

✅ Portfolio Health Dashboard with 4 metrics
✅ AI Recommendation Summary
✅ Model Contributions (all 4 shown)
✅ Trade Recommendations Table
✅ Expected Impact Visualization
✅ AI Insights & Warnings
✅ Action Buttons

## 🎨 Screenshots

The UI displays:
- Gradient header with confidence badge
- 4-column health metrics
- Color-coded model cards (Blue, Red, Green, Purple)
- Interactive trade table with priorities
- Before/After impact comparison
- AI-generated insights

## 🔧 Configuration

### ML Service

Edit `ml-service/app.py`:
- Ensemble weights (default: 40/30/20/10)
- Risk parameters
- Model configurations

### Frontend

Edit `frontend/src/components/RebalanceRecommendations.jsx`:
- API URL
- Sample data
- UI components

## 📝 API Endpoints

### POST /api/ml/recommendations/ensemble

Request:
```json
{
  "portfolio": {...},
  "holdings": [...],
  "target_allocations": [...],
  "market_data": {...}
}
```

Response:
```json
{
  "recommendation_id": "uuid",
  "sell_orders": [...],
  "buy_orders": [...],
  "ensemble_confidence": 0.87,
  "model_contributions": [...]
}
```

### GET /api/ml/models/status

Returns status of all 4 models.

### GET /health

Health check.

## 🧪 Testing

### Test ML Service

```bash
curl http://localhost:5000/health

curl -X POST http://localhost:5000/api/ml/recommendations/ensemble \
  -H "Content-Type: application/json" \
  -d @sample_request.json
```

### Test Frontend

Just open http://localhost:3000 - it includes sample data!

## 📦 Project Structure

```
complete-portfolio-rebalancer/
├── ml-service/
│   └── app.py                    # Complete ML ensemble
├── frontend/
│   └── src/
│       └── components/
│           ├── RebalanceRecommendations.jsx
│           └── RebalanceRecommendations.css
└── README.md
```

## 🎓 How It Works

1. **User opens React app**
2. **Component calls ML API** with portfolio data
3. **ML service runs 4 models in parallel:**
   - CVXPY: Optimizes allocation mathematically
   - XGBoost: Predicts market regime
   - LSTM: Forecasts returns
   - Claude: Provides strategic insights
4. **Ensemble combines results** with weights
5. **Generates trade recommendations**
6. **Returns JSON to frontend**
7. **UI displays beautiful recommendations**

## 💡 Customization

### Add Your Own Data

Replace `buildRequestPayload()` in React component with actual portfolio data from your database.

### Adjust Model Weights

In `ml-service/app.py`:
```python
self.weights = {
    'cvxpy': 0.40,    # Change these
    'xgboost': 0.30,
    'lstm': 0.20,
    'llm': 0.10
}
```

### Train Real Models

Replace simulated XGBoost/LSTM with actual trained models using your historical data.

## 🚢 Deployment

### Docker (Recommended)

```bash
# Build ML service
docker build -t ml-service ml-service/

# Run ML service
docker run -p 5000:5000 ml-service

# Build frontend
docker build -t frontend frontend/

# Run frontend
docker run -p 3000:3000 frontend
```

### Production

- ML Service: Deploy to AWS/GCP with auto-scaling
- Frontend: Deploy to Vercel/Netlify
- Use environment variables for configuration

## 📊 Performance

- ML processing: ~50-500ms per request
- Frontend render: <100ms
- Supports concurrent requests
- Caching recommended for production

## 🔒 Security

- Add authentication to ML API
- Validate all inputs
- Rate limiting recommended
- HTTPS in production
- Sanitize portfolio data

## 📄 License

MIT

## 🙏 Credits

- CVXPY: https://www.cvxpy.org/
- FastAPI: https://fastapi.tiangolo.com/
- React: https://reactjs.org/
- Anthropic Claude: https://www.anthropic.com/

---

**Built with ❤️ for intelligent portfolio management**
