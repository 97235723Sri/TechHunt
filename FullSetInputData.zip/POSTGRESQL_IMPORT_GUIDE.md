# PostgreSQL Complete Import Guide

## 📋 Complete File Checklist

✅ **corrected_portfolios.csv** - 10 portfolios  
✅ **corrected_holdings.csv** - 50 holdings  
✅ **corrected_target_allocations.csv** - 31 allocations  
✅ **corrected_drift_history.csv** - 214 historical records  
✅ **postgresql_schema.sql** - Complete DDL schema  

---

## 🚀 Step-by-Step Import Instructions

### Step 1: Create Database

```bash
# Create the database
createdb portfolio_rebalancer

# OR using psql
psql -U postgres
CREATE DATABASE portfolio_rebalancer;
\q
```

### Step 2: Create Schema

```bash
# Navigate to your data directory
cd /path/to/corrected_data/

# Execute schema creation
psql -d portfolio_rebalancer -f postgresql_schema.sql
```

**Expected Output:**
```
DROP TABLE
DROP TABLE
DROP TABLE
DROP TABLE
CREATE TABLE
CREATE INDEX
CREATE INDEX
CREATE INDEX
CREATE TABLE
CREATE INDEX
...
```

### Step 3: Verify Tables Created

```bash
psql -d portfolio_rebalancer
```

```sql
-- List all tables
\dt

-- Expected output:
-- portfolios
-- holdings
-- target_allocations
-- drift_history

-- Describe table structures
\d portfolios
\d holdings
\d target_allocations
\d drift_history
```

### Step 4: Import CSV Files

**Method A: Using psql \\COPY command (RECOMMENDED)**

```bash
psql -d portfolio_rebalancer

-- Import portfolios
\COPY portfolios FROM 'corrected_portfolios.csv' DELIMITER ',' CSV HEADER;

-- Import holdings
\COPY holdings FROM 'corrected_holdings.csv' DELIMITER ',' CSV HEADER;

-- Import target allocations
\COPY target_allocations FROM 'corrected_target_allocations.csv' DELIMITER ',' CSV HEADER;

-- Import drift history
\COPY drift_history FROM 'corrected_drift_history.csv' DELIMITER ',' CSV HEADER;
```

**Expected Output for each:**
```
COPY 10    (for portfolios)
COPY 50    (for holdings)
COPY 31    (for target_allocations)
COPY 214   (for drift_history)
```

**Method B: Using psql -c command**

```bash
# From command line
psql -d portfolio_rebalancer -c "\COPY portfolios FROM '/full/path/to/corrected_portfolios.csv' DELIMITER ',' CSV HEADER;"

psql -d portfolio_rebalancer -c "\COPY holdings FROM '/full/path/to/corrected_holdings.csv' DELIMITER ',' CSV HEADER;"

psql -d portfolio_rebalancer -c "\COPY target_allocations FROM '/full/path/to/corrected_target_allocations.csv' DELIMITER ',' CSV HEADER;"

psql -d portfolio_rebalancer -c "\COPY drift_history FROM '/full/path/to/corrected_drift_history.csv' DELIMITER ',' CSV HEADER;"
```

---

## ✅ Verification Steps

### Step 5: Verify Record Counts

```sql
-- Check all record counts
SELECT 'portfolios' AS table_name, COUNT(*) AS records FROM portfolios
UNION ALL
SELECT 'holdings', COUNT(*) FROM holdings
UNION ALL
SELECT 'target_allocations', COUNT(*) FROM target_allocations
UNION ALL
SELECT 'drift_history', COUNT(*) FROM drift_history;
```

**Expected Result:**
```
     table_name      | records 
--------------------+---------
 portfolios         |      10
 holdings           |      50
 target_allocations |      31
 drift_history      |     214
```

### Step 6: Verify Portfolio Totals

```sql
-- Verify cash + invested = total
SELECT 
    portfolio_id,
    portfolio_name,
    total_value,
    cash_balance,
    invested_value,
    cash_balance + invested_value AS calculated_total,
    total_value - (cash_balance + invested_value) AS difference
FROM portfolios
ORDER BY portfolio_id;
```

**Expected Result:** All `difference` values should be 0.00 ✅

### Step 7: Verify Allocation Percentages

```sql
-- Verify holdings allocations sum to 100%
SELECT 
    portfolio_id,
    COUNT(*) AS holdings_count,
    ROUND(SUM(current_allocation_pct)::NUMERIC, 2) AS total_allocation,
    100.00 - ROUND(SUM(current_allocation_pct)::NUMERIC, 2) AS variance
FROM holdings
GROUP BY portfolio_id
ORDER BY portfolio_id;
```

**Expected Result:** All `variance` values should be 0.00 ✅

### Step 8: Verify Calculations

```sql
-- Verify market_value = quantity * current_price
SELECT 
    holding_id,
    ticker,
    quantity,
    current_price,
    market_value,
    ROUND((quantity * current_price)::NUMERIC, 2) AS calculated_value,
    market_value - ROUND((quantity * current_price)::NUMERIC, 2) AS difference
FROM holdings
WHERE ABS(market_value - ROUND((quantity * current_price)::NUMERIC, 2)) > 0.01;
```

**Expected Result:** 0 rows (no calculation errors) ✅

### Step 9: Check Foreign Keys

```sql
-- Verify no orphaned holdings
SELECT 
    h.holding_id,
    h.portfolio_id,
    p.portfolio_id AS parent_exists
FROM holdings h
LEFT JOIN portfolios p ON h.portfolio_id = p.portfolio_id
WHERE p.portfolio_id IS NULL;

-- Verify no orphaned target allocations
SELECT 
    ta.allocation_id,
    ta.portfolio_id,
    p.portfolio_id AS parent_exists
FROM target_allocations ta
LEFT JOIN portfolios p ON ta.portfolio_id = p.portfolio_id
WHERE p.portfolio_id IS NULL;

-- Verify no orphaned drift history
SELECT 
    dh.drift_id,
    dh.portfolio_id,
    p.portfolio_id AS parent_exists
FROM drift_history dh
LEFT JOIN portfolios p ON dh.portfolio_id = p.portfolio_id
WHERE p.portfolio_id IS NULL;
```

**Expected Result:** All queries should return 0 rows ✅

---

## 📊 Sample Queries

### Query 1: Portfolio Summary

```sql
SELECT 
    portfolio_id,
    portfolio_name,
    TO_CHAR(total_value, '$999,999,999.99') AS total_value,
    TO_CHAR(current_drift, '999.99%') AS drift,
    risk_score,
    risk_level,
    rebalance_status,
    alerts_count
FROM portfolios
ORDER BY total_value DESC;
```

### Query 2: Holdings Requiring Action

```sql
SELECT 
    p.portfolio_name,
    h.ticker,
    h.company_name,
    h.current_allocation_pct,
    h.target_allocation_pct,
    h.drift_pct,
    h.recommended_action,
    h.recommended_shares,
    TO_CHAR(h.market_value, '$999,999.99') AS market_value
FROM holdings h
JOIN portfolios p ON h.portfolio_id = p.portfolio_id
WHERE h.recommended_action IN ('BUY', 'SELL')
ORDER BY p.portfolio_id, ABS(h.drift_pct) DESC;
```

### Query 3: Portfolio Risk Summary

```sql
SELECT 
    risk_level,
    COUNT(*) AS portfolio_count,
    TO_CHAR(SUM(total_value), '$999,999,999.99') AS total_aum,
    TO_CHAR(AVG(current_drift), '999.99%') AS avg_drift,
    ROUND(AVG(risk_score), 0) AS avg_risk_score
FROM portfolios
GROUP BY risk_level
ORDER BY avg_risk_score DESC;
```

### Query 4: Drift History Trend (PORT-001)

```sql
SELECT 
    snapshot_date,
    overall_drift,
    vix_level,
    market_volatility,
    threshold_breach,
    rebalance_event
FROM drift_history
WHERE portfolio_id = 'PORT-001'
    AND snapshot_date >= '2026-01-01'
ORDER BY snapshot_date;
```

### Query 5: Total AUM by Asset Class

```sql
SELECT 
    h.asset_class,
    COUNT(DISTINCT h.portfolio_id) AS portfolio_count,
    SUM(h.quantity) AS total_shares,
    TO_CHAR(SUM(h.market_value), '$999,999,999.99') AS total_value,
    ROUND(AVG(h.unrealized_gain_pct), 2) AS avg_gain_pct
FROM holdings h
GROUP BY h.asset_class
ORDER BY SUM(h.market_value) DESC;
```

---

## 🔧 Troubleshooting

### Problem: Import fails with "permission denied"

**Solution:**
```bash
# Make sure CSV files have read permissions
chmod 644 *.csv

# OR use absolute paths in COPY commands
\COPY portfolios FROM '/full/absolute/path/to/corrected_portfolios.csv' ...
```

### Problem: "relation does not exist"

**Solution:**
```bash
# Recreate schema
psql -d portfolio_rebalancer -f postgresql_schema.sql
```

### Problem: Foreign key violations

**Solution:**
```sql
-- Import in correct order (parents before children):
-- 1. portfolios (parent table)
-- 2. holdings (child of portfolios)
-- 3. target_allocations (child of portfolios)
-- 4. drift_history (child of portfolios)
```

### Problem: Date/time format errors

**Solution:**
All dates are in YYYY-MM-DD format
All timestamps are in YYYY-MM-DD HH:MM:SS format
These match PostgreSQL defaults ✅

### Problem: Decimal precision issues

**Solution:**
All money values: 2 decimals (e.g., 524830.00)
All percentages: 2-4 decimals (e.g., 5.20, 4.3500)
Already correctly formatted ✅

---

## 📈 Post-Import Optimization

### Create Additional Indexes (Optional)

```sql
-- Index for date-based queries
CREATE INDEX idx_drift_history_date_portfolio 
ON drift_history(portfolio_id, snapshot_date DESC);

-- Index for ticker lookups
CREATE INDEX idx_holdings_ticker_portfolio 
ON holdings(ticker, portfolio_id);

-- Index for asset class aggregations
CREATE INDEX idx_holdings_asset_class_value 
ON holdings(asset_class, market_value DESC);
```

### Update Statistics

```sql
-- Update table statistics for better query performance
ANALYZE portfolios;
ANALYZE holdings;
ANALYZE target_allocations;
ANALYZE drift_history;
```

### Create Views (Optional)

```sql
-- Portfolio summary view
CREATE VIEW v_portfolio_summary AS
SELECT 
    p.portfolio_id,
    p.portfolio_name,
    p.total_value,
    p.current_drift,
    p.rebalance_status,
    COUNT(h.holding_id) AS total_holdings,
    COUNT(CASE WHEN h.recommended_action IN ('BUY','SELL') THEN 1 END) AS actions_needed,
    SUM(CASE WHEN h.unrealized_gain > 0 THEN h.unrealized_gain ELSE 0 END) AS total_gains,
    SUM(CASE WHEN h.unrealized_gain < 0 THEN ABS(h.unrealized_gain) ELSE 0 END) AS total_losses
FROM portfolios p
LEFT JOIN holdings h ON p.portfolio_id = h.portfolio_id
GROUP BY p.portfolio_id, p.portfolio_name, p.total_value, p.current_drift, p.rebalance_status;
```

---

## ✅ Success Criteria

After successful import, you should have:

✅ 10 portfolios loaded  
✅ 50 holdings loaded  
✅ 31 target allocations loaded  
✅ 214 drift history records loaded  
✅ All foreign keys valid  
✅ All calculations accurate  
✅ All allocations sum to 100%  
✅ No constraint violations  
✅ Total AUM: $3,160,430.00  

---

## 🎯 Next Steps

1. ✅ Verify all data imported correctly
2. ✅ Run verification queries
3. ✅ Create any additional indexes needed
4. ✅ Set up backup strategy
5. ✅ Begin application development!

---

**Import completed successfully!** 🎉

Your PostgreSQL database is now ready for production use.

---
