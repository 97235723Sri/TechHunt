-- ============================================================================
-- SMART PORTFOLIO REBALANCER - POSTGRESQL DATABASE SCHEMA
-- Version: 2.0 (Corrected & Enhanced)
-- Date: February 2026
-- ============================================================================

-- Drop tables if they exist (for clean import)
DROP TABLE IF EXISTS drift_history CASCADE;
DROP TABLE IF EXISTS target_allocations CASCADE;
DROP TABLE IF EXISTS holdings CASCADE;
DROP TABLE IF EXISTS portfolios CASCADE;

-- ============================================================================
-- TABLE 1: portfolios
-- ============================================================================
CREATE TABLE portfolios (
    portfolio_id VARCHAR(20) PRIMARY KEY,
    portfolio_name VARCHAR(100) NOT NULL,
    user_id VARCHAR(20) NOT NULL,
    total_value DECIMAL(15,2) NOT NULL CHECK (total_value >= 0),
    cash_balance DECIMAL(15,2) NOT NULL CHECK (cash_balance >= 0),
    invested_value DECIMAL(15,2) NOT NULL CHECK (invested_value >= 0),
    current_drift DECIMAL(10,4) NOT NULL,
    drift_threshold DECIMAL(10,2) NOT NULL DEFAULT 5.00,
    last_rebalance_date DATE NOT NULL,
    days_since_rebalance INTEGER NOT NULL CHECK (days_since_rebalance >= 0),
    risk_score INTEGER NOT NULL CHECK (risk_score BETWEEN 0 AND 100),
    risk_level VARCHAR(50) NOT NULL,
    sharpe_ratio DECIMAL(10,4) NOT NULL,
    var_95_1day DECIMAL(10,4) NOT NULL,
    beta DECIMAL(10,4) NOT NULL,
    volatility_annual DECIMAL(10,4) NOT NULL,
    max_drawdown DECIMAL(10,4) NOT NULL,
    correlation_score DECIMAL(10,4) NOT NULL,
    rebalance_status VARCHAR(20) NOT NULL,
    alerts_count INTEGER NOT NULL DEFAULT 0,
    created_date DATE NOT NULL,
    updated_date DATE NOT NULL,
    
    -- Constraints
    CONSTRAINT chk_cash_invested CHECK (cash_balance + invested_value = total_value),
    CONSTRAINT chk_risk_level CHECK (risk_level IN ('Very Conservative', 'Conservative', 'Moderate', 'Moderate-Aggressive', 'Aggressive', 'Very Aggressive')),
    CONSTRAINT chk_rebalance_status CHECK (rebalance_status IN ('Good', 'Recommended', 'Critical'))
);

-- Create indexes for performance
CREATE INDEX idx_portfolios_user_id ON portfolios(user_id);
CREATE INDEX idx_portfolios_status ON portfolios(rebalance_status);
CREATE INDEX idx_portfolios_risk_level ON portfolios(risk_level);

-- ============================================================================
-- TABLE 2: holdings
-- ============================================================================
CREATE TABLE holdings (
    holding_id VARCHAR(20) PRIMARY KEY,
    portfolio_id VARCHAR(20) NOT NULL,
    ticker VARCHAR(10) NOT NULL,
    company_name VARCHAR(100) NOT NULL,
    asset_class VARCHAR(50) NOT NULL,
    sector VARCHAR(50) NOT NULL,
    quantity DECIMAL(15,4) NOT NULL CHECK (quantity >= 0),
    average_cost DECIMAL(15,4) NOT NULL CHECK (average_cost >= 0),
    current_price DECIMAL(15,4) NOT NULL CHECK (current_price >= 0),
    market_value DECIMAL(15,2) NOT NULL CHECK (market_value >= 0),
    cost_basis DECIMAL(15,2) NOT NULL CHECK (cost_basis >= 0),
    unrealized_gain DECIMAL(15,2) NOT NULL,
    unrealized_gain_pct DECIMAL(10,4) NOT NULL,
    current_allocation_pct DECIMAL(10,4) NOT NULL,
    target_allocation_pct DECIMAL(10,4) NOT NULL,
    drift_pct DECIMAL(10,4) NOT NULL,
    drift_status VARCHAR(20) NOT NULL,
    recommended_action VARCHAR(10) NOT NULL,
    recommended_shares INTEGER NOT NULL,
    dividend_yield DECIMAL(10,4) NOT NULL DEFAULT 0.00,
    last_updated TIMESTAMP NOT NULL,
    
    -- Foreign key
    CONSTRAINT fk_holdings_portfolio FOREIGN KEY (portfolio_id) 
        REFERENCES portfolios(portfolio_id) ON DELETE CASCADE,
    
    -- Constraints
    CONSTRAINT chk_market_value CHECK (ABS(quantity * current_price - market_value) < 1),
    CONSTRAINT chk_cost_basis CHECK (ABS(quantity * average_cost - cost_basis) < 1),
    CONSTRAINT chk_drift_status CHECK (drift_status IN ('Safe', 'Warning', 'Critical')),
    CONSTRAINT chk_recommended_action CHECK (recommended_action IN ('BUY', 'SELL', 'HOLD')),
    CONSTRAINT chk_asset_class CHECK (asset_class IN ('US Equity', 'International Equity', 'Bonds', 'REITs', 'Commodities', 'Cash'))
);

-- Create indexes
CREATE INDEX idx_holdings_portfolio ON holdings(portfolio_id);
CREATE INDEX idx_holdings_ticker ON holdings(ticker);
CREATE INDEX idx_holdings_asset_class ON holdings(asset_class);
CREATE INDEX idx_holdings_drift_status ON holdings(drift_status);
CREATE INDEX idx_holdings_action ON holdings(recommended_action);

-- ============================================================================
-- TABLE 3: target_allocations
-- ============================================================================
CREATE TABLE target_allocations (
    allocation_id VARCHAR(20) PRIMARY KEY,
    portfolio_id VARCHAR(20) NOT NULL,
    asset_class VARCHAR(50) NOT NULL,
    target_percentage DECIMAL(10,4) NOT NULL CHECK (target_percentage BETWEEN 0 AND 100),
    sub_allocations JSONB,
    drift_tolerance DECIMAL(10,4) NOT NULL DEFAULT 5.00,
    rebalance_band_lower DECIMAL(10,4) NOT NULL,
    rebalance_band_upper DECIMAL(10,4) NOT NULL,
    allocation_strategy VARCHAR(20) NOT NULL,
    last_updated DATE NOT NULL,
    
    -- Foreign key
    CONSTRAINT fk_target_allocations_portfolio FOREIGN KEY (portfolio_id) 
        REFERENCES portfolios(portfolio_id) ON DELETE CASCADE,
    
    -- Constraints
    CONSTRAINT chk_bands CHECK (rebalance_band_lower < rebalance_band_upper),
    CONSTRAINT chk_strategy CHECK (allocation_strategy IN ('Strategic', 'Tactical', 'Growth', 'Income', 'Conservative', 'Aggressive', 'Sector')),
    CONSTRAINT chk_target_asset_class CHECK (asset_class IN ('US Equity', 'International Equity', 'Bonds', 'REITs', 'Commodities', 'Cash'))
);

-- Create indexes
CREATE INDEX idx_target_allocations_portfolio ON target_allocations(portfolio_id);
CREATE INDEX idx_target_allocations_asset_class ON target_allocations(asset_class);

-- ============================================================================
-- TABLE 4: drift_history
-- ============================================================================
CREATE TABLE drift_history (
    drift_id VARCHAR(20) PRIMARY KEY,
    portfolio_id VARCHAR(20) NOT NULL,
    snapshot_date DATE NOT NULL,
    snapshot_time TIME NOT NULL,
    overall_drift DECIMAL(10,4) NOT NULL,
    us_equity_drift DECIMAL(10,4),
    international_equity_drift DECIMAL(10,4),
    bonds_drift DECIMAL(10,4),
    reits_drift DECIMAL(10,4),
    commodities_drift DECIMAL(10,4),
    cash_drift DECIMAL(10,4),
    threshold_breach BOOLEAN NOT NULL DEFAULT FALSE,
    critical_assets_count INTEGER NOT NULL DEFAULT 0,
    vix_level DECIMAL(10,4),
    market_volatility VARCHAR(20),
    rebalance_event BOOLEAN NOT NULL DEFAULT FALSE,
    notes TEXT,
    
    -- Foreign key
    CONSTRAINT fk_drift_history_portfolio FOREIGN KEY (portfolio_id) 
        REFERENCES portfolios(portfolio_id) ON DELETE CASCADE,
    
    -- Constraints
    CONSTRAINT chk_market_volatility CHECK (market_volatility IN ('Low', 'Moderate', 'High', 'Extreme') OR market_volatility IS NULL)
);

-- Create indexes
CREATE INDEX idx_drift_history_portfolio ON drift_history(portfolio_id);
CREATE INDEX idx_drift_history_date ON drift_history(snapshot_date DESC);
CREATE INDEX idx_drift_history_breach ON drift_history(threshold_breach);
CREATE INDEX idx_drift_history_rebalance ON drift_history(rebalance_event);

-- ============================================================================
-- IMPORT COMMANDS (Run after schema creation)
-- ============================================================================

-- Copy data from CSV files
-- Note: Adjust file paths to your actual location

-- COPY portfolios FROM '/path/to/corrected_portfolios.csv' DELIMITER ',' CSV HEADER;
-- COPY holdings FROM '/path/to/corrected_holdings.csv' DELIMITER ',' CSV HEADER;
-- COPY target_allocations FROM '/path/to/corrected_target_allocations.csv' DELIMITER ',' CSV HEADER;
-- COPY drift_history FROM '/path/to/corrected_drift_history.csv' DELIMITER ',' CSV HEADER;

-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================

-- Check portfolio totals
-- SELECT 
--     portfolio_id,
--     portfolio_name,
--     total_value,
--     cash_balance + invested_value AS calculated_total,
--     total_value - (cash_balance + invested_value) AS difference
-- FROM portfolios;

-- Verify holdings allocation percentages sum correctly
-- SELECT 
--     portfolio_id,
--     ROUND(SUM(current_allocation_pct)::NUMERIC, 2) AS total_allocation,
--     100.00 - ROUND(SUM(current_allocation_pct)::NUMERIC, 2) AS variance
-- FROM holdings
-- GROUP BY portfolio_id
-- ORDER BY portfolio_id;

-- Check for orphaned records
-- SELECT 'Holdings without portfolio' AS issue, COUNT(*) AS count
-- FROM holdings h
-- LEFT JOIN portfolios p ON h.portfolio_id = p.portfolio_id
-- WHERE p.portfolio_id IS NULL
-- UNION ALL
-- SELECT 'Target allocations without portfolio', COUNT(*)
-- FROM target_allocations ta
-- LEFT JOIN portfolios p ON ta.portfolio_id = p.portfolio_id
-- WHERE p.portfolio_id IS NULL;

-- ============================================================================
-- SUMMARY STATISTICS
-- ============================================================================

-- Portfolio summary
-- SELECT 
--     COUNT(*) AS total_portfolios,
--     SUM(total_value) AS total_aum,
--     AVG(current_drift) AS avg_drift,
--     AVG(risk_score) AS avg_risk_score,
--     COUNT(CASE WHEN rebalance_status = 'Critical' THEN 1 END) AS critical_count,
--     COUNT(CASE WHEN rebalance_status = 'Recommended' THEN 1 END) AS recommended_count,
--     COUNT(CASE WHEN rebalance_status = 'Good' THEN 1 END) AS good_count
-- FROM portfolios;

