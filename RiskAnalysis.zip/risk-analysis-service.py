"""
Portfolio Risk Analysis Service
Integrates with ML Ensemble for comprehensive risk assessment
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Dict, Optional
import numpy as np
from datetime import datetime, timedelta
import uuid

app = FastAPI(title="Portfolio Risk Analysis Service")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =============================================================================
# DATA MODELS
# =============================================================================

class Holding(BaseModel):
    ticker: str
    company_name: str
    asset_class: str
    quantity: int
    current_price: float
    average_cost: float
    market_value: float
    current_allocation_pct: float
    beta: Optional[float] = 1.0
    volatility: Optional[float] = 0.20

class PortfolioData(BaseModel):
    portfolio_id: str
    total_value: float
    current_drift: float
    risk_score: int
    sharpe_ratio: float
    volatility: float

class MarketData(BaseModel):
    vix: float
    sp500_return_1d: float
    sp500_return_30d: float
    treasury_10y: float
    market_sentiment: str

class RiskAnalysisRequest(BaseModel):
    portfolio: PortfolioData
    holdings: List[Holding]
    market_data: MarketData

class RiskMetric(BaseModel):
    name: str
    value: float
    threshold: float
    status: str  # LOW, MEDIUM, HIGH, CRITICAL
    description: str

class RiskFactor(BaseModel):
    factor: str
    contribution: float
    severity: str
    recommendation: str

class ConcentrationRisk(BaseModel):
    type: str  # ASSET, SECTOR, GEOGRAPHY
    concentration_score: float
    top_positions: List[Dict]
    warning_level: str

class VaRAnalysis(BaseModel):
    var_1day_95: float
    var_1day_99: float
    var_30day_95: float
    var_30day_99: float
    cvar_95: float  # Conditional VaR
    interpretation: str

class StressTest(BaseModel):
    scenario: str
    portfolio_impact: float
    probability: str
    mitigation: str

class RiskDecomposition(BaseModel):
    systematic_risk: float
    idiosyncratic_risk: float
    concentration_risk: float
    drift_risk: float
    market_risk: float

class RiskAnalysisResponse(BaseModel):
    analysis_id: str
    portfolio_id: str
    timestamp: str
    overall_risk_score: int  # 0-100
    risk_level: str  # LOW, MEDIUM, HIGH, CRITICAL
    
    # Core Metrics
    risk_metrics: List[RiskMetric]
    risk_factors: List[RiskFactor]
    concentration_risks: List[ConcentrationRisk]
    
    # Advanced Analytics
    var_analysis: VaRAnalysis
    stress_tests: List[StressTest]
    risk_decomposition: RiskDecomposition
    
    # Trend Analysis
    risk_trend: str  # INCREASING, STABLE, DECREASING
    drift_trend: str
    volatility_trend: str
    
    # Recommendations
    risk_mitigation_actions: List[str]
    warnings: List[str]
    
    # Visualizations Data
    risk_breakdown_chart: Dict
    var_distribution: Dict
    correlation_matrix: List[List[float]]

# =============================================================================
# RISK ANALYSIS ENGINE
# =============================================================================

class RiskAnalyzer:
    """Comprehensive portfolio risk analysis"""
    
    def __init__(self):
        self.risk_free_rate = 0.02
    
    def analyze(
        self,
        portfolio: PortfolioData,
        holdings: List[Holding],
        market_data: MarketData
    ) -> RiskAnalysisResponse:
        """Main risk analysis function"""
        
        # Calculate all risk metrics
        risk_metrics = self._calculate_risk_metrics(portfolio, holdings, market_data)
        risk_factors = self._identify_risk_factors(portfolio, holdings, market_data)
        concentration_risks = self._analyze_concentration(holdings)
        var_analysis = self._calculate_var(portfolio, holdings, market_data)
        stress_tests = self._run_stress_tests(portfolio, holdings)
        risk_decomposition = self._decompose_risk(portfolio, holdings, market_data)
        
        # Overall risk assessment
        overall_score = self._calculate_overall_risk_score(
            risk_metrics, concentration_risks, market_data
        )
        risk_level = self._determine_risk_level(overall_score)
        
        # Trend analysis
        risk_trend = self._analyze_risk_trend(portfolio, market_data)
        
        # Generate recommendations
        mitigation_actions = self._generate_mitigation_actions(
            risk_factors, concentration_risks, overall_score
        )
        warnings = self._generate_warnings(risk_metrics, market_data, overall_score)
        
        # Visualization data
        risk_breakdown = self._generate_risk_breakdown_chart(risk_decomposition)
        var_dist = self._generate_var_distribution(var_analysis)
        corr_matrix = self._calculate_correlation_matrix(holdings)
        
        return RiskAnalysisResponse(
            analysis_id=str(uuid.uuid4()),
            portfolio_id=portfolio.portfolio_id,
            timestamp=datetime.now().isoformat(),
            overall_risk_score=overall_score,
            risk_level=risk_level,
            risk_metrics=risk_metrics,
            risk_factors=risk_factors,
            concentration_risks=concentration_risks,
            var_analysis=var_analysis,
            stress_tests=stress_tests,
            risk_decomposition=risk_decomposition,
            risk_trend=risk_trend,
            drift_trend=self._analyze_drift_trend(portfolio),
            volatility_trend=self._analyze_volatility_trend(market_data),
            risk_mitigation_actions=mitigation_actions,
            warnings=warnings,
            risk_breakdown_chart=risk_breakdown,
            var_distribution=var_dist,
            correlation_matrix=corr_matrix
        )
    
    def _calculate_risk_metrics(
        self,
        portfolio: PortfolioData,
        holdings: List[Holding],
        market: MarketData
    ) -> List[RiskMetric]:
        """Calculate key risk metrics"""
        
        metrics = []
        
        # 1. Volatility Risk
        vol_status = "LOW" if portfolio.volatility < 0.15 else \
                     "MEDIUM" if portfolio.volatility < 0.25 else "HIGH"
        metrics.append(RiskMetric(
            name="Portfolio Volatility",
            value=portfolio.volatility,
            threshold=0.20,
            status=vol_status,
            description=f"Annual volatility: {portfolio.volatility*100:.1f}%"
        ))
        
        # 2. Drift Risk
        drift_status = "LOW" if portfolio.current_drift < 3 else \
                       "MEDIUM" if portfolio.current_drift < 7 else \
                       "HIGH" if portfolio.current_drift < 12 else "CRITICAL"
        metrics.append(RiskMetric(
            name="Portfolio Drift",
            value=portfolio.current_drift,
            threshold=5.0,
            status=drift_status,
            description=f"Drift from target: {portfolio.current_drift:.1f}%"
        ))
        
        # 3. Sharpe Ratio
        sharpe_status = "HIGH" if portfolio.sharpe_ratio < 0.5 else \
                        "MEDIUM" if portfolio.sharpe_ratio < 1.0 else "LOW"
        metrics.append(RiskMetric(
            name="Sharpe Ratio",
            value=portfolio.sharpe_ratio,
            threshold=1.0,
            status=sharpe_status,
            description=f"Risk-adjusted return: {portfolio.sharpe_ratio:.2f}"
        ))
        
        # 4. Market Risk (Beta)
        avg_beta = np.mean([h.beta for h in holdings if h.beta])
        beta_status = "LOW" if avg_beta < 0.8 else \
                      "MEDIUM" if avg_beta < 1.2 else "HIGH"
        metrics.append(RiskMetric(
            name="Market Beta",
            value=avg_beta,
            threshold=1.0,
            status=beta_status,
            description=f"Market sensitivity: {avg_beta:.2f}"
        ))
        
        # 5. Concentration Risk
        hhi = self._calculate_hhi(holdings)
        conc_status = "LOW" if hhi < 0.15 else \
                      "MEDIUM" if hhi < 0.25 else "HIGH"
        metrics.append(RiskMetric(
            name="Concentration (HHI)",
            value=hhi,
            threshold=0.20,
            status=conc_status,
            description=f"Portfolio concentration: {hhi:.3f}"
        ))
        
        # 6. Market Risk (VIX)
        vix_status = "LOW" if market.vix < 15 else \
                     "MEDIUM" if market.vix < 25 else "HIGH"
        metrics.append(RiskMetric(
            name="Market Volatility (VIX)",
            value=market.vix,
            threshold=20.0,
            status=vix_status,
            description=f"Market fear gauge: {market.vix:.1f}"
        ))
        
        return metrics
    
    def _identify_risk_factors(
        self,
        portfolio: PortfolioData,
        holdings: List[Holding],
        market: MarketData
    ) -> List[RiskFactor]:
        """Identify key risk factors"""
        
        factors = []
        
        # High drift risk
        if portfolio.current_drift > 7:
            factors.append(RiskFactor(
                factor="Portfolio Drift",
                contribution=min(portfolio.current_drift / 20, 1.0),
                severity="HIGH" if portfolio.current_drift > 12 else "MEDIUM",
                recommendation="Rebalance immediately to reduce drift risk"
            ))
        
        # Market volatility risk
        if market.vix > 25:
            factors.append(RiskFactor(
                factor="Market Volatility",
                contribution=min(market.vix / 50, 1.0),
                severity="HIGH",
                recommendation="Consider defensive positioning during high volatility"
            ))
        
        # Concentration risk
        top_position = max(holdings, key=lambda h: h.current_allocation_pct)
        if top_position.current_allocation_pct > 15:
            factors.append(RiskFactor(
                factor="Position Concentration",
                contribution=top_position.current_allocation_pct / 100,
                severity="MEDIUM" if top_position.current_allocation_pct < 25 else "HIGH",
                recommendation=f"Reduce {top_position.ticker} to below 15% allocation"
            ))
        
        # Low Sharpe ratio
        if portfolio.sharpe_ratio < 0.5:
            factors.append(RiskFactor(
                factor="Poor Risk-Adjusted Returns",
                contribution=0.6,
                severity="MEDIUM",
                recommendation="Review asset allocation for better risk/return balance"
            ))
        
        # Asset class concentration
        asset_classes = {}
        for h in holdings:
            asset_classes[h.asset_class] = asset_classes.get(h.asset_class, 0) + h.current_allocation_pct
        
        for ac, pct in asset_classes.items():
            if pct > 50:
                factors.append(RiskFactor(
                    factor=f"{ac} Concentration",
                    contribution=pct / 100,
                    severity="HIGH",
                    recommendation=f"Diversify beyond {ac} (currently {pct:.1f}%)"
                ))
        
        return factors
    
    def _analyze_concentration(self, holdings: List[Holding]) -> List[ConcentrationRisk]:
        """Analyze concentration risks"""
        
        risks = []
        
        # Asset-level concentration
        sorted_holdings = sorted(holdings, key=lambda h: h.current_allocation_pct, reverse=True)
        top_3 = sorted_holdings[:3]
        top_3_pct = sum(h.current_allocation_pct for h in top_3)
        
        asset_warning = "LOW" if top_3_pct < 40 else \
                       "MEDIUM" if top_3_pct < 60 else "HIGH"
        
        risks.append(ConcentrationRisk(
            type="ASSET",
            concentration_score=top_3_pct / 100,
            top_positions=[
                {
                    "ticker": h.ticker,
                    "allocation": h.current_allocation_pct,
                    "value": h.market_value
                } for h in top_3
            ],
            warning_level=asset_warning
        ))
        
        # Sector/Asset class concentration
        asset_classes = {}
        for h in holdings:
            asset_classes[h.asset_class] = asset_classes.get(h.asset_class, 0) + h.current_allocation_pct
        
        max_class_pct = max(asset_classes.values())
        sector_warning = "LOW" if max_class_pct < 40 else \
                        "MEDIUM" if max_class_pct < 60 else "HIGH"
        
        risks.append(ConcentrationRisk(
            type="SECTOR",
            concentration_score=max_class_pct / 100,
            top_positions=[
                {"sector": k, "allocation": v}
                for k, v in sorted(asset_classes.items(), key=lambda x: x[1], reverse=True)
            ],
            warning_level=sector_warning
        ))
        
        return risks
    
    def _calculate_var(
        self,
        portfolio: PortfolioData,
        holdings: List[Holding],
        market: MarketData
    ) -> VaRAnalysis:
        """Calculate Value at Risk"""
        
        # Portfolio volatility
        vol = portfolio.volatility
        value = portfolio.total_value
        
        # VaR calculation (parametric method)
        # 95% confidence: 1.645 standard deviations
        # 99% confidence: 2.326 standard deviations
        
        var_1day_95 = value * vol * 1.645 / np.sqrt(252)
        var_1day_99 = value * vol * 2.326 / np.sqrt(252)
        var_30day_95 = value * vol * 1.645 / np.sqrt(252/30)
        var_30day_99 = value * vol * 2.326 / np.sqrt(252/30)
        
        # Conditional VaR (Expected Shortfall)
        cvar_95 = var_1day_95 * 1.3  # Approximation
        
        interpretation = f"There is a 5% chance of losing more than ${var_1day_95:,.0f} in one day"
        
        return VaRAnalysis(
            var_1day_95=var_1day_95,
            var_1day_99=var_1day_99,
            var_30day_95=var_30day_95,
            var_30day_99=var_30day_99,
            cvar_95=cvar_95,
            interpretation=interpretation
        )
    
    def _run_stress_tests(
        self,
        portfolio: PortfolioData,
        holdings: List[Holding]
    ) -> List[StressTest]:
        """Run stress test scenarios"""
        
        tests = []
        value = portfolio.total_value
        
        # Market crash scenario
        tests.append(StressTest(
            scenario="Market Crash (-20%)",
            portfolio_impact=-value * 0.20,
            probability="LOW (2-5%)",
            mitigation="Maintain 20%+ bonds allocation, rebalance quarterly"
        ))
        
        # Sector rotation
        tests.append(StressTest(
            scenario="Tech Sector Decline (-15%)",
            portfolio_impact=-value * 0.15 * 0.35,  # Assume 35% tech exposure
            probability="MEDIUM (10-15%)",
            mitigation="Diversify across sectors, limit tech to 30%"
        ))
        
        # Rising rates
        tests.append(StressTest(
            scenario="Interest Rate Spike (+2%)",
            portfolio_impact=-value * 0.08,
            probability="MEDIUM (10-20%)",
            mitigation="Reduce bond duration, add floating rate securities"
        ))
        
        # Volatility spike
        tests.append(StressTest(
            scenario="VIX Spike to 50",
            portfolio_impact=-value * 0.12,
            probability="LOW (5-10%)",
            mitigation="Maintain cash buffer, use volatility for rebalancing"
        ))
        
        return tests
    
    def _decompose_risk(
        self,
        portfolio: PortfolioData,
        holdings: List[Holding],
        market: MarketData
    ) -> RiskDecomposition:
        """Decompose total risk into components"""
        
        total_vol = portfolio.volatility
        
        # Systematic risk (market beta)
        avg_beta = np.mean([h.beta for h in holdings if h.beta])
        systematic = total_vol * avg_beta * 0.7
        
        # Idiosyncratic risk
        idiosyncratic = total_vol * 0.3
        
        # Concentration risk
        hhi = self._calculate_hhi(holdings)
        concentration = hhi * 0.5
        
        # Drift risk
        drift_risk = min(portfolio.current_drift / 100, 0.3)
        
        # Market risk
        market_risk = (market.vix / 100) * 0.6
        
        return RiskDecomposition(
            systematic_risk=systematic,
            idiosyncratic_risk=idiosyncratic,
            concentration_risk=concentration,
            drift_risk=drift_risk,
            market_risk=market_risk
        )
    
    def _calculate_hhi(self, holdings: List[Holding]) -> float:
        """Calculate Herfindahl-Hirschman Index"""
        return sum((h.current_allocation_pct / 100) ** 2 for h in holdings)
    
    def _calculate_overall_risk_score(
        self,
        metrics: List[RiskMetric],
        concentration: List[ConcentrationRisk],
        market: MarketData
    ) -> int:
        """Calculate overall risk score (0-100)"""
        
        score = 0
        
        # Metrics contribution
        for m in metrics:
            if m.status == "CRITICAL":
                score += 20
            elif m.status == "HIGH":
                score += 15
            elif m.status == "MEDIUM":
                score += 10
            elif m.status == "LOW":
                score += 5
        
        # Concentration penalty
        for c in concentration:
            if c.warning_level == "HIGH":
                score += 15
            elif c.warning_level == "MEDIUM":
                score += 10
        
        # Market condition adjustment
        if market.vix > 30:
            score += 10
        
        return min(score, 100)
    
    def _determine_risk_level(self, score: int) -> str:
        """Determine risk level from score"""
        if score < 30:
            return "LOW"
        elif score < 50:
            return "MEDIUM"
        elif score < 75:
            return "HIGH"
        else:
            return "CRITICAL"
    
    def _analyze_risk_trend(self, portfolio: PortfolioData, market: MarketData) -> str:
        """Analyze risk trend"""
        # Simplified trend analysis
        if portfolio.current_drift > 7 or market.vix > 25:
            return "INCREASING"
        elif portfolio.current_drift < 3 and market.vix < 15:
            return "DECREASING"
        else:
            return "STABLE"
    
    def _analyze_drift_trend(self, portfolio: PortfolioData) -> str:
        """Analyze drift trend"""
        if portfolio.current_drift > 7:
            return "INCREASING"
        elif portfolio.current_drift < 3:
            return "DECREASING"
        else:
            return "STABLE"
    
    def _analyze_volatility_trend(self, market: MarketData) -> str:
        """Analyze volatility trend"""
        if market.vix > 25:
            return "INCREASING"
        elif market.vix < 15:
            return "DECREASING"
        else:
            return "STABLE"
    
    def _generate_mitigation_actions(
        self,
        factors: List[RiskFactor],
        concentration: List[ConcentrationRisk],
        overall_score: int
    ) -> List[str]:
        """Generate risk mitigation recommendations"""
        
        actions = []
        
        # High overall risk
        if overall_score > 75:
            actions.append("URGENT: Reduce portfolio risk immediately through rebalancing")
        
        # Specific factor mitigations
        for f in factors:
            if f.severity in ["HIGH", "CRITICAL"]:
                actions.append(f.recommendation)
        
        # Concentration mitigations
        for c in concentration:
            if c.warning_level == "HIGH":
                if c.type == "ASSET":
                    actions.append(f"Reduce top 3 positions (currently {c.concentration_score*100:.1f}%)")
                elif c.type == "SECTOR":
                    actions.append(f"Diversify across sectors to reduce concentration")
        
        # General recommendations
        if not actions:
            actions.append("Maintain current risk management approach")
        
        return actions
    
    def _generate_warnings(
        self,
        metrics: List[RiskMetric],
        market: MarketData,
        score: int
    ) -> List[str]:
        """Generate warnings"""
        
        warnings = []
        
        # Critical metrics
        for m in metrics:
            if m.status == "CRITICAL":
                warnings.append(f"CRITICAL: {m.name} at {m.value:.2f} (threshold: {m.threshold})")
        
        # Market conditions
        if market.vix > 30:
            warnings.append(f"Extreme market volatility detected (VIX: {market.vix:.1f})")
        
        # Overall risk
        if score > 75:
            warnings.append("Portfolio in HIGH RISK zone - immediate action recommended")
        
        return warnings
    
    def _generate_risk_breakdown_chart(self, decomp: RiskDecomposition) -> Dict:
        """Generate data for risk breakdown chart"""
        return {
            "labels": ["Systematic", "Idiosyncratic", "Concentration", "Drift", "Market"],
            "values": [
                decomp.systematic_risk * 100,
                decomp.idiosyncratic_risk * 100,
                decomp.concentration_risk * 100,
                decomp.drift_risk * 100,
                decomp.market_risk * 100
            ]
        }
    
    def _generate_var_distribution(self, var: VaRAnalysis) -> Dict:
        """Generate VaR distribution data"""
        return {
            "labels": ["VaR 1D 95%", "VaR 1D 99%", "VaR 30D 95%", "VaR 30D 99%", "CVaR 95%"],
            "values": [
                var.var_1day_95,
                var.var_1day_99,
                var.var_30day_95,
                var.var_30day_99,
                var.cvar_95
            ]
        }
    
    def _calculate_correlation_matrix(self, holdings: List[Holding]) -> List[List[float]]:
        """Generate correlation matrix"""
        n = len(holdings)
        matrix = [[0.0] * n for _ in range(n)]
        
        for i in range(n):
            for j in range(n):
                if i == j:
                    matrix[i][j] = 1.0
                else:
                    # Same asset class = higher correlation
                    if holdings[i].asset_class == holdings[j].asset_class:
                        matrix[i][j] = 0.7 + np.random.uniform(-0.1, 0.1)
                    else:
                        matrix[i][j] = 0.3 + np.random.uniform(-0.2, 0.2)
        
        return matrix

# =============================================================================
# API ENDPOINTS
# =============================================================================

analyzer = RiskAnalyzer()

@app.get("/")
async def root():
    return {
        "service": "Portfolio Risk Analysis Service",
        "version": "1.0.0",
        "features": [
            "Risk Metrics",
            "VaR Analysis",
            "Stress Testing",
            "Concentration Analysis",
            "Risk Decomposition"
        ]
    }

@app.get("/health")
async def health():
    return {"status": "healthy"}

@app.post("/api/risk/analyze", response_model=RiskAnalysisResponse)
async def analyze_risk(request: RiskAnalysisRequest):
    """
    Comprehensive risk analysis
    Returns detailed risk metrics and recommendations
    """
    try:
        result = analyzer.analyze(
            request.portfolio,
            request.holdings,
            request.market_data
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/risk/quick-score")
async def quick_risk_score(request: RiskAnalysisRequest):
    """Quick risk score calculation"""
    try:
        analysis = analyzer.analyze(
            request.portfolio,
            request.holdings,
            request.market_data
        )
        
        return {
            "portfolio_id": request.portfolio.portfolio_id,
            "risk_score": analysis.overall_risk_score,
            "risk_level": analysis.risk_level,
            "risk_trend": analysis.risk_trend,
            "top_risks": [
                f.factor for f in analysis.risk_factors[:3]
            ]
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    print("Starting Portfolio Risk Analysis Service...")
    uvicorn.run(app, host="0.0.0.0", port=5001, log_level="info")
