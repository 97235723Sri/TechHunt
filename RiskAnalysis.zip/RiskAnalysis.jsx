import React, { useState, useEffect } from 'react';
import './RiskAnalysis.css';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5001';

const RiskAnalysis = ({ portfolioId }) => {
  const [riskData, setRiskData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [selectedTab, setSelectedTab] = useState('overview');

  useEffect(() => {
    if (portfolioId) {
      fetchRiskAnalysis();
    }
  }, [portfolioId]);

  const fetchRiskAnalysis = async () => {
    setLoading(true);
    try {
      const requestData = buildRiskRequest(portfolioId);
      
      const response = await fetch(`${API_URL}/api/risk/analyze`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestData)
      });

      const data = await response.json();
      setRiskData(data);
    } catch (error) {
      console.error('Error fetching risk analysis:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <LoadingState />;
  }

  if (!riskData) {
    return <EmptyState onAnalyze={fetchRiskAnalysis} />;
  }

  return (
    <div className="risk-analysis">
      {/* Header */}
      <RiskHeader riskData={riskData} />

      {/* Navigation Tabs */}
      <RiskTabs selectedTab={selectedTab} setSelectedTab={setSelectedTab} />

      {/* Content based on selected tab */}
      {selectedTab === 'overview' && <OverviewTab riskData={riskData} />}
      {selectedTab === 'metrics' && <MetricsTab riskData={riskData} />}
      {selectedTab === 'var' && <VaRTab riskData={riskData} />}
      {selectedTab === 'stress' && <StressTestTab riskData={riskData} />}
      {selectedTab === 'concentration' && <ConcentrationTab riskData={riskData} />}
    </div>
  );
};

// ========================================================================
// HEADER
// ========================================================================

const RiskHeader = ({ riskData }) => {
  const getRiskColor = (level) => {
    const colors = {
      'LOW': '#2ecc71',
      'MEDIUM': '#f39c12',
      'HIGH': '#e74c3c',
      'CRITICAL': '#c0392b'
    };
    return colors[level] || '#95a5a6';
  };

  return (
    <div className="risk-header">
      <div className="header-content">
        <h1>
          <span className="icon">📊</span>
          Portfolio Risk Analysis
        </h1>
        <p className="subtitle">Comprehensive risk assessment and monitoring</p>
      </div>
      <div className="risk-score-card">
        <div className="score-circle" style={{ 
          borderColor: getRiskColor(riskData.risk_level) 
        }}>
          <div className="score-value">{riskData.overall_risk_score}</div>
          <div className="score-label">Risk Score</div>
        </div>
        <div className="risk-status">
          <span 
            className={`risk-badge ${riskData.risk_level.toLowerCase()}`}
            style={{ backgroundColor: getRiskColor(riskData.risk_level) }}
          >
            {riskData.risk_level} RISK
          </span>
          <div className="trend">
            <span className={`trend-icon ${riskData.risk_trend.toLowerCase()}`}>
              {riskData.risk_trend === 'INCREASING' ? '↗' : 
               riskData.risk_trend === 'DECREASING' ? '↘' : '→'}
            </span>
            <span className="trend-text">{riskData.risk_trend}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

// ========================================================================
// TABS
// ========================================================================

const RiskTabs = ({ selectedTab, setSelectedTab }) => {
  const tabs = [
    { id: 'overview', label: 'Overview', icon: '📋' },
    { id: 'metrics', label: 'Risk Metrics', icon: '📊' },
    { id: 'var', label: 'VaR Analysis', icon: '📉' },
    { id: 'stress', label: 'Stress Tests', icon: '⚠️' },
    { id: 'concentration', label: 'Concentration', icon: '🎯' }
  ];

  return (
    <div className="risk-tabs">
      {tabs.map(tab => (
        <button
          key={tab.id}
          className={`tab ${selectedTab === tab.id ? 'active' : ''}`}
          onClick={() => setSelectedTab(tab.id)}
        >
          <span className="tab-icon">{tab.icon}</span>
          <span className="tab-label">{tab.label}</span>
        </button>
      ))}
    </div>
  );
};

// ========================================================================
// OVERVIEW TAB
// ========================================================================

const OverviewTab = ({ riskData }) => {
  return (
    <div className="overview-tab">
      {/* Quick Metrics */}
      <div className="quick-metrics">
        <QuickMetricCard
          icon="📊"
          label="Overall Risk"
          value={riskData.overall_risk_score}
          max={100}
          status={riskData.risk_level}
        />
        <QuickMetricCard
          icon="💨"
          label="Volatility"
          value={(riskData.risk_metrics.find(m => m.name === "Portfolio Volatility")?.value * 100).toFixed(1)}
          unit="%"
          status={riskData.risk_metrics.find(m => m.name === "Portfolio Volatility")?.status}
        />
        <QuickMetricCard
          icon="⚡"
          label="Drift"
          value={riskData.risk_metrics.find(m => m.name === "Portfolio Drift")?.value.toFixed(1)}
          unit="%"
          status={riskData.risk_metrics.find(m => m.name === "Portfolio Drift")?.status}
        />
        <QuickMetricCard
          icon="📈"
          label="Sharpe Ratio"
          value={riskData.risk_metrics.find(m => m.name === "Sharpe Ratio")?.value.toFixed(2)}
          status={riskData.risk_metrics.find(m => m.name === "Sharpe Ratio")?.status}
        />
      </div>

      {/* Risk Decomposition */}
      <div className="risk-decomposition-card">
        <h3>Risk Decomposition</h3>
        <RiskBreakdownChart data={riskData.risk_breakdown_chart} />
        <div className="decomposition-details">
          <DecompositionRow 
            label="Systematic Risk"
            value={riskData.risk_decomposition.systematic_risk}
            color="#3498db"
          />
          <DecompositionRow 
            label="Idiosyncratic Risk"
            value={riskData.risk_decomposition.idiosyncratic_risk}
            color="#9b59b6"
          />
          <DecompositionRow 
            label="Concentration Risk"
            value={riskData.risk_decomposition.concentration_risk}
            color="#e74c3c"
          />
          <DecompositionRow 
            label="Drift Risk"
            value={riskData.risk_decomposition.drift_risk}
            color="#f39c12"
          />
          <DecompositionRow 
            label="Market Risk"
            value={riskData.risk_decomposition.market_risk}
            color="#1abc9c"
          />
        </div>
      </div>

      {/* Risk Factors */}
      <div className="risk-factors-card">
        <h3>🎯 Key Risk Factors</h3>
        <div className="risk-factors-list">
          {riskData.risk_factors.map((factor, index) => (
            <RiskFactorItem key={index} factor={factor} />
          ))}
        </div>
      </div>

      {/* Warnings */}
      {riskData.warnings.length > 0 && (
        <div className="warnings-card">
          <h3>⚠️ Active Warnings</h3>
          {riskData.warnings.map((warning, index) => (
            <div key={index} className="warning-item">
              <span className="warning-icon">⚠️</span>
              <span>{warning}</span>
            </div>
          ))}
        </div>
      )}

      {/* Mitigation Actions */}
      <div className="mitigation-card">
        <h3>🛡️ Risk Mitigation Actions</h3>
        <div className="action-list">
          {riskData.risk_mitigation_actions.map((action, index) => (
            <div key={index} className="action-item">
              <span className="action-number">{index + 1}</span>
              <span className="action-text">{action}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// ========================================================================
// METRICS TAB
// ========================================================================

const MetricsTab = ({ riskData }) => {
  return (
    <div className="metrics-tab">
      <h2>Risk Metrics Dashboard</h2>
      <div className="metrics-grid">
        {riskData.risk_metrics.map((metric, index) => (
          <MetricCard key={index} metric={metric} />
        ))}
      </div>

      {/* Trends */}
      <div className="trends-section">
        <h3>Risk Trends</h3>
        <div className="trends-grid">
          <TrendCard
            label="Overall Risk"
            trend={riskData.risk_trend}
            icon="📊"
          />
          <TrendCard
            label="Portfolio Drift"
            trend={riskData.drift_trend}
            icon="⚡"
          />
          <TrendCard
            label="Market Volatility"
            trend={riskData.volatility_trend}
            icon="💨"
          />
        </div>
      </div>
    </div>
  );
};

// ========================================================================
// VAR TAB
// ========================================================================

const VaRTab = ({ riskData }) => {
  const var_data = riskData.var_analysis;

  return (
    <div className="var-tab">
      <h2>Value at Risk (VaR) Analysis</h2>
      
      <div className="var-explanation">
        <p><strong>What is VaR?</strong> Value at Risk estimates the maximum potential loss over a given time period at a specific confidence level.</p>
        <p className="interpretation">{var_data.interpretation}</p>
      </div>

      <div className="var-metrics">
        <div className="var-metric-card">
          <div className="var-header">
            <h4>1-Day VaR</h4>
            <span className="confidence">95% Confidence</span>
          </div>
          <div className="var-value">${var_data.var_1day_95.toLocaleString()}</div>
          <p className="var-description">Maximum expected loss in one trading day</p>
        </div>

        <div className="var-metric-card">
          <div className="var-header">
            <h4>1-Day VaR</h4>
            <span className="confidence">99% Confidence</span>
          </div>
          <div className="var-value">${var_data.var_1day_99.toLocaleString()}</div>
          <p className="var-description">Extreme loss scenario (1 in 100 days)</p>
        </div>

        <div className="var-metric-card">
          <div className="var-header">
            <h4>30-Day VaR</h4>
            <span className="confidence">95% Confidence</span>
          </div>
          <div className="var-value">${var_data.var_30day_95.toLocaleString()}</div>
          <p className="var-description">Maximum expected loss over one month</p>
        </div>

        <div className="var-metric-card highlighted">
          <div className="var-header">
            <h4>Conditional VaR</h4>
            <span className="confidence">CVaR (95%)</span>
          </div>
          <div className="var-value">${var_data.cvar_95.toLocaleString()}</div>
          <p className="var-description">Expected loss when VaR is exceeded</p>
        </div>
      </div>

      {/* VaR Distribution Chart */}
      <div className="var-chart-card">
        <h3>VaR Distribution</h3>
        <VaRChart data={riskData.var_distribution} />
      </div>
    </div>
  );
};

// ========================================================================
// STRESS TEST TAB
// ========================================================================

const StressTestTab = ({ riskData }) => {
  return (
    <div className="stress-tab">
      <h2>Stress Test Scenarios</h2>
      <p className="tab-description">
        Analysis of portfolio performance under adverse market conditions
      </p>

      <div className="stress-tests">
        {riskData.stress_tests.map((test, index) => (
          <StressTestCard key={index} test={test} />
        ))}
      </div>
    </div>
  );
};

// ========================================================================
// CONCENTRATION TAB
// ========================================================================

const ConcentrationTab = ({ riskData }) => {
  return (
    <div className="concentration-tab">
      <h2>Concentration Risk Analysis</h2>

      {riskData.concentration_risks.map((risk, index) => (
        <ConcentrationCard key={index} risk={risk} />
      ))}

      {/* Correlation Matrix */}
      <div className="correlation-card">
        <h3>Position Correlation Matrix</h3>
        <p className="matrix-description">
          Shows how closely positions move together (1.0 = perfect correlation)
        </p>
        <CorrelationMatrix matrix={riskData.correlation_matrix} />
      </div>
    </div>
  );
};

// ========================================================================
// COMPONENT HELPERS
// ========================================================================

const QuickMetricCard = ({ icon, label, value, unit = '', max, status }) => {
  const getStatusColor = (status) => {
    const colors = {
      'LOW': '#2ecc71',
      'MEDIUM': '#f39c12',
      'HIGH': '#e74c3c',
      'CRITICAL': '#c0392b'
    };
    return colors[status] || '#95a5a6';
  };

  return (
    <div className="quick-metric-card">
      <div className="metric-icon">{icon}</div>
      <div className="metric-content">
        <div className="metric-label">{label}</div>
        <div className="metric-value">
          {value}{unit}
          {max && <span className="metric-max">/{max}</span>}
        </div>
        {status && (
          <div 
            className="metric-status"
            style={{ color: getStatusColor(status) }}
          >
            {status}
          </div>
        )}
      </div>
    </div>
  );
};

const DecompositionRow = ({ label, value, color }) => {
  const percentage = (value * 100).toFixed(1);
  
  return (
    <div className="decomposition-row">
      <div className="decomp-label">
        <span className="color-dot" style={{ backgroundColor: color }}></span>
        {label}
      </div>
      <div className="decomp-bar">
        <div 
          className="decomp-fill"
          style={{ 
            width: `${Math.min(percentage, 100)}%`,
            backgroundColor: color 
          }}
        ></div>
      </div>
      <div className="decomp-value">{percentage}%</div>
    </div>
  );
};

const RiskFactorItem = ({ factor }) => {
  const getSeverityColor = (severity) => {
    const colors = {
      'LOW': '#2ecc71',
      'MEDIUM': '#f39c12',
      'HIGH': '#e74c3c',
      'CRITICAL': '#c0392b'
    };
    return colors[severity] || '#95a5a6';
  };

  return (
    <div className="risk-factor-item">
      <div className="factor-header">
        <h4>{factor.factor}</h4>
        <span 
          className="severity-badge"
          style={{ backgroundColor: getSeverityColor(factor.severity) }}
        >
          {factor.severity}
        </span>
      </div>
      <div className="factor-contribution">
        <div className="contribution-bar">
          <div 
            className="contribution-fill"
            style={{ width: `${factor.contribution * 100}%` }}
          ></div>
        </div>
        <span className="contribution-pct">
          {(factor.contribution * 100).toFixed(0)}% contribution
        </span>
      </div>
      <p className="factor-recommendation">
        <strong>Recommendation:</strong> {factor.recommendation}
      </p>
    </div>
  );
};

const MetricCard = ({ metric }) => {
  const getStatusColor = (status) => {
    const colors = {
      'LOW': '#2ecc71',
      'MEDIUM': '#f39c12',
      'HIGH': '#e74c3c',
      'CRITICAL': '#c0392b'
    };
    return colors[status] || '#95a5a6';
  };

  return (
    <div className="metric-card" style={{ borderLeftColor: getStatusColor(metric.status) }}>
      <div className="metric-card-header">
        <h4>{metric.name}</h4>
        <span 
          className="status-badge"
          style={{ backgroundColor: getStatusColor(metric.status) }}
        >
          {metric.status}
        </span>
      </div>
      <div className="metric-card-value">
        {metric.value.toFixed(2)}
        <span className="threshold">/ {metric.threshold}</span>
      </div>
      <p className="metric-description">{metric.description}</p>
      <div className="metric-progress">
        <div 
          className="progress-fill"
          style={{ 
            width: `${Math.min((metric.value / metric.threshold) * 100, 100)}%`,
            backgroundColor: getStatusColor(metric.status)
          }}
        ></div>
      </div>
    </div>
  );
};

const TrendCard = ({ label, trend, icon }) => {
  const getTrendIcon = (trend) => {
    if (trend === 'INCREASING') return '↗';
    if (trend === 'DECREASING') return '↘';
    return '→';
  };

  const getTrendColor = (trend) => {
    if (trend === 'INCREASING') return '#e74c3c';
    if (trend === 'DECREASING') return '#2ecc71';
    return '#f39c12';
  };

  return (
    <div className="trend-card">
      <div className="trend-icon-large">{icon}</div>
      <div className="trend-content">
        <div className="trend-label">{label}</div>
        <div 
          className="trend-value"
          style={{ color: getTrendColor(trend) }}
        >
          <span className="trend-arrow">{getTrendIcon(trend)}</span>
          {trend}
        </div>
      </div>
    </div>
  );
};

const StressTestCard = ({ test }) => {
  const impactColor = test.portfolio_impact < 0 ? '#e74c3c' : '#2ecc71';
  
  return (
    <div className="stress-test-card">
      <div className="stress-header">
        <h4>{test.scenario}</h4>
        <span className="probability-badge">{test.probability}</span>
      </div>
      <div className="stress-impact" style={{ color: impactColor }}>
        <span className="impact-label">Portfolio Impact:</span>
        <span className="impact-value">
          ${Math.abs(test.portfolio_impact).toLocaleString()}
        </span>
      </div>
      <div className="stress-mitigation">
        <strong>Mitigation:</strong>
        <p>{test.mitigation}</p>
      </div>
    </div>
  );
};

const ConcentrationCard = ({ risk }) => {
  return (
    <div className="concentration-card">
      <div className="concentration-header">
        <h3>{risk.type} Concentration</h3>
        <span className={`warning-badge ${risk.warning_level.toLowerCase()}`}>
          {risk.warning_level} RISK
        </span>
      </div>
      <div className="concentration-score">
        <div className="score-label">Concentration Score</div>
        <div className="score-value">{(risk.concentration_score * 100).toFixed(1)}%</div>
      </div>
      <div className="top-positions">
        <h4>Top Positions</h4>
        <div className="positions-list">
          {risk.top_positions.map((pos, index) => (
            <div key={index} className="position-item">
              <span className="position-name">
                {pos.ticker || pos.sector}
              </span>
              <span className="position-allocation">
                {pos.allocation.toFixed(1)}%
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// Simple chart components (you can replace with recharts/chart.js)
const RiskBreakdownChart = ({ data }) => {
  return (
    <div className="simple-bar-chart">
      {data.labels.map((label, index) => (
        <div key={index} className="chart-bar">
          <div className="bar-label">{label}</div>
          <div className="bar-container">
            <div 
              className="bar-fill"
              style={{ width: `${data.values[index]}%` }}
            ></div>
          </div>
          <div className="bar-value">{data.values[index].toFixed(1)}%</div>
        </div>
      ))}
    </div>
  );
};

const VaRChart = ({ data }) => {
  const maxValue = Math.max(...data.values);
  
  return (
    <div className="var-bar-chart">
      {data.labels.map((label, index) => (
        <div key={index} className="var-bar">
          <div 
            className="var-bar-fill"
            style={{ height: `${(data.values[index] / maxValue) * 200}px` }}
          ></div>
          <div className="var-bar-label">{label}</div>
          <div className="var-bar-value">
            ${(data.values[index] / 1000).toFixed(0)}K
          </div>
        </div>
      ))}
    </div>
  );
};

const CorrelationMatrix = ({ matrix }) => {
  const getCorrelationColor = (value) => {
    if (value > 0.7) return '#e74c3c';
    if (value > 0.4) return '#f39c12';
    return '#2ecc71';
  };

  return (
    <div className="correlation-matrix">
      {matrix.slice(0, 5).map((row, i) => (
        <div key={i} className="matrix-row">
          {row.slice(0, 5).map((cell, j) => (
            <div 
              key={j}
              className="matrix-cell"
              style={{ backgroundColor: getCorrelationColor(cell) }}
              title={`Correlation: ${cell.toFixed(2)}`}
            >
              {cell.toFixed(2)}
            </div>
          ))}
        </div>
      ))}
    </div>
  );
};

// Loading and Empty States
const LoadingState = () => (
  <div className="loading-state">
    <div className="spinner"></div>
    <h3>Analyzing Portfolio Risk...</h3>
  </div>
);

const EmptyState = ({ onAnalyze }) => (
  <div className="empty-state">
    <span className="empty-icon">📊</span>
    <h3>No Risk Analysis Available</h3>
    <button className="btn btn-primary" onClick={onAnalyze}>
      Run Risk Analysis
    </button>
  </div>
);

// Build request helper
const buildRiskRequest = (portfolioId) => {
  return {
    portfolio: {
      portfolio_id: portfolioId || "PORT-001",
      total_value: 524830.00,
      current_drift: 5.2,
      risk_score: 72,
      sharpe_ratio: 1.42,
      volatility: 0.123
    },
    holdings: [
      {
        ticker: "AAPL",
        company_name: "Apple Inc.",
        asset_class: "US Equity",
        quantity: 125,
        current_price: 182.45,
        average_cost: 162.80,
        market_value: 22806.25,
        current_allocation_pct: 4.3,
        beta: 1.2,
        volatility: 0.25
      },
      {
        ticker: "MSFT",
        company_name: "Microsoft Corporation",
        asset_class: "US Equity",
        quantity: 85,
        current_price: 412.30,
        average_cost: 385.60,
        market_value: 35045.50,
        current_allocation_pct: 6.7,
        beta: 1.1,
        volatility: 0.22
      },
      {
        ticker: "BND",
        company_name: "Vanguard Total Bond Market ETF",
        asset_class: "Bonds",
        quantity: 320,
        current_price: 70.25,
        average_cost: 72.10,
        market_value: 22480.00,
        current_allocation_pct: 4.3,
        beta: 0.2,
        volatility: 0.08
      }
    ],
    market_data: {
      vix: 18.5,
      sp500_return_1d: 0.005,
      sp500_return_30d: 0.032,
      treasury_10y: 4.25,
      market_sentiment: "BULLISH"
    }
  };
};

export default RiskAnalysis;
