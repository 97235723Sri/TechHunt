# Team Management MCP Server

A lightweight Team Registration & Management system exposed via MCP (Model Context Protocol), invokable through GitHub Copilot Agent Mode.

---

## Application Overview

This server exposes 5 MCP tools that allow full team and member lifecycle management using natural language prompts in GitHub Copilot Chat — no REST calls needed.

```
GitHub Copilot (Agent Mode)
        |
        | Natural language prompt
        v
   MCP Protocol (stdio)
        |
        v
  Authentication Layer  <-- API Key check on every tool call
        |
        v
   MCP Tool Handlers   <-- createTeam, addMember, updateMember, deleteTeam, listTeams
        |
        v
   Service Layer (storage.py)
        |
        v
  In-Memory Storage    <-- dict { teamName -> Team }
```

---

## Setup & Run

### 1. Install dependencies
```bash
pip install mcp
```

### 2. Run the server
```bash
python server.py
```

### 3. Run unit tests
```bash
python tests.py
```

---

## Authentication

All MCP tools require an `api_key` parameter.

| Setting | Value |
|---------|-------|
| Default API Key | `team-secret-key-2025` |
| Override via env | `MCP_API_KEY=your-key python server.py` |

Every tool call that provides a wrong or missing API key returns:
```json
{"error": "Authentication failed. Invalid API key."}
```

---

## MCP Configuration (mcp.json)

```json
{
  "mcpServers": {
    "team-management": {
      "command": "python",
      "args": ["server.py"],
      "cwd": ".",
      "env": {
        "MCP_API_KEY": "team-secret-key-2025"
      }
    }
  }
}
```

---

## MCP Tools Reference

### createTeam
```
Inputs:  api_key (required), teamName (required), description (optional)
Output:  team object with id, name, description, membersCount
```

### addMember
```
Inputs:  api_key (required), teamName (required), members (array)
         Each member: { name (required), role (optional), email (optional) }
Output:  updated team with all members
```

### updateMember
```
Inputs:  api_key (required), teamName (required)
         memberId OR memberName (required)
         name, role, email (fields to update)
Output:  updated member object
```

### deleteTeam
```
Inputs:  api_key (required), teamName (required)
Output:  confirmation message
```

### listTeams
```
Inputs:  api_key (required), teamName (optional)
Output:  if teamName given → members of that team
         if no teamName   → all teams with member counts
```

---

## Example Copilot Prompts

```
"Create a team called Edgeworks with description AI Financial Tools"

"Add Alice as Developer and Bob as Manager to team Edgeworks"

"Update Alice's role to Senior Developer in team Edgeworks"

"List all teams"

"Show members of team Edgeworks"

"Delete team Edgeworks"
```

---

## Data Model

```
Team
├── id          (auto-generated)
├── name        (unique)
├── description (optional)
└── members[]
      ├── id    (auto-generated)
      ├── name
      ├── role  (optional)
      └── email (optional)
```

---

## Assumptions & Limitations

- Data is stored **in-memory** — all data is lost when server restarts
- No database integration required per spec
- Authentication uses a simple API key — not OAuth/JWT
- No UI or dashboard is provided
- teamName is used as the unique identifier for teams
