"""
storage.py - In-memory storage for teams
"""
from typing import Optional
from models import Team, Member


class TeamStorage:
    """Simple in-memory store for all teams."""

    def __init__(self):
        self._teams: dict[str, Team] = {}  # teamName -> Team

    # ---------- Team Operations ----------

    def create_team(self, name: str, description: Optional[str] = None) -> Team:
        if name in self._teams:
            raise ValueError(f"Team '{name}' already exists.")
        team = Team(name=name, description=description)
        self._teams[name] = team
        return team

    def get_team(self, name: str) -> Team:
        team = self._teams.get(name)
        if not team:
            raise ValueError(f"Team '{name}' does not exist.")
        return team

    def delete_team(self, name: str) -> str:
        self.get_team(name)  # raises if not found
        del self._teams[name]
        return f"Team '{name}' deleted successfully."

    def list_teams(self) -> list[Team]:
        return list(self._teams.values())

    # ---------- Member Operations ----------

    def add_members(self, team_name: str, members_data: list[dict]) -> Team:
        team = self.get_team(team_name)
        for m in members_data:
            if not m.get("name"):
                raise ValueError("Member name cannot be empty.")
            member = Member(
                name=m["name"],
                role=m.get("role"),
                email=m.get("email")
            )
            team.members.append(member)
        return team

    def update_member(self, team_name: str, member_id: str = None,
                      member_name: str = None, updated_fields: dict = {}) -> Member:
        team = self.get_team(team_name)
        member = self._find_member(team, member_id, member_name)
        if "name" in updated_fields and updated_fields["name"]:
            member.name = updated_fields["name"]
        if "role" in updated_fields:
            member.role = updated_fields["role"]
        if "email" in updated_fields:
            member.email = updated_fields["email"]
        return member

    def _find_member(self, team: Team, member_id: str = None,
                     member_name: str = None) -> Member:
        for m in team.members:
            if member_id and m.id == member_id:
                return m
            if member_name and m.name == member_name:
                return m
        raise ValueError(f"Member not found in team '{team.name}'.")


# Global singleton storage instance
storage = TeamStorage()
