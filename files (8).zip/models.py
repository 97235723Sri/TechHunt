"""
models.py - Data models for Team and Member
"""
from dataclasses import dataclass, field
from typing import Optional
import uuid


@dataclass
class Member:
    name: str
    role: Optional[str] = None
    email: Optional[str] = None
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "role": self.role,
            "email": self.email
        }


@dataclass
class Team:
    name: str
    description: Optional[str] = None
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    members: list = field(default_factory=list)

    @property
    def members_count(self):
        return len(self.members)

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "membersCount": self.members_count,
            "members": [m.to_dict() for m in self.members]
        }
