"""
auth.py - Simple API key authentication
"""
import os

# In production, load this from environment variable
# For demo, a hardcoded token is used
VALID_API_KEY = os.environ.get("MCP_API_KEY", "team-secret-key-2025")


def authenticate(api_key: str) -> bool:
    """Returns True if the provided API key is valid."""
    return api_key == VALID_API_KEY


def require_auth(api_key: str):
    """Raises an error if the API key is invalid."""
    if not authenticate(api_key):
        raise PermissionError("Authentication failed. Invalid API key.")
