"""
tests.py - Unit tests for Team Management MCP Server

Run with:
    python -m pytest tests.py -v
    OR
    python tests.py
"""
import unittest
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(__file__))

from models import Team, Member
from storage import TeamStorage
from auth import authenticate, require_auth


class TestAuthentication(unittest.TestCase):
    """Tests for authentication module."""

    def test_valid_api_key(self):
        """Valid API key should return True."""
        self.assertTrue(authenticate("team-secret-key-2025"))

    def test_invalid_api_key(self):
        """Invalid API key should return False."""
        self.assertFalse(authenticate("wrong-key"))

    def test_empty_api_key(self):
        """Empty API key should return False."""
        self.assertFalse(authenticate(""))

    def test_require_auth_raises_on_invalid(self):
        """require_auth should raise PermissionError for invalid key."""
        with self.assertRaises(PermissionError):
            require_auth("bad-key")

    def test_require_auth_passes_on_valid(self):
        """require_auth should not raise for valid key."""
        try:
            require_auth("team-secret-key-2025")
        except PermissionError:
            self.fail("require_auth raised PermissionError for valid key!")


class TestTeamCreation(unittest.TestCase):
    """Tests for team creation operations."""

    def setUp(self):
        """Fresh storage before each test."""
        self.storage = TeamStorage()

    def test_create_team_success(self):
        """Should create a team successfully."""
        team = self.storage.create_team("Alpha", "Alpha team")
        self.assertEqual(team.name, "Alpha")
        self.assertEqual(team.description, "Alpha team")
        self.assertEqual(team.members_count, 0)
        self.assertIsNotNone(team.id)

    def test_create_team_without_description(self):
        """Should create a team with no description."""
        team = self.storage.create_team("Beta")
        self.assertIsNone(team.description)

    def test_create_duplicate_team(self):
        """Should reject duplicate team names."""
        self.storage.create_team("Alpha")
        with self.assertRaises(ValueError):
            self.storage.create_team("Alpha")


class TestTeamDeletion(unittest.TestCase):
    """Tests for team deletion operations."""

    def setUp(self):
        self.storage = TeamStorage()
        self.storage.create_team("DeleteMe")

    def test_delete_existing_team(self):
        """Should delete a team successfully."""
        msg = self.storage.delete_team("DeleteMe")
        self.assertIn("deleted", msg)

    def test_delete_nonexistent_team(self):
        """Should raise error when deleting nonexistent team."""
        with self.assertRaises(ValueError):
            self.storage.delete_team("GhostTeam")

    def test_team_no_longer_exists_after_delete(self):
        """Deleted team should not be retrievable."""
        self.storage.delete_team("DeleteMe")
        with self.assertRaises(ValueError):
            self.storage.get_team("DeleteMe")


class TestMemberAddition(unittest.TestCase):
    """Tests for adding members to teams."""

    def setUp(self):
        self.storage = TeamStorage()
        self.storage.create_team("Gamma")

    def test_add_single_member(self):
        """Should add one member successfully."""
        team = self.storage.add_members("Gamma", [
            {"name": "Alice", "role": "Developer", "email": "alice@test.com"}
        ])
        self.assertEqual(team.members_count, 1)
        self.assertEqual(team.members[0].name, "Alice")

    def test_add_multiple_members(self):
        """Should add multiple members at once."""
        team = self.storage.add_members("Gamma", [
            {"name": "Alice"},
            {"name": "Bob", "role": "Manager"},
            {"name": "Charlie", "email": "charlie@test.com"}
        ])
        self.assertEqual(team.members_count, 3)

    def test_add_member_to_nonexistent_team(self):
        """Should raise error when team does not exist."""
        with self.assertRaises(ValueError):
            self.storage.add_members("GhostTeam", [{"name": "Alice"}])

    def test_add_member_with_empty_name(self):
        """Should reject member with empty name."""
        with self.assertRaises(ValueError):
            self.storage.add_members("Gamma", [{"name": ""}])


class TestMemberUpdate(unittest.TestCase):
    """Tests for updating team members."""

    def setUp(self):
        self.storage = TeamStorage()
        self.storage.create_team("Delta")
        self.storage.add_members("Delta", [
            {"name": "Alice", "role": "Developer", "email": "alice@test.com"}
        ])

    def test_update_member_by_name(self):
        """Should update member using member name."""
        member = self.storage.update_member(
            "Delta",
            member_name="Alice",
            updated_fields={"role": "Senior Developer"}
        )
        self.assertEqual(member.role, "Senior Developer")

    def test_update_member_by_id(self):
        """Should update member using member ID."""
        team = self.storage.get_team("Delta")
        member_id = team.members[0].id
        member = self.storage.update_member(
            "Delta",
            member_id=member_id,
            updated_fields={"email": "newalice@test.com"}
        )
        self.assertEqual(member.email, "newalice@test.com")

    def test_update_nonexistent_member(self):
        """Should raise error for nonexistent member."""
        with self.assertRaises(ValueError):
            self.storage.update_member(
                "Delta",
                member_name="Ghost",
                updated_fields={"role": "Tester"}
            )


class TestListTeams(unittest.TestCase):
    """Tests for listing teams and members."""

    def setUp(self):
        self.storage = TeamStorage()
        self.storage.create_team("Team1", "First team")
        self.storage.create_team("Team2", "Second team")
        self.storage.add_members("Team1", [{"name": "Alice"}, {"name": "Bob"}])

    def test_list_all_teams(self):
        """Should return all teams."""
        teams = self.storage.list_teams()
        self.assertEqual(len(teams), 2)

    def test_list_members_of_team(self):
        """Should return members of a specific team."""
        team = self.storage.get_team("Team1")
        self.assertEqual(team.members_count, 2)

    def test_list_members_of_empty_team(self):
        """Should return empty members list for new team."""
        team = self.storage.get_team("Team2")
        self.assertEqual(team.members_count, 0)


if __name__ == "__main__":
    print("=" * 60)
    print("Running Team Management MCP Server - Unit Tests")
    print("=" * 60)
    unittest.main(verbosity=2)
