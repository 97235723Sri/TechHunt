"""
server.py - MCP Server exposing Team Management tools

Run with:
    pip install mcp
    python server.py

All tools require api_key for authentication.
Default API key: team-secret-key-2025
"""
import json
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp import types

from auth import require_auth
from storage import storage

# Create the MCP server
app = Server("team-management-server")


# ─────────────────────────────────────────────
# TOOL 1: createTeam
# ─────────────────────────────────────────────
@app.tool()
async def createTeam(api_key: str, teamName: str, description: str = "") -> str:
    """
    Create a new team.
    - api_key: required for authentication
    - teamName: name of the team (must be unique)
    - description: optional description
    """
    try:
        require_auth(api_key)
        if not teamName.strip():
            return json.dumps({"error": "teamName cannot be empty."})
        team = storage.create_team(teamName.strip(), description or None)
        return json.dumps({
            "status": "success",
            "message": f"Team '{teamName}' created successfully.",
            "team": {
                "id": team.id,
                "name": team.name,
                "description": team.description,
                "membersCount": team.members_count
            }
        })
    except PermissionError as e:
        return json.dumps({"error": str(e)})
    except ValueError as e:
        return json.dumps({"error": str(e)})


# ─────────────────────────────────────────────
# TOOL 2: addMember
# ─────────────────────────────────────────────
@app.tool()
async def addMember(api_key: str, teamName: str, members: list) -> str:
    """
    Add one or more members to an existing team.
    - api_key: required for authentication
    - teamName: name of the team
    - members: list of member objects [{name, role, email}]
    """
    try:
        require_auth(api_key)
        team = storage.add_members(teamName, members)
        return json.dumps({
            "status": "success",
            "message": f"{len(members)} member(s) added to '{teamName}'.",
            "team": {
                "id": team.id,
                "name": team.name,
                "membersCount": team.members_count,
                "members": [m.to_dict() for m in team.members]
            }
        })
    except PermissionError as e:
        return json.dumps({"error": str(e)})
    except ValueError as e:
        return json.dumps({"error": str(e)})


# ─────────────────────────────────────────────
# TOOL 3: updateMember
# ─────────────────────────────────────────────
@app.tool()
async def updateMember(api_key: str, teamName: str,
                        memberId: str = "", memberName: str = "",
                        name: str = "", role: str = "", email: str = "") -> str:
    """
    Update an existing team member.
    - api_key: required for authentication
    - teamName: name of the team
    - memberId OR memberName: to identify the member
    - name, role, email: fields to update
    """
    try:
        require_auth(api_key)
        if not memberId and not memberName:
            return json.dumps({"error": "Provide either memberId or memberName."})
        updated_fields = {}
        if name:
            updated_fields["name"] = name
        if role:
            updated_fields["role"] = role
        if email:
            updated_fields["email"] = email
        member = storage.update_member(
            teamName,
            member_id=memberId or None,
            member_name=memberName or None,
            updated_fields=updated_fields
        )
        return json.dumps({
            "status": "success",
            "message": "Member updated successfully.",
            "member": member.to_dict()
        })
    except PermissionError as e:
        return json.dumps({"error": str(e)})
    except ValueError as e:
        return json.dumps({"error": str(e)})


# ─────────────────────────────────────────────
# TOOL 4: deleteTeam
# ─────────────────────────────────────────────
@app.tool()
async def deleteTeam(api_key: str, teamName: str) -> str:
    """
    Delete an existing team and all its members.
    - api_key: required for authentication
    - teamName: name of the team to delete
    """
    try:
        require_auth(api_key)
        message = storage.delete_team(teamName)
        return json.dumps({"status": "success", "message": message})
    except PermissionError as e:
        return json.dumps({"error": str(e)})
    except ValueError as e:
        return json.dumps({"error": str(e)})


# ─────────────────────────────────────────────
# TOOL 5: listTeams
# ─────────────────────────────────────────────
@app.tool()
async def listTeams(api_key: str, teamName: str = "") -> str:
    """
    List all teams or members of a specific team.
    - api_key: required for authentication
    - teamName: optional. If provided, returns members of that team.
    """
    try:
        require_auth(api_key)
        if teamName:
            # Return members of a specific team
            team = storage.get_team(teamName)
            return json.dumps({
                "status": "success",
                "team": team.name,
                "membersCount": team.members_count,
                "members": [m.to_dict() for m in team.members]
            })
        else:
            # Return all teams with member counts
            teams = storage.list_teams()
            return json.dumps({
                "status": "success",
                "totalTeams": len(teams),
                "teams": [
                    {"id": t.id, "name": t.name,
                     "description": t.description,
                     "membersCount": t.members_count}
                    for t in teams
                ]
            })
    except PermissionError as e:
        return json.dumps({"error": str(e)})
    except ValueError as e:
        return json.dumps({"error": str(e)})


# ─────────────────────────────────────────────
# Start the server
# ─────────────────────────────────────────────
if __name__ == "__main__":
    import asyncio
    print("Starting Team Management MCP Server...")
    print("API Key: team-secret-key-2025")
    asyncio.run(stdio_server(app))
