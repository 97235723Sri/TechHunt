package com.portfolio.rebalancer.dto;

import lombok.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

// ============================================================================
// SIMULATION DTOs
// ============================================================================

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SimulationRequest {
    @NotBlank(message = "Scenario name is required")
    private String scenarioName;
    
    @NotEmpty(message = "At least one trade is required")
    private List<TradeDTO> trades;
    
    private Map<String, Double> customAllocations;  // Optional
    
    @Builder.Default
    private boolean includeBacktest = false;
    
    @Min(value = 1, message = "Backtest period must be at least 1 month")
    @Max(value = 60, message = "Backtest period cannot exceed 60 months")
    @Builder.Default
    private Integer backtestPeriodMonths = 12;
}

@Data
@Builder
public class SimulationResultDTO {
    private Long simulationId;
    private Long portfolioId;
    private String scenarioName;
    private SimulationMetricsDTO beforeMetrics;
    private SimulationMetricsDTO afterMetrics;
    private ImpactAnalysisDTO impact;
    private CostAnalysisDTO costs;
    private BacktestResultDTO backtest;
    
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    private LocalDateTime createdAt;
}

@Data
@Builder
public class SimulationMetricsDTO {
    private BigDecimal totalValue;
    private BigDecimal drift;
    private Integer riskScore;
    private BigDecimal sharpeRatio;
    private BigDecimal volatility;
    private BigDecimal var95;
    private BigDecimal beta;
    private BigDecimal maxDrawdown;
    private Map<String, BigDecimal> allocations;
}

@Data
@Builder
public class ImpactAnalysisDTO {
    private BigDecimal driftReduction;
    private Integer riskScoreChange;
    private BigDecimal sharpeChange;
    private BigDecimal volatilityChange;
    private BigDecimal varChange;
    private BigDecimal betaChange;
    private Double riskReduction;  // Percentage
}

@Data
@Builder
public class CostAnalysisDTO {
    private BigDecimal tradingFees;
    private BigDecimal bidAskSpread;
    private BigDecimal totalCost;
    private Integer tradesCount;
    private BigDecimal costAsPercentage;
    private Integer breakEvenDays;
}

@Data
@Builder
public class BacktestResultDTO {
    private Integer periodMonths;
    private BigDecimal expectedReturn;
    private BigDecimal sharpeRatio;
    private BigDecimal maxDrawdown;
    private Double winRate;
    private List<MonthlyPerformanceDTO> monthlyPerformance;
}

@Data
@Builder
public class MonthlyPerformanceDTO {
    private String month;
    private BigDecimal return_;
    private BigDecimal benchmarkReturn;
    private BigDecimal alpha;
}

@Data
@Builder
public class CompareRequest {
    @NotEmpty(message = "At least 2 scenarios required for comparison")
    @Size(min = 2, max = 10, message = "Can compare between 2 and 10 scenarios")
    private List<ScenarioRequest> scenarios;
}

@Data
@Builder
public class ScenarioRequest {
    @NotBlank(message = "Scenario name is required")
    private String name;
    
    private List<TradeDTO> trades;
    private Map<String, Double> customAllocations;
}

@Data
@Builder
public class ComparisonResultDTO {
    private List<SimulationResultDTO> scenarios;
    private ComparisonSummaryDTO summary;
    private RecommendedScenarioDTO recommendation;
}

@Data
@Builder
public class ComparisonSummaryDTO {
    private String bestRiskAdjusted;  // Scenario name
    private String bestReturn;
    private String lowestCost;
    private String lowestRisk;
}

@Data
@Builder
public class OptimizationRequest {
    @NotBlank(message = "Optimization objective is required")
    private String objective;  // MAXIMIZE_SHARPE, MINIMIZE_RISK, MAXIMIZE_RETURN
    
    private ConstraintsDTO constraints;
    
    @NotBlank(message = "Risk tolerance is required")
    private String riskTolerance;  // CONSERVATIVE, MODERATE, AGGRESSIVE
}

@Data
@Builder
public class ConstraintsDTO {
    private Double maxSingleAssetPct;
    private Double minBondAllocation;
    private Double maxBondAllocation;
    private Double minEquityAllocation;
    private Double maxEquityAllocation;
    private Double targetVolatility;
    private Double maxDrawdown;
}

@Data
@Builder
public class OptimizedSimulationDTO {
    private SimulationResultDTO simulation;
    private Map<String, Double> optimalAllocations;
    private List<MLInsightDTO> mlInsights;
    private Double confidenceScore;
}

@Data
@Builder
public class ImpactPreviewDTO {
    private BigDecimal driftReduction;
    private BigDecimal estimatedCost;
    private Integer tradesRequired;
    private BigDecimal expectedRiskImprovement;
    private BigDecimal expectedSharpeImprovement;
}

// ============================================================================
// REBALANCING DTOs
// ============================================================================

@Data
@Builder
public class RebalanceRecommendationDTO {
    private String recommendationId;
    private Long portfolioId;
    private BigDecimal currentDrift;
    private BigDecimal targetDrift;
    private String strategy;
    
    private List<TradeRecommendationDTO> sellOrders;
    private List<TradeRecommendationDTO> buyOrders;
    
    private RebalanceSummaryDTO summary;
    private ExpectedImpactDTO expectedImpact;
    private List<MLInsightDTO> mlInsights;
    private List<String> warnings;
    
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    private LocalDateTime generatedAt;
    
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    private LocalDateTime expiresAt;
}

@Data
@Builder
public class TradeRecommendationDTO {
    private String tradeId;
    private String ticker;
    private String companyName;
    private String assetClass;
    private String action;  // BUY, SELL
    
    private Integer currentQuantity;
    private Integer recommendedQuantity;
    private BigDecimal currentPrice;
    private BigDecimal estimatedValue;
    
    private BigDecimal currentAllocation;
    private BigDecimal targetAllocation;
    private BigDecimal drift;
    
    private String reason;
    private String priority;  // LOW, MEDIUM, HIGH, CRITICAL
    
    private BigDecimal taxImpact;
    private String lotSelection;  // FIFO, LIFO, HIFO, SPECIFIC_ID
    private Integer holdingPeriodDays;
}

@Data
@Builder
public class RebalanceSummaryDTO {
    private Integer totalTrades;
    private BigDecimal totalSellValue;
    private BigDecimal totalBuyValue;
    private BigDecimal estimatedFees;
    private BigDecimal netCashFlow;
    private BigDecimal expectedDriftReduction;
    private BigDecimal estimatedTaxImpact;
    private Integer breakEvenDays;
}

@Data
@Builder
public class ExpectedImpactDTO {
    private Integer beforeRisk;
    private Integer afterRisk;
    private Double riskImprovement;
    
    private BigDecimal beforeSharpe;
    private BigDecimal afterSharpe;
    
    private BigDecimal beforeVolatility;
    private BigDecimal afterVolatility;
    
    private BigDecimal beforeVar;
    private BigDecimal afterVar;
}

@Data
@Builder
public class MLInsightDTO {
    private String type;  // TAX_LOSS_HARVESTING, MARKET_TIMING, COST_OPTIMIZATION
    private Integer confidence;  // 0-100
    private String message;
    private BigDecimal potentialSavings;
    private String expectedImpact;
    private List<String> actionItems;
}

@Data
@Builder
public class ExecuteRebalanceRequest {
    @NotBlank(message = "Recommendation ID is required")
    private String recommendationId;
    
    @NotEmpty(message = "At least one trade must be selected")
    private List<TradeExecutionDTO> trades;
    
    @NotBlank(message = "Execution strategy is required")
    private String executionStrategy;  // IMMEDIATE, SCHEDULE, SPREAD_OVER_DAYS
    
    @JsonFormat(pattern = "yyyy-MM-dd")
    private String scheduleDate;
    
    @Builder.Default
    private Boolean validateOnly = false;
}

@Data
@Builder
public class TradeExecutionDTO {
    @NotBlank(message = "Trade ID is required")
    private String tradeId;
    
    @NotBlank(message = "Order type is required")
    private String orderType;  // MARKET, LIMIT, VWAP, TWAP
    
    private BigDecimal limitPrice;
    
    @Builder.Default
    private Boolean execute = true;
}

@Data
@Builder
public class ExecutionResultDTO {
    private String executionId;
    private String status;  // COMPLETED, PARTIAL, FAILED, PENDING
    
    private Integer executedTrades;
    private Integer failedTrades;
    private BigDecimal totalCost;
    
    private List<TradeResultDTO> results;
    
    private BigDecimal newDrift;
    private Integer newRiskScore;
    
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    private LocalDateTime executedAt;
}

@Data
@Builder
public class TradeResultDTO {
    private String tradeId;
    private String ticker;
    private String status;  // SUCCESS, FAILED, PARTIAL
    
    private Integer requestedQuantity;
    private Integer executedQuantity;
    
    private BigDecimal requestedPrice;
    private BigDecimal executedPrice;
    
    private BigDecimal totalValue;
    private BigDecimal fees;
    
    private String errorMessage;
}

@Data
@Builder
public class ScheduleRequest {
    @NotNull(message = "Enabled flag is required")
    private Boolean enabled;
    
    @NotBlank(message = "Frequency is required")
    private String frequency;  // MONTHLY, QUARTERLY, SEMI_ANNUAL, ANNUAL
    
    @JsonFormat(pattern = "yyyy-MM-dd")
    private String nextRunDate;
    
    @DecimalMin(value = "0.0", message = "Drift threshold must be positive")
    @DecimalMax(value = "20.0", message = "Drift threshold cannot exceed 20%")
    private Double driftThreshold;
    
    private String strategy;  // RECOMMENDED, ML_OPTIMIZED, TAX_EFFICIENT
    
    @Builder.Default
    private Boolean autoExecute = false;
    
    @Builder.Default
    private Boolean notifyBeforeExecution = true;
    
    @Builder.Default
    private Integer notificationDays = 3;
}

@Data
@Builder
public class ScheduleConfigDTO {
    private Long scheduleId;
    private Long portfolioId;
    private Boolean enabled;
    private String frequency;
    private String nextRunDate;
    private Double driftThreshold;
    private String strategy;
    private Boolean autoExecute;
    private Boolean notifyBeforeExecution;
    private Integer notificationDays;
    
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    private LocalDateTime createdAt;
    
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    private LocalDateTime updatedAt;
}

@Data
@Builder
public class TaxImpactDTO {
    private BigDecimal totalRealizedGains;
    private BigDecimal totalRealizedLosses;
    private BigDecimal netGains;
    private BigDecimal estimatedTaxLiability;
    private BigDecimal taxRate;
    
    private List<TaxBreakdownDTO> breakdown;
    private List<TaxLossHarvestingDTO> taxLossHarvestingOpportunities;
}

@Data
@Builder
public class TaxBreakdownDTO {
    private String ticker;
    private BigDecimal costBasis;
    private BigDecimal saleProceeds;
    private BigDecimal gain;
    private String holdingPeriod;  // SHORT_TERM, LONG_TERM
    private BigDecimal taxRate;
    private BigDecimal estimatedTax;
}

@Data
@Builder
public class TaxLossHarvestingDTO {
    private String ticker;
    private BigDecimal unrealizedLoss;
    private BigDecimal potentialTaxSavings;
    private List<String> replacementSuggestions;
    private String washSaleRisk;  // NONE, LOW, MEDIUM, HIGH
}

@Data
@Builder
public class ValidationResultDTO {
    private Boolean valid;
    private List<String> errors;
    private List<String> warnings;
    private BigDecimal estimatedImpact;
    private Boolean feasible;
}

@Data
@Builder
public class ExecutionStatusDTO {
    private String executionId;
    private String status;
    private Integer totalTrades;
    private Integer completedTrades;
    private Integer failedTrades;
    private Integer pendingTrades;
    private Double progressPercentage;
    
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    private LocalDateTime startedAt;
    
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    private LocalDateTime estimatedCompletionAt;
}

@Data
@Builder
public class RebalanceHistoryDTO {
    private Long executionId;
    private Long portfolioId;
    private String strategy;
    
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    private LocalDateTime executionDate;
    
    private String status;
    private Integer tradesExecuted;
    
    private BigDecimal driftBefore;
    private BigDecimal driftAfter;
    
    private BigDecimal totalCost;
    private BigDecimal taxImpact;
}

// ============================================================================
// COMMON/SHARED DTOs
// ============================================================================

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TradeDTO {
    @NotBlank(message = "Ticker is required")
    private String ticker;
    
    @NotBlank(message = "Action is required")
    private String action;  // BUY, SELL
    
    @Min(value = 1, message = "Quantity must be at least 1")
    private Integer quantity;
    
    @DecimalMin(value = "0.01", message = "Price must be positive")
    private BigDecimal price;
}

@Data
@Builder
public class SimulationSummaryDTO {
    private Long simulationId;
    private String scenarioName;
    private BigDecimal driftReduction;
    private BigDecimal totalCost;
    
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    private LocalDateTime createdAt;
}

@Data
@Builder
public class RecommendedScenarioDTO {
    private String scenarioName;
    private String reason;
    private Double confidenceScore;
    private List<String> advantages;
    private List<String> considerations;
}

// ============================================================================
// RESPONSE WRAPPERS
// ============================================================================

@Data
@Builder
public class ApiResponse<T> {
    private boolean success;
    private String message;
    private T data;
    private List<String> errors;
    
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    private LocalDateTime timestamp;
}

@Data
@Builder
public class PageResponse<T> {
    private List<T> content;
    private Integer page;
    private Integer size;
    private Long totalElements;
    private Integer totalPages;
    private Boolean last;
}
