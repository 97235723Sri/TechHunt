package com.portfolio.rebalancer.controller;

import com.portfolio.rebalancer.dto.*;
import com.portfolio.rebalancer.service.SimulationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;

/**
 * REST Controller for Portfolio Rebalancing Simulations
 * 
 * Provides comprehensive what-if analysis and scenario comparison
 */
@RestController
@RequestMapping("/api/portfolios/{portfolioId}/simulate")
@RequiredArgsConstructor
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:3001"})
public class SimulationController {

    private final SimulationService simulationService;

    /**
     * Run a rebalancing simulation
     * 
     * POST /api/portfolios/123/simulate
     */
    @PostMapping
    public ResponseEntity<SimulationResultDTO> runSimulation(
            @PathVariable Long portfolioId,
            @Valid @RequestBody SimulationRequest request) {
        SimulationResultDTO result = simulationService.runSimulation(portfolioId, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(result);
    }

    /**
     * Get simulation results by ID
     */
    @GetMapping("/{simulationId}")
    public ResponseEntity<SimulationResultDTO> getSimulation(
            @PathVariable Long portfolioId,
            @PathVariable Long simulationId) {
        SimulationResultDTO result = simulationService.getSimulation(portfolioId, simulationId);
        return ResponseEntity.ok(result);
    }

    /**
     * Compare multiple scenarios
     */
    @PostMapping("/compare")
    public ResponseEntity<ComparisonResultDTO> compareScenarios(
            @PathVariable Long portfolioId,
            @Valid @RequestBody CompareRequest request) {
        ComparisonResultDTO comparison = simulationService.compareScenarios(portfolioId, request);
        return ResponseEntity.ok(comparison);
    }

    /**
     * ML-optimized allocation
     */
    @PostMapping("/optimize")
    public ResponseEntity<OptimizedSimulationDTO> optimizeAllocation(
            @PathVariable Long portfolioId,
            @Valid @RequestBody OptimizationRequest request) {
        OptimizedSimulationDTO result = simulationService.optimizeAllocation(portfolioId, request);
        return ResponseEntity.ok(result);
    }

    /**
     * Quick impact preview (no save)
     */
    @PostMapping("/preview")
    public ResponseEntity<ImpactPreviewDTO> previewImpact(
            @PathVariable Long portfolioId,
            @Valid @RequestBody List<TradeDTO> trades) {
        ImpactPreviewDTO preview = simulationService.previewImpact(portfolioId, trades);
        return ResponseEntity.ok(preview);
    }
}
