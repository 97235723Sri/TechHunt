package com.portfolio.rebalancer.service;

import com.portfolio.rebalancer.dto.*;
import com.portfolio.rebalancer.model.*;
import com.portfolio.rebalancer.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Service for Portfolio Rebalancing Simulations
 * 
 * Provides comprehensive what-if analysis including:
 * - Before/after comparison
 * - Risk metrics impact
 * - Cost analysis
 * - Backtesting
 * - Multi-scenario comparison
 */
@Service
@Slf4j
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class SimulationService {

    private final PortfolioRepository portfolioRepository;
    private final HoldingRepository holdingRepository;
    private final TargetAllocationRepository targetAllocationRepository;
    private final SimulationRepository simulationRepository;
    private final RiskCalculationService riskCalculationService;
    private final MLRecommendationService mlRecommendationService;
    
    /**
     * Run a rebalancing simulation
     */
    @Transactional
    public SimulationResultDTO runSimulation(Long portfolioId, SimulationRequest request) {
        log.info("Running simulation for portfolio {}: {}", portfolioId, request.getScenarioName());
        
        // Validate portfolio exists
        Portfolio portfolio = portfolioRepository.findById(portfolioId)
            .orElseThrow(() -> new ResourceNotFoundException("Portfolio not found"));
        
        // Get current state
        List<Holding> currentHoldings = holdingRepository.findByPortfolioId(portfolioId);
        PortfolioSnapshot beforeSnapshot = createSnapshot(portfolio, currentHoldings);
        
        // Apply trades to create simulated state
        List<Holding> simulatedHoldings = applyTrades(currentHoldings, request.getTrades());
        
        // Apply custom allocations if provided
        if (request.getCustomAllocations() != null && !request.getCustomAllocations().isEmpty()) {
            simulatedHoldings = applyCustomAllocations(
                simulatedHoldings, 
                portfolio.getTotalValue(), 
                request.getCustomAllocations()
            );
        }
        
        // Calculate after state
        PortfolioSnapshot afterSnapshot = createSnapshot(portfolio, simulatedHoldings);
        
        // Calculate impact
        ImpactAnalysis impact = calculateImpact(beforeSnapshot, afterSnapshot);
        
        // Calculate costs
        CostAnalysis costs = calculateCosts(request.getTrades());
        
        // Run backtest if requested
        BacktestResult backtest = null;
        if (request.isIncludeBacktest()) {
            backtest = runBacktest(portfolio, simulatedHoldings, request.getBacktestPeriodMonths());
        }
        
        // Create and save simulation
        Simulation simulation = createSimulation(
            portfolio, request, beforeSnapshot, afterSnapshot, impact, costs, backtest);
        simulation = simulationRepository.save(simulation);
        
        // Build response
        return buildSimulationResult(simulation, beforeSnapshot, afterSnapshot, impact, costs, backtest);
    }
    
    /**
     * Get existing simulation
     */
    public SimulationResultDTO getSimulation(Long portfolioId, Long simulationId) {
        Simulation simulation = simulationRepository.findByIdAndPortfolioId(simulationId, portfolioId)
            .orElseThrow(() -> new ResourceNotFoundException("Simulation not found"));
        
        return convertToDTO(simulation);
    }
    
    /**
     * Compare multiple scenarios
     */
    public ComparisonResultDTO compareScenarios(Long portfolioId, CompareRequest request) {
        log.info("Comparing {} scenarios for portfolio {}", request.getScenarios().size(), portfolioId);
        
        List<SimulationResultDTO> scenarios = new ArrayList<>();
        
        for (ScenarioRequest scenario : request.getScenarios()) {
            SimulationRequest simRequest = new SimulationRequest();
            simRequest.setScenarioName(scenario.getName());
            simRequest.setTrades(scenario.getTrades());
            simRequest.setCustomAllocations(scenario.getCustomAllocations());
            simRequest.setIncludeBacktest(false); // Skip for comparison
            
            SimulationResultDTO result = runSimulation(portfolioId, simRequest);
            scenarios.add(result);
        }
        
        // Build comparison
        return buildComparison(scenarios);
    }
    
    /**
     * ML-optimized allocation
     */
    public OptimizedSimulationDTO optimizeAllocation(Long portfolioId, OptimizationRequest request) {
        log.info("Optimizing allocation for portfolio {} with objective: {}", 
            portfolioId, request.getObjective());
        
        Portfolio portfolio = portfolioRepository.findById(portfolioId)
            .orElseThrow(() -> new ResourceNotFoundException("Portfolio not found"));
        
        List<Holding> currentHoldings = holdingRepository.findByPortfolioId(portfolioId);
        
        // Use ML service to find optimal allocation
        OptimizationResult mlResult = mlRecommendationService.optimizeAllocation(
            portfolio, currentHoldings, request);
        
        // Run simulation with optimized allocation
        SimulationRequest simRequest = new SimulationRequest();
        simRequest.setScenarioName("ML-Optimized: " + request.getObjective());
        simRequest.setTrades(mlResult.getRecommendedTrades());
        simRequest.setCustomAllocations(mlResult.getOptimalAllocations());
        simRequest.setIncludeBacktest(true);
        simRequest.setBacktestPeriodMonths(12);
        
        SimulationResultDTO simulation = runSimulation(portfolioId, simRequest);
        
        // Build optimized result
        return buildOptimizedResult(simulation, mlResult);
    }
    
    /**
     * Quick preview without saving
     */
    public ImpactPreviewDTO previewImpact(Long portfolioId, List<TradeDTO> trades) {
        Portfolio portfolio = portfolioRepository.findById(portfolioId)
            .orElseThrow(() -> new ResourceNotFoundException("Portfolio not found"));
        
        List<Holding> currentHoldings = holdingRepository.findByPortfolioId(portfolioId);
        PortfolioSnapshot before = createSnapshot(portfolio, currentHoldings);
        
        List<Holding> simulatedHoldings = applyTrades(currentHoldings, trades);
        PortfolioSnapshot after = createSnapshot(portfolio, simulatedHoldings);
        
        ImpactAnalysis impact = calculateImpact(before, after);
        CostAnalysis costs = calculateCosts(trades);
        
        return buildImpactPreview(impact, costs);
    }
    
    // ========================================================================
    // PRIVATE HELPER METHODS
    // ========================================================================
    
    private PortfolioSnapshot createSnapshot(Portfolio portfolio, List<Holding> holdings) {
        BigDecimal totalValue = holdings.stream()
            .map(h -> h.getCurrentPrice().multiply(BigDecimal.valueOf(h.getQuantity())))
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        // Calculate allocations
        Map<String, BigDecimal> allocations = calculateAllocations(holdings, totalValue);
        
        // Calculate drift
        BigDecimal drift = calculateDrift(portfolio.getId(), allocations);
        
        // Calculate risk metrics
        RiskMetrics risk = riskCalculationService.calculateRisk(holdings);
        
        return PortfolioSnapshot.builder()
            .totalValue(totalValue)
            .holdings(holdings)
            .allocations(allocations)
            .drift(drift)
            .riskScore(risk.getRiskScore())
            .sharpeRatio(risk.getSharpeRatio())
            .volatility(risk.getVolatility())
            .var95(risk.getVar95())
            .beta(risk.getBeta())
            .maxDrawdown(risk.getMaxDrawdown())
            .build();
    }
    
    private List<Holding> applyTrades(List<Holding> currentHoldings, List<TradeDTO> trades) {
        // Create mutable copy
        Map<String, Holding> holdingMap = currentHoldings.stream()
            .collect(Collectors.toMap(Holding::getTicker, h -> h.copy()));
        
        for (TradeDTO trade : trades) {
            Holding holding = holdingMap.get(trade.getTicker());
            
            if (trade.getAction().equals("BUY")) {
                if (holding != null) {
                    holding.setQuantity(holding.getQuantity() + trade.getQuantity());
                } else {
                    // New position
                    holding = Holding.builder()
                        .ticker(trade.getTicker())
                        .quantity(trade.getQuantity())
                        .currentPrice(trade.getPrice())
                        .build();
                    holdingMap.put(trade.getTicker(), holding);
                }
            } else if (trade.getAction().equals("SELL")) {
                if (holding != null) {
                    holding.setQuantity(Math.max(0, holding.getQuantity() - trade.getQuantity()));
                    if (holding.getQuantity() == 0) {
                        holdingMap.remove(trade.getTicker());
                    }
                }
            }
        }
        
        return new ArrayList<>(holdingMap.values());
    }
    
    private Map<String, BigDecimal> calculateAllocations(List<Holding> holdings, BigDecimal totalValue) {
        Map<String, BigDecimal> allocations = new HashMap<>();
        
        for (Holding holding : holdings) {
            BigDecimal value = holding.getCurrentPrice()
                .multiply(BigDecimal.valueOf(holding.getQuantity()));
            BigDecimal percentage = value.divide(totalValue, 4, RoundingMode.HALF_UP)
                .multiply(BigDecimal.valueOf(100));
            
            String assetClass = holding.getAssetClass();
            allocations.merge(assetClass, percentage, BigDecimal::add);
        }
        
        return allocations;
    }
    
    private BigDecimal calculateDrift(Long portfolioId, Map<String, BigDecimal> currentAllocations) {
        List<TargetAllocation> targets = targetAllocationRepository.findByPortfolioId(portfolioId);
        
        BigDecimal totalDrift = BigDecimal.ZERO;
        
        for (TargetAllocation target : targets) {
            BigDecimal current = currentAllocations.getOrDefault(
                target.getAssetClass(), BigDecimal.ZERO);
            BigDecimal drift = current.subtract(target.getTargetPercentage()).abs();
            totalDrift = totalDrift.add(drift);
        }
        
        return totalDrift.divide(BigDecimal.valueOf(targets.size()), 2, RoundingMode.HALF_UP);
    }
    
    private ImpactAnalysis calculateImpact(PortfolioSnapshot before, PortfolioSnapshot after) {
        return ImpactAnalysis.builder()
            .driftReduction(before.getDrift().subtract(after.getDrift()))
            .riskScoreChange(after.getRiskScore() - before.getRiskScore())
            .sharpeChange(after.getSharpeRatio().subtract(before.getSharpeRatio()))
            .volatilityChange(after.getVolatility().subtract(before.getVolatility()))
            .varChange(after.getVar95().subtract(before.getVar95()))
            .betaChange(after.getBeta().subtract(before.getBeta()))
            .build();
    }
    
    private CostAnalysis calculateCosts(List<TradeDTO> trades) {
        BigDecimal totalFees = BigDecimal.ZERO;
        BigDecimal totalSpread = BigDecimal.ZERO;
        
        for (TradeDTO trade : trades) {
            // Assume $7 per trade + 0.02% spread
            BigDecimal tradeFee = BigDecimal.valueOf(7);
            BigDecimal tradeValue = trade.getPrice()
                .multiply(BigDecimal.valueOf(trade.getQuantity()));
            BigDecimal spreadCost = tradeValue.multiply(BigDecimal.valueOf(0.0002));
            
            totalFees = totalFees.add(tradeFee);
            totalSpread = totalSpread.add(spreadCost);
        }
        
        return CostAnalysis.builder()
            .tradingFees(totalFees)
            .bidAskSpread(totalSpread)
            .totalCost(totalFees.add(totalSpread))
            .tradesCount(trades.size())
            .build();
    }
    
    private BacktestResult runBacktest(Portfolio portfolio, List<Holding> holdings, int months) {
        // Simplified backtest - in production, use historical price data
        return mlRecommendationService.runBacktest(portfolio, holdings, months);
    }
    
    private SimulationResultDTO buildSimulationResult(
            Simulation simulation,
            PortfolioSnapshot before,
            PortfolioSnapshot after,
            ImpactAnalysis impact,
            CostAnalysis costs,
            BacktestResult backtest) {
        
        return SimulationResultDTO.builder()
            .simulationId(simulation.getId())
            .portfolioId(simulation.getPortfolioId())
            .scenarioName(simulation.getScenarioName())
            .beforeMetrics(convertSnapshotToMetrics(before))
            .afterMetrics(convertSnapshotToMetrics(after))
            .impact(impact)
            .costs(costs)
            .backtest(backtest)
            .createdAt(simulation.getCreatedAt())
            .build();
    }
    
    private SimulationMetricsDTO convertSnapshotToMetrics(PortfolioSnapshot snapshot) {
        return SimulationMetricsDTO.builder()
            .totalValue(snapshot.getTotalValue())
            .drift(snapshot.getDrift())
            .riskScore(snapshot.getRiskScore())
            .sharpeRatio(snapshot.getSharpeRatio())
            .volatility(snapshot.getVolatility())
            .var95(snapshot.getVar95())
            .beta(snapshot.getBeta())
            .maxDrawdown(snapshot.getMaxDrawdown())
            .allocations(snapshot.getAllocations())
            .build();
    }
}
