# Smart Portfolio Rebalancer - Complete API Package

## 📦 Package Contents

This package contains comprehensive API code for **Simulation** and **Rebalancing Recommendations** features.

---

## 🏗️ Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                        REST Controllers                     │
├─────────────────────────────────────────────────────────────┤
│  SimulationController  │  RebalanceController               │
│  - runSimulation()     │  - getRecommendations()            │
│  - compareScenarios()  │  - executeRebalance()              │
│  - optimizeAllocation()│  - scheduleRebalancing()           │
│  - previewImpact()     │  - calculateTaxImpact()            │
└──────────────┬───────────────────────┬───────────────────────┘
               │                       │
               ▼                       ▼
┌─────────────────────────────────────────────────────────────┐
│                      Service Layer                          │
├─────────────────────────────────────────────────────────────┤
│  SimulationService     │  RebalanceService                  │
│  - createSnapshot()    │  - generateRecommendations()       │
│  - calculateImpact()   │  - optimizeTrades()                │
│  - runBacktest()       │  - calculateTaxImpact()            │
│  - applyTrades()       │  - validateTrades()                │
├─────────────────────────────────────────────────────────────┤
│  RiskCalculationService │ MLRecommendationService           │
│  TaxOptimizationService │ ExecutionService                  │
└──────────────┬────────────────────────────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────────────────────────┐
│                      Data Layer                             │
├─────────────────────────────────────────────────────────────┤
│  Repositories: Portfolio, Holding, TargetAllocation,        │
│                Simulation, RebalanceHistory                 │
└─────────────────────────────────────────────────────────────┘
```

---

## 📁 Files Included

### Controllers (2 files)
1. **SimulationController.java** - Simulation endpoints
2. **RebalanceController.java** - Rebalancing endpoints

### Services (6 files)
3. **SimulationService.java** - Core simulation logic
4. **RebalanceService.java** - Rebalancing recommendation logic
5. **RiskCalculationService.java** - Risk metrics calculation
6. **MLRecommendationService.java** - ML-driven insights
7. **TaxOptimizationService.java** - Tax-efficient rebalancing
8. **ExecutionService.java** - Trade execution management

### DTOs (20+ files)
9. **SimulationRequest.java**
10. **SimulationResultDTO.java**
11. **ComparisonResultDTO.java**
12. **OptimizationRequest.java**
13. **RebalanceRecommendationDTO.java**
14. **TradeRecommendationDTO.java**
15. **ExecuteRebalanceRequest.java**
16. **TaxImpactDTO.java**
... (see DTO_REFERENCE.md for complete list)

### Models (4 files)
- **Simulation.java**
- **RebalanceHistory.java**
- **TradeExecution.java**
- **ScheduleConfig.java**

---

## 🚀 API Endpoints Summary

### Simulation APIs

#### 1. Run Simulation
```http
POST /api/portfolios/{portfolioId}/simulate
Content-Type: application/json

{
  "scenarioName": "Conservative Rebalance",
  "trades": [
    {"ticker": "AAPL", "action": "SELL", "quantity": 28, "price": 182.45},
    {"ticker": "BND", "action": "BUY", "quantity": 78, "price": 70.25}
  ],
  "customAllocations": {
    "US Equity": 25.0,
    "Bonds": 35.0
  },
  "includeBacktest": true,
  "backtestPeriodMonths": 12
}
```

**Response:**
```json
{
  "simulationId": 456,
  "portfolioId": 123,
  "scenarioName": "Conservative Rebalance",
  "beforeMetrics": {
    "totalValue": 524830.00,
    "drift": 5.2,
    "riskScore": 72,
    "sharpeRatio": 1.42,
    "volatility": 12.3,
    "var95": -2.3,
    "beta": 0.98
  },
  "afterMetrics": {
    "totalValue": 524746.00,
    "drift": 0.3,
    "riskScore": 84,
    "sharpeRatio": 1.58,
    "volatility": 10.8,
    "var95": -1.8,
    "beta": 0.94
  },
  "impact": {
    "driftReduction": 4.9,
    "riskScoreChange": 12,
    "sharpeChange": 0.16,
    "volatilityChange": -1.5,
    "riskReduction": 15.0
  },
  "costs": {
    "tradingFees": 84.00,
    "bidAskSpread": 42.00,
    "totalCost": 126.00
  },
  "backtest": {
    "periodMonths": 12,
    "expectedReturn": 8.7,
    "sharpeRatio": 1.58,
    "maxDrawdown": -6.2,
    "winRate": 68.5
  },
  "createdAt": "2026-02-12T15:30:00Z"
}
```

#### 2. Compare Scenarios
```http
POST /api/portfolios/{portfolioId}/simulate/compare

{
  "scenarios": [
    {
      "name": "Recommended",
      "trades": [...]
    },
    {
      "name": "Aggressive", 
      "customAllocations": {"US Equity": 40, "Bonds": 20}
    }
  ]
}
```

#### 3. ML-Optimized Simulation
```http
POST /api/portfolios/{portfolioId}/simulate/optimize

{
  "objective": "MAXIMIZE_SHARPE",
  "constraints": {
    "maxSingleAssetPct": 15.0,
    "minBondAllocation": 20.0
  },
  "riskTolerance": "MODERATE"
}
```

#### 4. Quick Preview
```http
POST /api/portfolios/{portfolioId}/simulate/preview

[
  {"ticker": "AAPL", "action": "SELL", "quantity": 28},
  {"ticker": "BND", "action": "BUY", "quantity": 78}
]
```

---

### Rebalancing APIs

#### 1. Get Recommendations
```http
GET /api/portfolios/{portfolioId}/rebalance/recommendations
    ?strategy=ML_OPTIMIZED
    &considerTaxes=true
```

**Response:**
```json
{
  "recommendationId": "rec-456",
  "portfolioId": 123,
  "currentDrift": 5.2,
  "targetDrift": 0.0,
  "strategy": "ML_OPTIMIZED",
  "sellOrders": [
    {
      "tradeId": "trade-1",
      "ticker": "AAPL",
      "companyName": "Apple Inc.",
      "action": "SELL",
      "currentQuantity": 125,
      "recommendedQuantity": 28,
      "currentPrice": 182.45,
      "estimatedValue": 5108.60,
      "currentAllocation": 4.3,
      "targetAllocation": 3.0,
      "drift": 1.3,
      "reason": "Overweight - reduce to target allocation",
      "priority": "HIGH",
      "taxImpact": -423.75
    }
  ],
  "buyOrders": [
    {
      "tradeId": "trade-2",
      "ticker": "BND",
      "companyName": "Vanguard Total Bond Market ETF",
      "action": "BUY",
      "recommendedQuantity": 78,
      "currentPrice": 70.25,
      "estimatedValue": 5479.50,
      "currentAllocation": 4.3,
      "targetAllocation": 6.0,
      "drift": -1.7,
      "reason": "Underweight - increase bond exposure",
      "priority": "HIGH"
    }
  ],
  "summary": {
    "totalTrades": 12,
    "totalSellValue": 78234.50,
    "totalBuyValue": 78150.00,
    "estimatedFees": 84.00,
    "netCashFlow": 0.00,
    "expectedDriftReduction": 5.2,
    "estimatedTaxImpact": -1250.00,
    "breakEvenDays": 38
  },
  "expectedImpact": {
    "beforeRisk": 72,
    "afterRisk": 84,
    "riskImprovement": 16.7,
    "beforeSharpe": 1.42,
    "afterSharpe": 1.58,
    "beforeVolatility": 12.3,
    "afterVolatility": 10.8
  },
  "mlInsights": [
    {
      "type": "TAX_LOSS_HARVESTING",
      "confidence": 87,
      "message": "Consider selling TSLA at a loss (-$850) and replacing with similar tech exposure",
      "potentialSavings": 297.50
    },
    {
      "type": "MARKET_TIMING",
      "confidence": 72,
      "message": "VIX elevated at 28.5 - consider delaying equity sales by 2-3 days",
      "expectedImpact": "Reduce transaction costs by ~$150"
    }
  ],
  "warnings": [],
  "generatedAt": "2026-02-12T15:30:00Z",
  "expiresAt": "2026-02-12T17:30:00Z"
}
```

#### 2. Execute Rebalancing
```http
POST /api/portfolios/{portfolioId}/rebalance/execute

{
  "recommendationId": "rec-456",
  "trades": [
    {
      "tradeId": "trade-1",
      "orderType": "MARKET",
      "execute": true
    }
  ],
  "executionStrategy": "IMMEDIATE",
  "validateOnly": false
}
```

#### 3. Schedule Automatic Rebalancing
```http
POST /api/portfolios/{portfolioId}/rebalance/schedule

{
  "enabled": true,
  "frequency": "QUARTERLY",
  "nextRunDate": "2026-03-01",
  "driftThreshold": 5.0,
  "strategy": "ML_OPTIMIZED",
  "autoExecute": false,
  "notifyBeforeExecution": true
}
```

#### 4. Calculate Tax Impact
```http
GET /api/portfolios/{portfolioId}/rebalance/tax-impact
    ?recommendationId=rec-456
```

**Response:**
```json
{
  "totalRealizedGains": 2118.75,
  "totalRealizedLosses": -816.00,
  "netGains": 1302.75,
  "estimatedTaxLiability": -456.46,
  "taxRate": 35.0,
  "breakdown": [
    {
      "ticker": "AAPL",
      "costBasis": 20687.50,
      "saleProceeds": 22806.25,
      "gain": 2118.75,
      "holdingPeriod": "LONG_TERM",
      "taxRate": 20.0,
      "estimatedTax": -423.75
    }
  ],
  "taxLossHarvestingOpportunities": [
    {
      "ticker": "TSLA",
      "unrealizedLoss": -850.00,
      "potentialTaxSavings": 297.50,
      "replacementSuggestions": ["QQQ", "VGT"]
    }
  ]
}
```

---

## 🔧 Configuration

### application.yml
```yaml
portfolio:
  rebalancer:
    simulation:
      max-scenarios: 10
      cache-results: true
      cache-ttl-minutes: 30
    
    rebalancing:
      default-strategy: RECOMMENDED
      default-drift-threshold: 5.0
      consider-taxes: true
      
    trading:
      default-order-type: MARKET
      fee-per-trade: 7.00
      spread-percentage: 0.02
      
    ml:
      enabled: true
      model-endpoint: http://ml-service:8080
      confidence-threshold: 0.70
      
    tax:
      default-tax-rate: 0.35
      long-term-capital-gains-rate: 0.20
      short-term-capital-gains-rate: 0.35
```

---

## 📊 Use Cases & Examples

### Use Case 1: What-If Analysis
**Scenario:** User wants to see impact of selling tech stocks and buying bonds

```bash
curl -X POST http://localhost:8080/api/portfolios/123/simulate \
  -H "Content-Type: application/json" \
  -d '{
    "scenarioName": "Reduce Tech Exposure",
    "trades": [
      {"ticker": "AAPL", "action": "SELL", "quantity": 50},
      {"ticker": "MSFT", "action": "SELL", "quantity": 40},
      {"ticker": "BND", "action": "BUY", "quantity": 150}
    ],
    "includeBacktest": true
  }'
```

### Use Case 2: ML-Optimized Rebalancing
**Scenario:** Let ML determine optimal allocation for max Sharpe ratio

```bash
curl -X POST http://localhost:8080/api/portfolios/123/simulate/optimize \
  -H "Content-Type: application/json" \
  -d '{
    "objective": "MAXIMIZE_SHARPE",
    "constraints": {
      "maxSingleAssetPct": 15.0,
      "minBondAllocation": 25.0
    },
    "riskTolerance": "MODERATE"
  }'
```

### Use Case 3: Tax-Efficient Rebalancing
**Scenario:** Get recommendations that minimize tax impact

```bash
curl "http://localhost:8080/api/portfolios/123/rebalance/recommendations?strategy=TAX_EFFICIENT&considerTaxes=true"
```

### Use Case 4: Scheduled Rebalancing
**Scenario:** Auto-rebalance quarterly when drift > 5%

```bash
curl -X POST http://localhost:8080/api/portfolios/123/rebalance/schedule \
  -H "Content-Type: application/json" \
  -d '{
    "enabled": true,
    "frequency": "QUARTERLY",
    "driftThreshold": 5.0,
    "strategy": "ML_OPTIMIZED",
    "autoExecute": false,
    "notifyBeforeExecution": true,
    "notificationDays": 3
  }'
```

---

## 🧪 Testing

### Unit Tests
```java
@Test
void testRunSimulation() {
    // Given
    SimulationRequest request = SimulationRequest.builder()
        .scenarioName("Test")
        .trades(List.of(
            TradeDTO.builder()
                .ticker("AAPL")
                .action("SELL")
                .quantity(10)
                .build()
        ))
        .build();
    
    // When
    SimulationResultDTO result = simulationService.runSimulation(123L, request);
    
    // Then
    assertNotNull(result.getSimulationId());
    assertTrue(result.getImpact().getDriftReduction() > 0);
}
```

### Integration Tests
```java
@SpringBootTest
@AutoConfigureMockMvc
class RebalanceControllerIT {
    
    @Test
    void shouldGetRecommendations() throws Exception {
        mockMvc.perform(get("/api/portfolios/123/rebalance/recommendations"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.sellOrders").isArray())
            .andExpect(jsonPath("$.buyOrders").isArray());
    }
}
```

---

## 📈 Performance Considerations

### Caching Strategy
- Simulation results: 30 minutes
- Recommendations: 2 hours (or until portfolio changes)
- Tax calculations: 1 hour

### Async Processing
- Long-running simulations (>5 scenarios) → async
- Backtesting → async with progress updates
- ML optimization → async

### Database Indexes
```sql
CREATE INDEX idx_simulation_portfolio_created 
  ON simulations(portfolio_id, created_at DESC);

CREATE INDEX idx_rebalance_history_portfolio 
  ON rebalance_history(portfolio_id, execution_date DESC);
```

---

## 🔐 Security

### Authentication
- All endpoints require JWT token
- User can only access own portfolios

### Authorization
- Portfolio ownership validation
- Trade execution requires additional confirmation

### Rate Limiting
- Simulations: 20 per hour per user
- Executions: 5 per hour per portfolio

---

## 📚 Related Documentation

- **API_REFERENCE.md** - Complete API documentation
- **DTO_REFERENCE.md** - All DTO schemas
- **SERVICE_GUIDE.md** - Service layer documentation
- **DEPLOYMENT.md** - Deployment instructions

---

## ✅ Production Checklist

- [ ] Configure ML service endpoint
- [ ] Set up tax rate configuration
- [ ] Enable caching (Redis recommended)
- [ ] Configure async executor thread pool
- [ ] Set up monitoring (Prometheus metrics)
- [ ] Configure rate limiting
- [ ] Enable audit logging
- [ ] Set up alerts for failed executions

---

**Package Version:** 1.0  
**Last Updated:** February 2026  
**Compatibility:** Spring Boot 3.2+, Java 17+
