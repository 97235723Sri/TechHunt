package com.portfolio.rebalancer.controller;

import com.portfolio.rebalancer.dto.*;
import com.portfolio.rebalancer.service.RebalanceService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;

/**
 * REST Controller for Portfolio Rebalancing Recommendations
 * 
 * Endpoints:
 * - GET  /api/portfolios/{portfolioId}/rebalance/recommendations - Get rebalancing recommendations
 * - POST /api/portfolios/{portfolioId}/rebalance/execute - Execute rebalancing trades
 * - GET  /api/portfolios/{portfolioId}/rebalance/history - Get rebalancing history
 * - POST /api/portfolios/{portfolioId}/rebalance/schedule - Schedule automatic rebalancing
 * - GET  /api/portfolios/{portfolioId}/rebalance/tax-impact - Calculate tax impact
 */
@RestController
@RequestMapping("/api/portfolios/{portfolioId}/rebalance")
@RequiredArgsConstructor
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:3001"})
public class RebalanceController {

    private final RebalanceService rebalanceService;

    /**
     * Get comprehensive rebalancing recommendations
     * 
     * GET /api/portfolios/123/rebalance/recommendations?strategy=ML_OPTIMIZED
     * 
     * Query Parameters:
     * - strategy: RECOMMENDED (default), ML_OPTIMIZED, TAX_EFFICIENT, COST_MINIMIZED
     * - driftThreshold: Override default threshold (optional)
     * - considerTaxes: true/false (default: true)
     * 
     * Response:
     * {
     *   "recommendationId": "rec-456",
     *   "portfolioId": 123,
     *   "currentDrift": 5.2,
     *   "targetDrift": 0.0,
     *   "strategy": "ML_OPTIMIZED",
     *   "sellOrders": [...],
     *   "buyOrders": [...],
     *   "summary": {
     *     "totalTrades": 12,
     *     "totalSellValue": 78234.50,
     *     "totalBuyValue": 78150.00,
     *     "estimatedFees": 84.00,
     *     "netCashFlow": 0.00,
     *     "expectedDriftReduction": 5.2,
     *     "estimatedTaxImpact": -1250.00
     *   },
     *   "expectedImpact": {
     *     "beforeRisk": 72,
     *     "afterRisk": 84,
     *     "beforeSharpe": 1.42,
     *     "afterSharpe": 1.58,
     *     "beforeVolatility": 12.3,
     *     "afterVolatility": 10.8,
     *     "riskReduction": 15.0
     *   },
     *   "mlInsights": [...],
     *   "warnings": [],
     *   "generatedAt": "2026-02-12T15:30:00Z"
     * }
     */
    @GetMapping("/recommendations")
    public ResponseEntity<RebalanceRecommendationDTO> getRecommendations(
            @PathVariable Long portfolioId,
            @RequestParam(required = false, defaultValue = "RECOMMENDED") String strategy,
            @RequestParam(required = false) Double driftThreshold,
            @RequestParam(required = false, defaultValue = "true") Boolean considerTaxes) {
        
        RebalanceRecommendationDTO recommendations = rebalanceService.getRecommendations(
            portfolioId, strategy, driftThreshold, considerTaxes);
        return ResponseEntity.ok(recommendations);
    }

    /**
     * Get detailed breakdown of individual trades
     * 
     * GET /api/portfolios/123/rebalance/trades?strategy=ML_OPTIMIZED
     * 
     * Response includes detailed analysis for each recommended trade
     */
    @GetMapping("/trades")
    public ResponseEntity<List<TradeRecommendationDTO>> getTradeDetails(
            @PathVariable Long portfolioId,
            @RequestParam(required = false, defaultValue = "RECOMMENDED") String strategy) {
        
        List<TradeRecommendationDTO> trades = rebalanceService.getTradeDetails(
            portfolioId, strategy);
        return ResponseEntity.ok(trades);
    }

    /**
     * Execute rebalancing trades
     * 
     * POST /api/portfolios/123/rebalance/execute
     * 
     * Request Body:
     * {
     *   "recommendationId": "rec-456",  // From recommendations endpoint
     *   "trades": [
     *     {
     *       "tradeId": "trade-1",
     *       "ticker": "AAPL",
     *       "action": "SELL",
     *       "quantity": 28,
     *       "orderType": "MARKET",  // MARKET, LIMIT, VWAP, TWAP
     *       "limitPrice": null,
     *       "execute": true  // false to skip this trade
     *     }
     *   ],
     *   "executionStrategy": "IMMEDIATE",  // IMMEDIATE, SCHEDULE, SPREAD_OVER_DAYS
     *   "scheduleDate": null,
     *   "validateOnly": false  // Set true for dry-run
     * }
     * 
     * Response:
     * {
     *   "executionId": "exec-789",
     *   "status": "COMPLETED",
     *   "executedTrades": 12,
     *   "failedTrades": 0,
     *   "totalCost": 84.50,
     *   "results": [...],
     *   "newDrift": 0.3,
     *   "executedAt": "2026-02-12T15:45:00Z"
     * }
     */
    @PostMapping("/execute")
    public ResponseEntity<ExecutionResultDTO> executeRebalance(
            @PathVariable Long portfolioId,
            @Valid @RequestBody ExecuteRebalanceRequest request) {
        
        ExecutionResultDTO result = rebalanceService.executeRebalance(portfolioId, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(result);
    }

    /**
     * Get rebalancing history
     * 
     * GET /api/portfolios/123/rebalance/history?limit=10&status=COMPLETED
     */
    @GetMapping("/history")
    public ResponseEntity<List<RebalanceHistoryDTO>> getHistory(
            @PathVariable Long portfolioId,
            @RequestParam(required = false, defaultValue = "10") Integer limit,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String fromDate,
            @RequestParam(required = false) String toDate) {
        
        List<RebalanceHistoryDTO> history = rebalanceService.getHistory(
            portfolioId, limit, status, fromDate, toDate);
        return ResponseEntity.ok(history);
    }

    /**
     * Schedule automatic rebalancing
     * 
     * POST /api/portfolios/123/rebalance/schedule
     * 
     * Request Body:
     * {
     *   "enabled": true,
     *   "frequency": "QUARTERLY",  // MONTHLY, QUARTERLY, SEMI_ANNUAL, ANNUAL
     *   "nextRunDate": "2026-03-01",
     *   "driftThreshold": 5.0,
     *   "strategy": "ML_OPTIMIZED",
     *   "autoExecute": false,  // If false, just generates recommendations
     *   "notifyBeforeExecution": true,
     *   "notificationDays": 3
     * }
     */
    @PostMapping("/schedule")
    public ResponseEntity<ScheduleConfigDTO> scheduleRebalancing(
            @PathVariable Long portfolioId,
            @Valid @RequestBody ScheduleRequest request) {
        
        ScheduleConfigDTO config = rebalanceService.scheduleRebalancing(portfolioId, request);
        return ResponseEntity.ok(config);
    }

    /**
     * Get current rebalancing schedule
     * 
     * GET /api/portfolios/123/rebalance/schedule
     */
    @GetMapping("/schedule")
    public ResponseEntity<ScheduleConfigDTO> getSchedule(@PathVariable Long portfolioId) {
        ScheduleConfigDTO config = rebalanceService.getSchedule(portfolioId);
        return ResponseEntity.ok(config);
    }

    /**
     * Update rebalancing schedule
     * 
     * PUT /api/portfolios/123/rebalance/schedule
     */
    @PutMapping("/schedule")
    public ResponseEntity<ScheduleConfigDTO> updateSchedule(
            @PathVariable Long portfolioId,
            @Valid @RequestBody ScheduleRequest request) {
        
        ScheduleConfigDTO config = rebalanceService.updateSchedule(portfolioId, request);
        return ResponseEntity.ok(config);
    }

    /**
     * Delete rebalancing schedule
     * 
     * DELETE /api/portfolios/123/rebalance/schedule
     */
    @DeleteMapping("/schedule")
    public ResponseEntity<Void> deleteSchedule(@PathVariable Long portfolioId) {
        rebalanceService.deleteSchedule(portfolioId);
        return ResponseEntity.noContent().build();
    }

    /**
     * Calculate tax impact of rebalancing
     * 
     * GET /api/portfolios/123/rebalance/tax-impact?recommendationId=rec-456
     * 
     * Response:
     * {
     *   "totalRealizedGains": 2118.75,
     *   "totalRealizedLosses": -816.00,
     *   "netGains": 1302.75,
     *   "estimatedTaxLiability": -456.46,
     *   "taxRate": 35.0,
     *   "breakdown": [
     *     {
     *       "ticker": "AAPL",
     *       "costBasis": 20687.50,
     *       "saleProceeds": 22806.25,
     *       "gain": 2118.75,
     *       "holdingPeriod": "LONG_TERM",
     *       "taxRate": 20.0
     *     }
     *   ],
     *   "taxLossHarvestingOpportunities": [...]
     * }
     */
    @GetMapping("/tax-impact")
    public ResponseEntity<TaxImpactDTO> calculateTaxImpact(
            @PathVariable Long portfolioId,
            @RequestParam(required = false) String recommendationId,
            @RequestParam(required = false) List<Long> tradeIds) {
        
        TaxImpactDTO impact = rebalanceService.calculateTaxImpact(
            portfolioId, recommendationId, tradeIds);
        return ResponseEntity.ok(impact);
    }

    /**
     * Get ML insights for rebalancing
     * 
     * GET /api/portfolios/123/rebalance/ml-insights
     * 
     * Response includes:
     * - Market timing recommendations
     * - Tax-loss harvesting opportunities
     * - Cost optimization suggestions
     * - Risk-adjusted rebalancing strategies
     */
    @GetMapping("/ml-insights")
    public ResponseEntity<MLInsightsDTO> getMLInsights(@PathVariable Long portfolioId) {
        MLInsightsDTO insights = rebalanceService.getMLInsights(portfolioId);
        return ResponseEntity.ok(insights);
    }

    /**
     * Validate rebalancing trades before execution
     * 
     * POST /api/portfolios/123/rebalance/validate
     * 
     * Request Body:
     * {
     *   "trades": [...]
     * }
     * 
     * Response includes warnings, errors, and feasibility check
     */
    @PostMapping("/validate")
    public ResponseEntity<ValidationResultDTO> validateTrades(
            @PathVariable Long portfolioId,
            @Valid @RequestBody List<TradeDTO> trades) {
        
        ValidationResultDTO validation = rebalanceService.validateTrades(portfolioId, trades);
        return ResponseEntity.ok(validation);
    }

    /**
     * Cancel a pending rebalancing execution
     * 
     * POST /api/portfolios/123/rebalance/{executionId}/cancel
     */
    @PostMapping("/{executionId}/cancel")
    public ResponseEntity<ExecutionResultDTO> cancelExecution(
            @PathVariable Long portfolioId,
            @PathVariable Long executionId) {
        
        ExecutionResultDTO result = rebalanceService.cancelExecution(portfolioId, executionId);
        return ResponseEntity.ok(result);
    }

    /**
     * Get status of ongoing execution
     * 
     * GET /api/portfolios/123/rebalance/{executionId}/status
     */
    @GetMapping("/{executionId}/status")
    public ResponseEntity<ExecutionStatusDTO> getExecutionStatus(
            @PathVariable Long portfolioId,
            @PathVariable Long executionId) {
        
        ExecutionStatusDTO status = rebalanceService.getExecutionStatus(portfolioId, executionId);
        return ResponseEntity.ok(status);
    }
}
