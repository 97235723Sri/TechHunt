"""
Tax Analysis & Optimization ML Service
Integrates with Portfolio Rebalancer for tax-efficient trading
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Dict, Optional
import numpy as np
from datetime import datetime, timedelta
import uuid

app = FastAPI(title="Tax Analysis & Optimization Service")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =============================================================================
# DATA MODELS
# =============================================================================

class TaxLot(BaseModel):
    lot_id: str
    ticker: str
    quantity: float
    purchase_price: float
    purchase_date: str
    holding_period_days: int
    unrealized_gain: float
    unrealized_gain_pct: float
    tax_status: str  # "Short Term" or "Long Term"

class TradeTaxImpact(BaseModel):
    ticker: str
    action: str  # BUY, SELL
    quantity: int
    estimated_proceeds: float
    cost_basis: float
    capital_gain: float
    tax_rate: float
    estimated_tax: float
    tax_status: str
    holding_period: int
    tax_efficiency_score: float

class TaxLossHarvesting(BaseModel):
    ticker: str
    current_position: float
    unrealized_loss: float
    tax_savings: float
    replacement_ticker: Optional[str]
    wash_sale_risk: bool
    recommended_action: str
    confidence: float

class TaxBracket(BaseModel):
    bracket_name: str
    income_min: float
    income_max: float
    rate_short_term: float
    rate_long_term: float
    rate_qualified_dividends: float

class TaxAnalysisRequest(BaseModel):
    portfolio_id: str
    user_id: str
    tax_lots: List[TaxLot]
    proposed_trades: List[Dict]
    annual_income: float
    filing_status: str  # "Single", "Married Filing Jointly", "Head of Household"
    state: str
    investment_account_type: str  # "Taxable", "IRA", "Roth IRA", "401k"

class TaxOptimizationStrategy(BaseModel):
    strategy_name: str
    description: str
    estimated_tax_savings: float
    trades_required: List[Dict]
    implementation_steps: List[str]
    confidence: float
    priority: str

class TaxAnalysisResponse(BaseModel):
    analysis_id: str
    portfolio_id: str
    timestamp: str
    
    # Current Tax Status
    current_unrealized_gains: float
    current_unrealized_losses: float
    short_term_gains: float
    long_term_gains: float
    
    # Trade Impact Analysis
    trade_tax_impacts: List[TradeTaxImpact]
    total_estimated_tax: float
    tax_efficiency_score: float
    
    # Tax Loss Harvesting
    tlh_opportunities: List[TaxLossHarvesting]
    potential_tax_savings: float
    
    # Optimization Strategies
    optimization_strategies: List[TaxOptimizationStrategy]
    recommended_strategy: str
    
    # Tax Bracket Analysis
    current_tax_bracket: TaxBracket
    marginal_rate: float
    effective_rate: float
    
    # Recommendations
    recommendations: List[str]
    warnings: List[str]

# =============================================================================
# TAX ANALYSIS ENGINE
# =============================================================================

class TaxAnalyzer:
    """ML-powered tax analysis and optimization"""
    
    def __init__(self):
        self.federal_tax_brackets_2026 = self._initialize_tax_brackets()
        self.state_tax_rates = self._initialize_state_rates()
        
    def _initialize_tax_brackets(self) -> Dict:
        """2026 Federal Tax Brackets"""
        return {
            "Single": [
                {"min": 0, "max": 11600, "rate": 0.10},
                {"min": 11600, "max": 47150, "rate": 0.12},
                {"min": 47150, "max": 100525, "rate": 0.22},
                {"min": 100525, "max": 191950, "rate": 0.24},
                {"min": 191950, "max": 243725, "rate": 0.32},
                {"min": 243725, "max": 609350, "rate": 0.35},
                {"min": 609350, "max": float('inf'), "rate": 0.37}
            ],
            "Married Filing Jointly": [
                {"min": 0, "max": 23200, "rate": 0.10},
                {"min": 23200, "max": 94300, "rate": 0.12},
                {"min": 94300, "max": 201050, "rate": 0.22},
                {"min": 201050, "max": 383900, "rate": 0.24},
                {"min": 383900, "max": 487450, "rate": 0.32},
                {"min": 487450, "max": 731200, "rate": 0.35},
                {"min": 731200, "max": float('inf'), "rate": 0.37}
            ]
        }
    
    def _initialize_state_rates(self) -> Dict:
        """State capital gains tax rates"""
        return {
            "CA": 0.133,  # California
            "NY": 0.109,  # New York
            "TX": 0.0,    # Texas (no state income tax)
            "FL": 0.0,    # Florida (no state income tax)
            "WA": 0.07,   # Washington (capital gains tax)
            "SG": 0.0,    # Singapore (for your location)
            "DEFAULT": 0.05
        }
    
    def analyze(self, request: TaxAnalysisRequest) -> TaxAnalysisResponse:
        """Comprehensive tax analysis"""
        
        # Skip tax analysis for tax-advantaged accounts
        if request.investment_account_type in ["IRA", "Roth IRA", "401k", "529"]:
            return self._tax_advantaged_response(request)
        
        # Calculate current tax status
        current_status = self._calculate_current_tax_status(request.tax_lots)
        
        # Analyze trade impacts
        trade_impacts = self._analyze_trade_tax_impact(
            request.proposed_trades,
            request.tax_lots,
            request.annual_income,
            request.filing_status,
            request.state
        )
        
        # Find tax loss harvesting opportunities
        tlh_opportunities = self._find_tlh_opportunities(request.tax_lots)
        
        # Generate optimization strategies
        strategies = self._generate_optimization_strategies(
            request.tax_lots,
            trade_impacts,
            tlh_opportunities,
            request.annual_income,
            request.filing_status
        )
        
        # Determine tax bracket
        tax_bracket = self._determine_tax_bracket(
            request.annual_income,
            request.filing_status
        )
        
        # Calculate rates
        marginal_rate = self._calculate_marginal_rate(
            request.annual_income,
            request.filing_status,
            request.state
        )
        
        effective_rate = self._calculate_effective_rate(
            request.annual_income,
            request.filing_status
        )
        
        # Generate recommendations
        recommendations = self._generate_recommendations(
            current_status,
            trade_impacts,
            tlh_opportunities,
            strategies
        )
        
        warnings = self._generate_warnings(trade_impacts, current_status)
        
        # Calculate total estimated tax
        total_tax = sum(t.estimated_tax for t in trade_impacts)
        
        # Calculate potential savings
        potential_savings = sum(t.tax_savings for t in tlh_opportunities)
        
        # Tax efficiency score (0-100)
        tax_efficiency = self._calculate_tax_efficiency_score(
            trade_impacts,
            tlh_opportunities,
            current_status
        )
        
        return TaxAnalysisResponse(
            analysis_id=str(uuid.uuid4()),
            portfolio_id=request.portfolio_id,
            timestamp=datetime.now().isoformat(),
            current_unrealized_gains=current_status['unrealized_gains'],
            current_unrealized_losses=current_status['unrealized_losses'],
            short_term_gains=current_status['short_term_gains'],
            long_term_gains=current_status['long_term_gains'],
            trade_tax_impacts=trade_impacts,
            total_estimated_tax=total_tax,
            tax_efficiency_score=tax_efficiency,
            tlh_opportunities=tlh_opportunities,
            potential_tax_savings=potential_savings,
            optimization_strategies=strategies,
            recommended_strategy=strategies[0].strategy_name if strategies else "None",
            current_tax_bracket=tax_bracket,
            marginal_rate=marginal_rate,
            effective_rate=effective_rate,
            recommendations=recommendations,
            warnings=warnings
        )
    
    def _calculate_current_tax_status(self, tax_lots: List[TaxLot]) -> Dict:
        """Calculate current unrealized gains/losses"""
        
        unrealized_gains = sum(lot.unrealized_gain for lot in tax_lots if lot.unrealized_gain > 0)
        unrealized_losses = sum(lot.unrealized_gain for lot in tax_lots if lot.unrealized_gain < 0)
        
        short_term_gains = sum(
            lot.unrealized_gain for lot in tax_lots 
            if lot.unrealized_gain > 0 and lot.tax_status == "Short Term"
        )
        
        long_term_gains = sum(
            lot.unrealized_gain for lot in tax_lots 
            if lot.unrealized_gain > 0 and lot.tax_status == "Long Term"
        )
        
        return {
            'unrealized_gains': unrealized_gains,
            'unrealized_losses': unrealized_losses,
            'short_term_gains': short_term_gains,
            'long_term_gains': long_term_gains
        }
    
    def _analyze_trade_tax_impact(
        self,
        trades: List[Dict],
        tax_lots: List[TaxLot],
        income: float,
        filing_status: str,
        state: str
    ) -> List[TradeTaxImpact]:
        """Analyze tax impact of proposed trades"""
        
        impacts = []
        
        for trade in trades:
            if trade['action'] != 'SELL':
                continue  # Only SELL trades have immediate tax impact
            
            ticker = trade['ticker']
            quantity = abs(trade['quantity'])
            current_price = trade.get('current_price', 0)
            
            # Find matching tax lots using FIFO
            lots = [lot for lot in tax_lots if lot.ticker == ticker]
            lots.sort(key=lambda x: x.purchase_date)  # FIFO
            
            remaining_qty = quantity
            total_proceeds = quantity * current_price
            total_cost_basis = 0
            is_long_term = True
            
            for lot in lots:
                if remaining_qty <= 0:
                    break
                
                qty_from_lot = min(remaining_qty, lot.quantity)
                total_cost_basis += qty_from_lot * lot.purchase_price
                
                if lot.tax_status == "Short Term":
                    is_long_term = False
                
                remaining_qty -= qty_from_lot
            
            capital_gain = total_proceeds - total_cost_basis
            
            # Determine tax rate
            if is_long_term:
                federal_rate = self._get_long_term_cap_gains_rate(income, filing_status)
                tax_status = "Long Term"
            else:
                federal_rate = self._get_marginal_rate(income, filing_status)
                tax_status = "Short Term"
            
            state_rate = self.state_tax_rates.get(state, self.state_tax_rates["DEFAULT"])
            combined_rate = federal_rate + state_rate
            
            estimated_tax = capital_gain * combined_rate if capital_gain > 0 else 0
            
            # Tax efficiency score (higher is better)
            efficiency_score = 100 - (combined_rate * 100)
            if capital_gain < 0:
                efficiency_score = 100  # Losses are tax-efficient
            
            impacts.append(TradeTaxImpact(
                ticker=ticker,
                action="SELL",
                quantity=quantity,
                estimated_proceeds=total_proceeds,
                cost_basis=total_cost_basis,
                capital_gain=capital_gain,
                tax_rate=combined_rate,
                estimated_tax=estimated_tax,
                tax_status=tax_status,
                holding_period=365 if is_long_term else 180,  # Approximation
                tax_efficiency_score=efficiency_score
            ))
        
        return impacts
    
    def _find_tlh_opportunities(self, tax_lots: List[TaxLot]) -> List[TaxLossHarvesting]:
        """Find tax loss harvesting opportunities"""
        
        opportunities = []
        
        # Group by ticker
        by_ticker = {}
        for lot in tax_lots:
            if lot.ticker not in by_ticker:
                by_ticker[lot.ticker] = []
            by_ticker[lot.ticker].append(lot)
        
        # Find losers
        for ticker, lots in by_ticker.items():
            total_unrealized = sum(lot.unrealized_gain for lot in lots)
            
            if total_unrealized < -1000:  # Minimum $1,000 loss threshold
                total_position = sum(lot.quantity for lot in lots)
                
                # Estimate tax savings
                # Assume 35% short-term rate (conservative)
                tax_savings = abs(total_unrealized) * 0.35
                
                # Suggest replacement ticker (simplified)
                replacement = self._suggest_replacement(ticker)
                
                # Check wash sale risk
                wash_sale_risk = False  # Would need to check recent purchase history
                
                opportunities.append(TaxLossHarvesting(
                    ticker=ticker,
                    current_position=total_position,
                    unrealized_loss=total_unrealized,
                    tax_savings=tax_savings,
                    replacement_ticker=replacement,
                    wash_sale_risk=wash_sale_risk,
                    recommended_action=f"Sell {ticker}, buy {replacement}",
                    confidence=0.85
                ))
        
        # Sort by tax savings
        opportunities.sort(key=lambda x: x.tax_savings, reverse=True)
        
        return opportunities
    
    def _generate_optimization_strategies(
        self,
        tax_lots: List[TaxLot],
        trade_impacts: List[TradeTaxImpact],
        tlh_opportunities: List[TaxLossHarvesting],
        income: float,
        filing_status: str
    ) -> List[TaxOptimizationStrategy]:
        """Generate tax optimization strategies"""
        
        strategies = []
        
        # Strategy 1: Tax Loss Harvesting
        if tlh_opportunities:
            total_savings = sum(t.tax_savings for t in tlh_opportunities[:3])
            
            strategies.append(TaxOptimizationStrategy(
                strategy_name="Tax Loss Harvesting",
                description=f"Harvest {len(tlh_opportunities)} losses to offset gains",
                estimated_tax_savings=total_savings,
                trades_required=[
                    {
                        "action": "SELL",
                        "ticker": opp.ticker,
                        "reason": "Harvest loss"
                    } for opp in tlh_opportunities[:3]
                ],
                implementation_steps=[
                    "1. Sell losing positions",
                    "2. Wait 31 days to avoid wash sale",
                    "3. Repurchase or buy replacement securities"
                ],
                confidence=0.90,
                priority="HIGH"
            ))
        
        # Strategy 2: Long-term holding
        short_term_lots = [lot for lot in tax_lots if lot.tax_status == "Short Term"]
        if short_term_lots:
            strategies.append(TaxOptimizationStrategy(
                strategy_name="Delay Sales for Long-Term Treatment",
                description=f"Hold {len(short_term_lots)} positions 31+ more days",
                estimated_tax_savings=5000.0,  # Estimated
                trades_required=[],
                implementation_steps=[
                    "1. Delay selling short-term positions",
                    "2. Wait for long-term capital gains treatment (1 year+)",
                    "3. Save 15-20% in taxes"
                ],
                confidence=0.95,
                priority="MEDIUM"
            ))
        
        # Strategy 3: Strategic lot selection
        if any(t.capital_gain > 0 for t in trade_impacts):
            strategies.append(TaxOptimizationStrategy(
                strategy_name="Specific Lot Identification",
                description="Sell high-basis lots first to minimize gains",
                estimated_tax_savings=2500.0,
                trades_required=[],
                implementation_steps=[
                    "1. Use 'Specific Identification' instead of FIFO",
                    "2. Sell highest cost-basis shares first",
                    "3. Defer gains to future years"
                ],
                confidence=0.85,
                priority="MEDIUM"
            ))
        
        # Strategy 4: Offset gains with losses
        total_gains = sum(t.capital_gain for t in trade_impacts if t.capital_gain > 0)
        total_losses = sum(abs(t.unrealized_loss) for t in tlh_opportunities)
        
        if total_gains > 0 and total_losses > 0:
            offset_amount = min(total_gains, total_losses)
            tax_savings = offset_amount * 0.35  # Conservative rate
            
            strategies.append(TaxOptimizationStrategy(
                strategy_name="Offset Gains with Losses",
                description=f"Offset ${offset_amount:,.0f} in gains with losses",
                estimated_tax_savings=tax_savings,
                trades_required=[],
                implementation_steps=[
                    "1. Realize gains from profitable positions",
                    "2. Simultaneously harvest losses",
                    "3. Net capital gain = $0, tax = $0"
                ],
                confidence=0.95,
                priority="HIGH"
            ))
        
        # Sort by savings
        strategies.sort(key=lambda x: x.estimated_tax_savings, reverse=True)
        
        return strategies
    
    def _determine_tax_bracket(self, income: float, filing_status: str) -> TaxBracket:
        """Determine current tax bracket"""
        
        brackets = self.federal_tax_brackets_2026.get(filing_status, 
                                                       self.federal_tax_brackets_2026["Single"])
        
        for bracket in brackets:
            if income >= bracket['min'] and income < bracket['max']:
                # Long-term cap gains rates
                if income < 44625:  # Single
                    ltcg_rate = 0.0
                elif income < 492300:
                    ltcg_rate = 0.15
                else:
                    ltcg_rate = 0.20
                
                return TaxBracket(
                    bracket_name=f"{int(bracket['rate']*100)}% Bracket",
                    income_min=bracket['min'],
                    income_max=bracket['max'],
                    rate_short_term=bracket['rate'],
                    rate_long_term=ltcg_rate,
                    rate_qualified_dividends=ltcg_rate
                )
        
        # Default to highest bracket
        return TaxBracket(
            bracket_name="37% Bracket",
            income_min=609350,
            income_max=float('inf'),
            rate_short_term=0.37,
            rate_long_term=0.20,
            rate_qualified_dividends=0.20
        )
    
    def _calculate_marginal_rate(self, income: float, filing_status: str, state: str) -> float:
        """Calculate marginal tax rate"""
        federal = self._get_marginal_rate(income, filing_status)
        state_rate = self.state_tax_rates.get(state, self.state_tax_rates["DEFAULT"])
        return federal + state_rate
    
    def _get_marginal_rate(self, income: float, filing_status: str) -> float:
        """Get federal marginal rate"""
        brackets = self.federal_tax_brackets_2026.get(filing_status,
                                                       self.federal_tax_brackets_2026["Single"])
        
        for bracket in brackets:
            if income >= bracket['min'] and income < bracket['max']:
                return bracket['rate']
        
        return brackets[-1]['rate']
    
    def _get_long_term_cap_gains_rate(self, income: float, filing_status: str) -> float:
        """Get long-term capital gains rate"""
        # 2026 LTCG thresholds
        if filing_status == "Single":
            if income < 44625:
                return 0.0
            elif income < 492300:
                return 0.15
            else:
                return 0.20
        else:  # Married Filing Jointly
            if income < 89250:
                return 0.0
            elif income < 553850:
                return 0.15
            else:
                return 0.20
    
    def _calculate_effective_rate(self, income: float, filing_status: str) -> float:
        """Calculate effective tax rate"""
        brackets = self.federal_tax_brackets_2026.get(filing_status,
                                                       self.federal_tax_brackets_2026["Single"])
        
        total_tax = 0
        remaining_income = income
        
        for bracket in brackets:
            if remaining_income <= 0:
                break
            
            bracket_width = bracket['max'] - bracket['min']
            taxable_in_bracket = min(remaining_income, bracket_width)
            
            total_tax += taxable_in_bracket * bracket['rate']
            remaining_income -= taxable_in_bracket
        
        return total_tax / income if income > 0 else 0
    
    def _suggest_replacement(self, ticker: str) -> str:
        """Suggest replacement ticker (simplified)"""
        replacements = {
            "SPY": "VOO",
            "QQQ": "VGT",
            "VTI": "ITOT",
            "VWO": "IEMG",
            "VEA": "IEFA"
        }
        return replacements.get(ticker, "CASH")
    
    def _calculate_tax_efficiency_score(
        self,
        trade_impacts: List[TradeTaxImpact],
        tlh_opportunities: List[TaxLossHarvesting],
        current_status: Dict
    ) -> float:
        """Calculate overall tax efficiency score (0-100)"""
        
        # Start at 100
        score = 100.0
        
        # Penalty for high tax trades
        for trade in trade_impacts:
            if trade.estimated_tax > 1000:
                score -= min(trade.estimated_tax / 1000, 20)
        
        # Bonus for TLH opportunities utilized
        if tlh_opportunities:
            score += min(len(tlh_opportunities) * 5, 15)
        
        # Penalty for short-term gains
        if current_status['short_term_gains'] > 0:
            score -= 10
        
        return max(0, min(100, score))
    
    def _generate_recommendations(
        self,
        current_status: Dict,
        trade_impacts: List[TradeTaxImpact],
        tlh_opportunities: List[TaxLossHarvesting],
        strategies: List[TaxOptimizationStrategy]
    ) -> List[str]:
        """Generate tax recommendations"""
        
        recommendations = []
        
        # High tax impact warning
        total_tax = sum(t.estimated_tax for t in trade_impacts)
        if total_tax > 5000:
            recommendations.append(
                f"⚠️ High tax liability: ${total_tax:,.0f}. Consider tax optimization strategies."
            )
        
        # TLH opportunities
        if tlh_opportunities:
            total_savings = sum(t.tax_savings for t in tlh_opportunities[:3])
            recommendations.append(
                f"💰 Tax Loss Harvesting: Potential savings of ${total_savings:,.0f}"
            )
        
        # Short-term vs long-term
        if current_status['short_term_gains'] > 5000:
            recommendations.append(
                f"⏰ Consider holding short-term positions longer for preferential long-term rates"
            )
        
        # Top strategy
        if strategies:
            top_strategy = strategies[0]
            recommendations.append(
                f"✅ Recommended: {top_strategy.strategy_name} - "
                f"Save ${top_strategy.estimated_tax_savings:,.0f}"
            )
        
        return recommendations
    
    def _generate_warnings(
        self,
        trade_impacts: List[TradeTaxImpact],
        current_status: Dict
    ) -> List[str]:
        """Generate tax warnings"""
        
        warnings = []
        
        # Large single trade tax
        for trade in trade_impacts:
            if trade.estimated_tax > 10000:
                warnings.append(
                    f"Large tax liability on {trade.ticker}: ${trade.estimated_tax:,.0f}"
                )
        
        # Year-end timing
        current_date = datetime.now()
        if current_date.month >= 11:
            warnings.append(
                "Year-end approaching - consider tax impact of timing trades"
            )
        
        # Short-term gains
        if current_status['short_term_gains'] > 10000:
            warnings.append(
                f"Significant short-term gains: ${current_status['short_term_gains']:,.0f} "
                f"taxed at ordinary income rates"
            )
        
        return warnings
    
    def _tax_advantaged_response(self, request: TaxAnalysisRequest) -> TaxAnalysisResponse:
        """Response for tax-advantaged accounts"""
        
        return TaxAnalysisResponse(
            analysis_id=str(uuid.uuid4()),
            portfolio_id=request.portfolio_id,
            timestamp=datetime.now().isoformat(),
            current_unrealized_gains=0,
            current_unrealized_losses=0,
            short_term_gains=0,
            long_term_gains=0,
            trade_tax_impacts=[],
            total_estimated_tax=0,
            tax_efficiency_score=100,
            tlh_opportunities=[],
            potential_tax_savings=0,
            optimization_strategies=[],
            recommended_strategy="N/A - Tax-Advantaged Account",
            current_tax_bracket=TaxBracket(
                bracket_name="N/A",
                income_min=0,
                income_max=0,
                rate_short_term=0,
                rate_long_term=0,
                rate_qualified_dividends=0
            ),
            marginal_rate=0,
            effective_rate=0,
            recommendations=[
                f"✅ {request.investment_account_type}: No immediate tax consequences",
                "💡 Trades are tax-free within this account",
                "📊 Focus on investment strategy, not tax optimization"
            ],
            warnings=[]
        )

# =============================================================================
# API ENDPOINTS
# =============================================================================

analyzer = TaxAnalyzer()

@app.get("/")
async def root():
    return {
        "service": "Tax Analysis & Optimization Service",
        "version": "1.0.0",
        "features": [
            "Tax Impact Analysis",
            "Tax Loss Harvesting",
            "Optimization Strategies",
            "Tax Bracket Analysis"
        ]
    }

@app.post("/api/tax/analyze", response_model=TaxAnalysisResponse)
async def analyze_tax(request: TaxAnalysisRequest):
    """
    Comprehensive tax analysis for proposed trades
    """
    try:
        result = analyzer.analyze(request)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/tax/quick-estimate")
async def quick_tax_estimate(
    capital_gain: float,
    holding_period_days: int,
    annual_income: float,
    filing_status: str = "Single"
):
    """Quick tax estimate for a single trade"""
    
    try:
        bracket = analyzer._determine_tax_bracket(annual_income, filing_status)
        
        if holding_period_days >= 365:
            tax_rate = bracket.rate_long_term
            status = "Long Term"
        else:
            tax_rate = bracket.rate_short_term
            status = "Short Term"
        
        estimated_tax = max(0, capital_gain * tax_rate)
        
        return {
            "capital_gain": capital_gain,
            "holding_period": holding_period_days,
            "tax_status": status,
            "tax_rate": tax_rate,
            "estimated_tax": estimated_tax,
            "after_tax_gain": capital_gain - estimated_tax
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    print("Starting Tax Analysis & Optimization Service...")
    uvicorn.run(app, host="0.0.0.0", port=5002, log_level="info")
