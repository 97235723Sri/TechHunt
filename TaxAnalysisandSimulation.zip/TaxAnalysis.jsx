import React, { useState, useEffect } from 'react';
import './TaxAnalysis.css';

const API_URL = process.env.REACT_APP_TAX_API_URL || 'http://localhost:5002';

const TaxAnalysis = ({ portfolioId }) => {
  const [taxData, setTaxData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [selectedTab, setSelectedTab] = useState('overview');

  useEffect(() => {
    if (portfolioId) {
      fetchTaxAnalysis();
    }
  }, [portfolioId]);

  const fetchTaxAnalysis = async () => {
    setLoading(true);
    try {
      const requestData = buildTaxRequest(portfolioId);
      
      const response = await fetch(`${API_URL}/api/tax/analyze`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestData)
      });

      const data = await response.json();
      setTaxData(data);
    } catch (error) {
      console.error('Error fetching tax analysis:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <LoadingState />;
  }

  if (!taxData) {
    return <EmptyState onAnalyze={fetchTaxAnalysis} />;
  }

  return (
    <div className="tax-analysis">
      {/* Header */}
      <TaxHeader taxData={taxData} />

      {/* Navigation Tabs */}
      <TaxTabs selectedTab={selectedTab} setSelectedTab={setSelectedTab} />

      {/* Content */}
      {selectedTab === 'overview' && <OverviewTab taxData={taxData} />}
      {selectedTab === 'trades' && <TradeImpactTab taxData={taxData} />}
      {selectedTab === 'harvesting' && <TaxLossHarvestingTab taxData={taxData} />}
      {selectedTab === 'strategies' && <OptimizationTab taxData={taxData} />}
    </div>
  );
};

// ============================================================================
// HEADER COMPONENT
// ============================================================================

const TaxHeader = ({ taxData }) => {
  const getEfficiencyColor = (score) => {
    if (score >= 80) return '#2ecc71';
    if (score >= 60) return '#f39c12';
    return '#e74c3c';
  };

  return (
    <div className="tax-header">
      <div className="header-content">
        <h1>
          <span className="icon">💰</span>
          Tax Analysis & Optimization
        </h1>
        <p className="subtitle">ML-powered tax-efficient trading recommendations</p>
      </div>
      
      <div className="tax-summary-cards">
        <div className="tax-card">
          <div className="card-label">Estimated Tax Liability</div>
          <div className="card-value tax-liability">
            ${taxData.total_estimated_tax.toLocaleString()}
          </div>
        </div>
        
        <div className="tax-card">
          <div className="card-label">Potential Savings</div>
          <div className="card-value tax-savings">
            ${taxData.potential_tax_savings.toLocaleString()}
          </div>
        </div>
        
        <div className="tax-card">
          <div className="card-label">Tax Efficiency Score</div>
          <div className="card-value" style={{ color: getEfficiencyColor(taxData.tax_efficiency_score) }}>
            {taxData.tax_efficiency_score.toFixed(0)}/100
          </div>
          <div className="efficiency-bar">
            <div 
              className="efficiency-fill"
              style={{ 
                width: `${taxData.tax_efficiency_score}%`,
                backgroundColor: getEfficiencyColor(taxData.tax_efficiency_score)
              }}
            ></div>
          </div>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// TABS COMPONENT
// ============================================================================

const TaxTabs = ({ selectedTab, setSelectedTab }) => {
  const tabs = [
    { id: 'overview', label: 'Overview', icon: '📋' },
    { id: 'trades', label: 'Trade Impact', icon: '💸' },
    { id: 'harvesting', label: 'Tax Loss Harvesting', icon: '🌾' },
    { id: 'strategies', label: 'Optimization', icon: '🎯' }
  ];

  return (
    <div className="tax-tabs">
      {tabs.map(tab => (
        <button
          key={tab.id}
          className={`tab ${selectedTab === tab.id ? 'active' : ''}`}
          onClick={() => setSelectedTab(tab.id)}
        >
          <span className="tab-icon">{tab.icon}</span>
          <span className="tab-label">{tab.label}</span>
        </button>
      ))}
    </div>
  );
};

// ============================================================================
// OVERVIEW TAB
// ============================================================================

const OverviewTab = ({ taxData }) => {
  return (
    <div className="overview-tab">
      {/* Current Tax Status */}
      <div className="section-card">
        <h3>📊 Current Tax Status</h3>
        <div className="tax-status-grid">
          <StatusMetric 
            label="Unrealized Gains"
            value={taxData.current_unrealized_gains}
            positive={true}
          />
          <StatusMetric 
            label="Unrealized Losses"
            value={taxData.current_unrealized_losses}
            positive={false}
          />
          <StatusMetric 
            label="Short-Term Gains"
            value={taxData.short_term_gains}
            positive={true}
            warning={taxData.short_term_gains > 10000}
          />
          <StatusMetric 
            label="Long-Term Gains"
            value={taxData.long_term_gains}
            positive={true}
          />
        </div>
      </div>

      {/* Tax Bracket */}
      <div className="section-card">
        <h3>🎚️ Your Tax Bracket</h3>
        <div className="tax-bracket-info">
          <div className="bracket-name">{taxData.current_tax_bracket.bracket_name}</div>
          <div className="rates-grid">
            <div className="rate-item">
              <span className="rate-label">Short-Term Rate:</span>
              <span className="rate-value">{(taxData.current_tax_bracket.rate_short_term * 100).toFixed(1)}%</span>
            </div>
            <div className="rate-item">
              <span className="rate-label">Long-Term Rate:</span>
              <span className="rate-value">{(taxData.current_tax_bracket.rate_long_term * 100).toFixed(1)}%</span>
            </div>
            <div className="rate-item">
              <span className="rate-label">Marginal Rate:</span>
              <span className="rate-value">{(taxData.marginal_rate * 100).toFixed(1)}%</span>
            </div>
            <div className="rate-item">
              <span className="rate-label">Effective Rate:</span>
              <span className="rate-value">{(taxData.effective_rate * 100).toFixed(1)}%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Recommendations */}
      <div className="section-card recommendations-card">
        <h3>💡 Key Recommendations</h3>
        <div className="recommendations-list">
          {taxData.recommendations.map((rec, index) => (
            <div key={index} className="recommendation-item">
              <span className="rec-bullet">•</span>
              <span className="rec-text">{rec}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Warnings */}
      {taxData.warnings.length > 0 && (
        <div className="section-card warnings-card">
          <h3>⚠️ Warnings</h3>
          <div className="warnings-list">
            {taxData.warnings.map((warning, index) => (
              <div key={index} className="warning-item">
                <span className="warning-icon">⚠️</span>
                <span className="warning-text">{warning}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

// ============================================================================
// TRADE IMPACT TAB
// ============================================================================

const TradeImpactTab = ({ taxData }) => {
  return (
    <div className="trade-impact-tab">
      <h2>💸 Tax Impact of Proposed Trades</h2>
      
      <div className="impact-summary">
        <div className="summary-item">
          <span className="summary-label">Total Tax Liability:</span>
          <span className="summary-value">${taxData.total_estimated_tax.toLocaleString()}</span>
        </div>
        <div className="summary-item">
          <span className="summary-label">Average Efficiency:</span>
          <span className="summary-value">
            {taxData.trade_tax_impacts.length > 0 
              ? (taxData.trade_tax_impacts.reduce((sum, t) => sum + t.tax_efficiency_score, 0) / taxData.trade_tax_impacts.length).toFixed(1)
              : 'N/A'}
          </span>
        </div>
      </div>

      <div className="trades-table">
        <table>
          <thead>
            <tr>
              <th>Ticker</th>
              <th>Action</th>
              <th>Quantity</th>
              <th>Proceeds</th>
              <th>Cost Basis</th>
              <th>Capital Gain</th>
              <th>Tax Status</th>
              <th>Tax Rate</th>
              <th>Estimated Tax</th>
              <th>Efficiency</th>
            </tr>
          </thead>
          <tbody>
            {taxData.trade_tax_impacts.map((trade, index) => (
              <TradeImpactRow key={index} trade={trade} />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

const TradeImpactRow = ({ trade }) => {
  const getGainColor = (gain) => gain >= 0 ? '#2ecc71' : '#e74c3c';
  const getEfficiencyColor = (score) => {
    if (score >= 80) return '#2ecc71';
    if (score >= 60) return '#f39c12';
    return '#e74c3c';
  };

  return (
    <tr>
      <td><strong>{trade.ticker}</strong></td>
      <td><span className={`action-badge ${trade.action.toLowerCase()}`}>{trade.action}</span></td>
      <td>{trade.quantity}</td>
      <td>${trade.estimated_proceeds.toLocaleString()}</td>
      <td>${trade.cost_basis.toLocaleString()}</td>
      <td style={{ color: getGainColor(trade.capital_gain) }}>
        ${trade.capital_gain.toLocaleString()}
      </td>
      <td>
        <span className={`status-badge ${trade.tax_status === 'Long Term' ? 'long-term' : 'short-term'}`}>
          {trade.tax_status}
        </span>
      </td>
      <td>{(trade.tax_rate * 100).toFixed(1)}%</td>
      <td className="tax-amount">${trade.estimated_tax.toLocaleString()}</td>
      <td>
        <div className="efficiency-indicator" style={{ color: getEfficiencyColor(trade.tax_efficiency_score) }}>
          {trade.tax_efficiency_score.toFixed(0)}
        </div>
      </td>
    </tr>
  );
};

// ============================================================================
// TAX LOSS HARVESTING TAB
// ============================================================================

const TaxLossHarvestingTab = ({ taxData }) => {
  const totalSavings = taxData.tlh_opportunities.reduce((sum, opp) => sum + opp.tax_savings, 0);

  return (
    <div className="tlh-tab">
      <div className="tlh-header">
        <h2>🌾 Tax Loss Harvesting Opportunities</h2>
        <div className="total-savings">
          Total Potential Savings: <strong>${totalSavings.toLocaleString()}</strong>
        </div>
      </div>

      {taxData.tlh_opportunities.length === 0 ? (
        <div className="no-opportunities">
          <span className="icon">✅</span>
          <p>No tax loss harvesting opportunities found at this time.</p>
        </div>
      ) : (
        <div className="tlh-opportunities">
          {taxData.tlh_opportunities.map((opp, index) => (
            <TLHOpportunityCard key={index} opportunity={opp} rank={index + 1} />
          ))}
        </div>
      )}
    </div>
  );
};

const TLHOpportunityCard = ({ opportunity, rank }) => {
  return (
    <div className="tlh-card">
      <div className="tlh-rank">#{rank}</div>
      <div className="tlh-content">
        <div className="tlh-header-row">
          <h4>{opportunity.ticker}</h4>
          <div className="tlh-savings">${opportunity.tax_savings.toLocaleString()}</div>
        </div>
        
        <div className="tlh-details">
          <div className="detail-row">
            <span className="detail-label">Unrealized Loss:</span>
            <span className="detail-value loss">${Math.abs(opportunity.unrealized_loss).toLocaleString()}</span>
          </div>
          <div className="detail-row">
            <span className="detail-label">Current Position:</span>
            <span className="detail-value">{opportunity.current_position} shares</span>
          </div>
          {opportunity.replacement_ticker && (
            <div className="detail-row">
              <span className="detail-label">Replacement:</span>
              <span className="detail-value">{opportunity.replacement_ticker}</span>
            </div>
          )}
          {opportunity.wash_sale_risk && (
            <div className="detail-row warning">
              <span className="warning-icon">⚠️</span>
              <span>Wash Sale Risk Detected</span>
            </div>
          )}
        </div>
        
        <div className="tlh-action">
          <strong>Action:</strong> {opportunity.recommended_action}
        </div>
        
        <div className="confidence-bar">
          <div className="confidence-label">Confidence: {(opportunity.confidence * 100).toFixed(0)}%</div>
          <div className="bar">
            <div 
              className="bar-fill"
              style={{ width: `${opportunity.confidence * 100}%` }}
            ></div>
          </div>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// OPTIMIZATION STRATEGIES TAB
// ============================================================================

const OptimizationTab = ({ taxData }) => {
  return (
    <div className="optimization-tab">
      <div className="opt-header">
        <h2>🎯 Tax Optimization Strategies</h2>
        <div className="recommended-badge">
          Recommended: <strong>{taxData.recommended_strategy}</strong>
        </div>
      </div>

      <div className="strategies-list">
        {taxData.optimization_strategies.map((strategy, index) => (
          <StrategyCard 
            key={index} 
            strategy={strategy} 
            isRecommended={strategy.strategy_name === taxData.recommended_strategy}
          />
        ))}
      </div>
    </div>
  );
};

const StrategyCard = ({ strategy, isRecommended }) => {
  const getPriorityColor = (priority) => {
    const colors = {
      'HIGH': '#e74c3c',
      'MEDIUM': '#f39c12',
      'LOW': '#3498db'
    };
    return colors[priority] || '#95a5a6';
  };

  return (
    <div className={`strategy-card ${isRecommended ? 'recommended' : ''}`}>
      {isRecommended && <div className="recommended-ribbon">⭐ RECOMMENDED</div>}
      
      <div className="strategy-header">
        <h3>{strategy.strategy_name}</h3>
        <div className="savings-badge">
          Save ${strategy.estimated_tax_savings.toLocaleString()}
        </div>
      </div>
      
      <p className="strategy-description">{strategy.description}</p>
      
      <div className="strategy-meta">
        <span className="priority-badge" style={{ backgroundColor: getPriorityColor(strategy.priority) }}>
          {strategy.priority} PRIORITY
        </span>
        <span className="confidence">
          Confidence: {(strategy.confidence * 100).toFixed(0)}%
        </span>
      </div>
      
      {strategy.trades_required.length > 0 && (
        <div className="required-trades">
          <h4>Required Trades:</h4>
          <ul>
            {strategy.trades_required.map((trade, idx) => (
              <li key={idx}>
                {trade.action} {trade.ticker} {trade.reason && `- ${trade.reason}`}
              </li>
            ))}
          </ul>
        </div>
      )}
      
      <div className="implementation-steps">
        <h4>Implementation Steps:</h4>
        <ol>
          {strategy.implementation_steps.map((step, idx) => (
            <li key={idx}>{step}</li>
          ))}
        </ol>
      </div>
    </div>
  );
};

// ============================================================================
// HELPER COMPONENTS
// ============================================================================

const StatusMetric = ({ label, value, positive, warning }) => {
  const color = warning ? '#f39c12' : (positive && value > 0) ? '#2ecc71' : value < 0 ? '#e74c3c' : '#7f8c8d';
  
  return (
    <div className="status-metric">
      <div className="metric-label">{label}</div>
      <div className="metric-value" style={{ color }}>
        ${Math.abs(value).toLocaleString()}
      </div>
    </div>
  );
};

const LoadingState = () => (
  <div className="loading-state">
    <div className="spinner"></div>
    <h3>Analyzing Tax Impact...</h3>
  </div>
);

const EmptyState = ({ onAnalyze }) => (
  <div className="empty-state">
    <span className="empty-icon">💰</span>
    <h3>No Tax Analysis Available</h3>
    <button className="btn btn-primary" onClick={onAnalyze}>
      Run Tax Analysis
    </button>
  </div>
);

// ============================================================================
// DATA BUILDER
// ============================================================================

const buildTaxRequest = (portfolioId) => {
  return {
    portfolio_id: portfolioId,
    user_id: "USER-001",
    tax_lots: [
      {
        lot_id: "LOT-001",
        ticker: "AAPL",
        quantity: 125.0,
        purchase_price: 165.50,
        purchase_date: "2024-03-15",
        holding_period_days: 334,
        unrealized_gain: 2118.75,
        unrealized_gain_pct: 10.24,
        tax_status: "Long Term"
      },
      {
        lot_id: "LOT-002",
        ticker: "MSFT",
        quantity: 85.0,
        purchase_price: 380.20,
        purchase_date: "2024-02-20",
        holding_period_days: 357,
        unrealized_gain: 2728.50,
        unrealized_gain_pct: 8.44,
        tax_status: "Long Term"
      },
      {
        lot_id: "LOT-003",
        ticker: "BND",
        quantity: 320.0,
        purchase_price: 72.80,
        purchase_date: "2024-01-20",
        holding_period_days: 388,
        unrealized_gain: -816.00,
        unrealized_gain_pct: -3.50,
        tax_status: "Long Term"
      }
    ],
    proposed_trades: [
      {
        ticker: "AAPL",
        action: "SELL",
        quantity: -28,
        current_price: 182.45
      },
      {
        ticker: "MSFT",
        action: "SELL",
        quantity: -17,
        current_price: 412.30
      },
      {
        ticker: "BND",
        action: "BUY",
        quantity: 78,
        current_price: 70.25
      }
    ],
    annual_income: 150000,
    filing_status: "Single",
    state: "SG",
    investment_account_type: "Taxable"
  };
};

export default TaxAnalysis;
