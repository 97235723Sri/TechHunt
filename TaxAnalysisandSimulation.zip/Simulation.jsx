import React, { useState, useEffect } from 'react';
import './Simulation.css';

const API_URL = process.env.REACT_APP_SIMULATION_API_URL || 'http://localhost:5003';

const Simulation = ({ portfolioId }) => {
  const [simData, setSimData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [timeHorizon, setTimeHorizon] = useState(10);
  const [numSimulations, setNumSimulations] = useState(10000);
  const [rebalanceStrategy, setRebalanceStrategy] = useState('drift_5pct');

  const runSimulation = async () => {
    setLoading(true);
    try {
      const requestData = buildSimulationRequest(
        portfolioId,
        timeHorizon,
        numSimulations,
        rebalanceStrategy
      );
      
      const response = await fetch(`${API_URL}/api/simulation/monte-carlo`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestData)
      });

      const data = await response.json();
      setSimData(data);
    } catch (error) {
      console.error('Error running simulation:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (portfolioId) {
      runSimulation();
    }
  }, [portfolioId]);

  if (loading) {
    return <LoadingState />;
  }

  if (!simData) {
    return <EmptyState onRun={runSimulation} />;
  }

  return (
    <div className="simulation">
      {/* Header */}
      <SimulationHeader simData={simData} />

      {/* Controls */}
      <SimulationControls 
        timeHorizon={timeHorizon}
        setTimeHorizon={setTimeHorizon}
        numSimulations={numSimulations}
        setNumSimulations={setNumSimulations}
        rebalanceStrategy={rebalanceStrategy}
        setRebalanceStrategy={setRebalanceStrategy}
        onRun={runSimulation}
      />

      {/* Results */}
      <SimulationResults simData={simData} />

      {/* Scenarios */}
      <ScenariosSection scenarios={simData.scenarios} />

      {/* Strategy Comparison */}
      <StrategyComparison comparisons={simData.rebalance_comparisons} />

      {/* Insights */}
      <InsightsSection insights={simData.key_insights} />
    </div>
  );
};

// ============================================================================
// HEADER
// ============================================================================

const SimulationHeader = ({ simData }) => {
  return (
    <div className="sim-header">
      <div className="header-content">
        <h1>
          <span className="icon">🎲</span>
          Portfolio Simulation
        </h1>
        <p className="subtitle">Monte Carlo analysis with {simData.num_simulations.toLocaleString()} simulations</p>
      </div>
      
      <div className="sim-meta">
        <div className="meta-item">
          <span className="meta-label">Time Horizon:</span>
          <span className="meta-value">{simData.time_horizon_years} years</span>
        </div>
        <div className="meta-item">
          <span className="meta-label">Recommended Strategy:</span>
          <span className="meta-value">{simData.recommended_strategy}</span>
        </div>
        <div className="meta-item">
          <span className="meta-label">Confidence:</span>
          <span className="meta-value">{(simData.confidence * 100).toFixed(0)}%</span>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// CONTROLS
// ============================================================================

const SimulationControls = ({ 
  timeHorizon, setTimeHorizon,
  numSimulations, setNumSimulations,
  rebalanceStrategy, setRebalanceStrategy,
  onRun 
}) => {
  return (
    <div className="sim-controls">
      <div className="control-group">
        <label>Time Horizon (years)</label>
        <input 
          type="number" 
          value={timeHorizon}
          onChange={(e) => setTimeHorizon(parseInt(e.target.value))}
          min="1"
          max="50"
        />
      </div>

      <div className="control-group">
        <label>Number of Simulations</label>
        <select 
          value={numSimulations}
          onChange={(e) => setNumSimulations(parseInt(e.target.value))}
        >
          <option value="1000">1,000 (Fast)</option>
          <option value="10000">10,000 (Standard)</option>
          <option value="50000">50,000 (Detailed)</option>
          <option value="100000">100,000 (Maximum)</option>
        </select>
      </div>

      <div className="control-group">
        <label>Rebalance Strategy</label>
        <select 
          value={rebalanceStrategy}
          onChange={(e) => setRebalanceStrategy(e.target.value)}
        >
          <option value="never">Never Rebalance</option>
          <option value="annually">Annual Rebalancing</option>
          <option value="drift_5pct">Drift Threshold (5%)</option>
          <option value="optimal">Optimal ML Strategy</option>
        </select>
      </div>

      <button className="btn btn-primary" onClick={onRun}>
        Run Simulation
      </button>
    </div>
  );
};

// ============================================================================
// RESULTS
// ============================================================================

const SimulationResults = ({ simData }) => {
  const results = simData.simulation_results;

  return (
    <div className="sim-results">
      <h2>📊 Simulation Results</h2>
      
      <div className="results-grid">
        <ResultCard 
          label="5th Percentile (Worst Case)"
          value={results.percentile_5}
          description="Only 5% of outcomes are worse than this"
          color="#e74c3c"
        />
        
        <ResultCard 
          label="25th Percentile"
          value={results.percentile_25}
          description="Below average outcome"
          color="#f39c12"
        />
        
        <ResultCard 
          label="Median (Most Likely)"
          value={results.median}
          description="50% chance of this or better"
          color="#3498db"
          highlight={true}
        />
        
        <ResultCard 
          label="75th Percentile"
          value={results.percentile_75}
          description="Above average outcome"
          color="#2ecc71"
        />
        
        <ResultCard 
          label="95th Percentile (Best Case)"
          value={results.percentile_95}
          description="Only 5% of outcomes are better"
          color="#9b59b6"
        />
        
        <ResultCard 
          label="Mean (Average)"
          value={results.mean}
          description="Arithmetic mean of all outcomes"
          color="#1abc9c"
        />
      </div>

      <div className="additional-metrics">
        <MetricRow 
          label="Standard Deviation"
          value={`$${results.std_dev.toLocaleString()}`}
        />
        <MetricRow 
          label="Success Probability"
          value={`${(results.success_probability * 100).toFixed(1)}%`}
          description="Chance of beating inflation"
        />
        <MetricRow 
          label="Range"
          value={`$${results.min_value.toLocaleString()} - $${results.max_value.toLocaleString()}`}
        />
      </div>

      {/* Distribution Chart Placeholder */}
      <div className="chart-container">
        <h3>Outcome Distribution</h3>
        <DistributionChart data={simData.distribution_data} />
      </div>
    </div>
  );
};

const ResultCard = ({ label, value, description, color, highlight }) => {
  return (
    <div className={`result-card ${highlight ? 'highlight' : ''}`} style={{ borderLeftColor: color }}>
      <div className="result-label">{label}</div>
      <div className="result-value" style={{ color }}>${value.toLocaleString()}</div>
      <div className="result-description">{description}</div>
    </div>
  );
};

const MetricRow = ({ label, value, description }) => {
  return (
    <div className="metric-row">
      <span className="metric-label">{label}:</span>
      <span className="metric-value">{value}</span>
      {description && <span className="metric-desc">({description})</span>}
    </div>
  );
};

// ============================================================================
// SCENARIOS
// ============================================================================

const ScenariosSection = ({ scenarios }) => {
  return (
    <div className="scenarios-section">
      <h2>🎯 Outcome Scenarios</h2>
      
      <div className="scenarios-grid">
        {scenarios.map((scenario, index) => (
          <ScenarioCard key={index} scenario={scenario} />
        ))}
      </div>
    </div>
  );
};

const ScenarioCard = ({ scenario }) => {
  const getScenarioColor = (name) => {
    if (name.includes('Bear')) return '#e74c3c';
    if (name.includes('Below')) return '#f39c12';
    if (name.includes('Median')) return '#3498db';
    if (name.includes('Above')) return '#2ecc71';
    if (name.includes('Bull')) return '#9b59b6';
    return '#95a5a6';
  };

  const color = getScenarioColor(scenario.scenario_name);

  return (
    <div className="scenario-card" style={{ borderTopColor: color }}>
      <div className="scenario-header">
        <h4>{scenario.scenario_name}</h4>
        <span className="probability">{(scenario.probability * 100).toFixed(0)}% likely</span>
      </div>
      
      <div className="scenario-value">
        ${scenario.median_value.toLocaleString()}
      </div>
      
      <div className="scenario-metrics">
        <div className="scenario-metric">
          <span className="sm-label">Range:</span>
          <span className="sm-value">
            ${scenario.percentile_10.toLocaleString()} - ${scenario.percentile_90.toLocaleString()}
          </span>
        </div>
        <div className="scenario-metric">
          <span className="sm-label">Max Drawdown:</span>
          <span className="sm-value">{(scenario.max_drawdown * 100).toFixed(1)}%</span>
        </div>
        <div className="scenario-metric">
          <span className="sm-label">Sharpe Ratio:</span>
          <span className="sm-value">{scenario.sharpe_ratio.toFixed(2)}</span>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// STRATEGY COMPARISON
// ============================================================================

const StrategyComparison = ({ comparisons }) => {
  return (
    <div className="strategy-comparison">
      <h2>⚖️ Rebalancing Strategy Comparison</h2>
      
      <table className="comparison-table">
        <thead>
          <tr>
            <th>Rank</th>
            <th>Strategy</th>
            <th>Final Value (Median)</th>
            <th>Sharpe Ratio</th>
            <th>Max Drawdown</th>
            <th>Volatility</th>
            <th>Tax Cost</th>
            <th>Net Benefit</th>
          </tr>
        </thead>
        <tbody>
          {comparisons.map((comp, index) => (
            <ComparisonRow key={index} comparison={comp} />
          ))}
        </tbody>
      </table>
    </div>
  );
};

const ComparisonRow = ({ comparison }) => {
  const getRankClass = (rank) => {
    if (rank === 1) return 'rank-1';
    if (rank === 2) return 'rank-2';
    if (rank === 3) return 'rank-3';
    return '';
  };

  return (
    <tr className={getRankClass(comparison.rank)}>
      <td className="rank-cell">
        {comparison.rank === 1 && <span className="medal">🥇</span>}
        {comparison.rank === 2 && <span className="medal">🥈</span>}
        {comparison.rank === 3 && <span className="medal">🥉</span>}
        {comparison.rank}
      </td>
      <td><strong>{comparison.strategy_name}</strong></td>
      <td>${comparison.final_value_median.toLocaleString()}</td>
      <td>{comparison.sharpe_ratio.toFixed(2)}</td>
      <td className="negative">{(comparison.max_drawdown * 100).toFixed(1)}%</td>
      <td>{(comparison.volatility * 100).toFixed(1)}%</td>
      <td className="tax-cost">${comparison.tax_cost_estimate.toLocaleString()}</td>
      <td className={comparison.net_benefit >= 0 ? 'positive' : 'negative'}>
        ${comparison.net_benefit.toLocaleString()}
      </td>
    </tr>
  );
};

// ============================================================================
// INSIGHTS
// ============================================================================

const InsightsSection = ({ insights }) => {
  return (
    <div className="insights-section">
      <h2>💡 Key Insights</h2>
      <div className="insights-list">
        {insights.map((insight, index) => (
          <div key={index} className="insight-item">
            <span className="insight-bullet">•</span>
            <span className="insight-text">{insight}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

// ============================================================================
// CHARTS
// ============================================================================

const DistributionChart = ({ data }) => {
  // Simple histogram visualization
  const bins = data.bins || [];
  const counts = data.counts || [];
  const maxCount = Math.max(...counts);

  return (
    <div className="distribution-chart">
      {counts.map((count, index) => (
        <div key={index} className="histogram-bar">
          <div 
            className="bar-fill"
            style={{ height: `${(count / maxCount) * 200}px` }}
          ></div>
        </div>
      ))}
    </div>
  );
};

// ============================================================================
// HELPER COMPONENTS
// ============================================================================

const LoadingState = () => (
  <div className="loading-state">
    <div className="spinner"></div>
    <h3>Running Monte Carlo Simulation...</h3>
    <p>This may take a few seconds</p>
  </div>
);

const EmptyState = ({ onRun }) => (
  <div className="empty-state">
    <span className="empty-icon">🎲</span>
    <h3>No Simulation Data</h3>
    <button className="btn btn-primary" onClick={onRun}>
      Run Simulation
    </button>
  </div>
);

// ============================================================================
// DATA BUILDER
// ============================================================================

const buildSimulationRequest = (portfolioId, years, numSims, strategy) => {
  return {
    portfolio_id: portfolioId || "PORT-001",
    current_value: 524830.00,
    current_allocations: {
      "US Equity": 0.35,
      "International Equity": 0.20,
      "Bonds": 0.30,
      "REITs": 0.10,
      "Cash": 0.05
    },
    target_allocations: {
      "US Equity": 0.30,
      "International Equity": 0.20,
      "Bonds": 0.30,
      "REITs": 0.10,
      "Commodities": 0.05,
      "Cash": 0.05
    },
    time_horizon_years: years,
    num_simulations: numSims,
    rebalance_strategy: strategy,
    risk_free_rate: 0.02
  };
};

export default Simulation;
