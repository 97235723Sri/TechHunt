"""
Portfolio Simulation Service using Monte Carlo & ML
Simulates different rebalancing scenarios and their outcomes
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Dict, Optional
import numpy as np
from datetime import datetime, timedelta
import uuid

app = FastAPI(title="Portfolio Simulation Service")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =============================================================================
# DATA MODELS
# =============================================================================

class SimulationRequest(BaseModel):
    portfolio_id: str
    current_value: float
    current_allocations: Dict[str, float]
    target_allocations: Dict[str, float]
    time_horizon_years: int
    num_simulations: int = 10000
    rebalance_strategy: str  # "never", "annually", "drift_5pct", "optimal"
    risk_free_rate: float = 0.02
    
class AssetAssumptions(BaseModel):
    asset_class: str
    expected_return: float
    volatility: float
    correlation_matrix: Optional[List[List[float]]] = None

class SimulationScenario(BaseModel):
    scenario_name: str
    probability: float
    expected_portfolio_value: float
    median_value: float
    percentile_10: float
    percentile_90: float
    max_drawdown: float
    sharpe_ratio: float

class SimulationResult(BaseModel):
    percentile_5: float
    percentile_25: float
    median: float
    percentile_75: float
    percentile_95: float
    mean: float
    std_dev: float
    max_value: float
    min_value: float
    success_probability: float

class RebalanceComparison(BaseModel):
    strategy_name: str
    final_value_median: float
    sharpe_ratio: float
    max_drawdown: float
    volatility: float
    tax_cost_estimate: float
    net_benefit: float
    rank: int

class SimulationResponse(BaseModel):
    simulation_id: str
    portfolio_id: str
    timestamp: str
    num_simulations: int
    time_horizon_years: int
    
    # Simulation Results
    simulation_results: SimulationResult
    scenarios: List[SimulationScenario]
    rebalance_comparisons: List[RebalanceComparison]
    
    # Recommendations
    recommended_strategy: str
    confidence: float
    key_insights: List[str]
    
    # Chart Data
    distribution_data: Dict
    path_data: Dict
    
# =============================================================================
# SIMULATION ENGINE
# =============================================================================

class PortfolioSimulator:
    """Monte Carlo simulation for portfolio outcomes"""
    
    def __init__(self):
        self.asset_assumptions = self._default_assumptions()
    
    def _default_assumptions(self) -> Dict[str, AssetAssumptions]:
        """Default asset class assumptions"""
        return {
            "US Equity": {"return": 0.10, "volatility": 0.18},
            "International Equity": {"return": 0.09, "volatility": 0.20},
            "Bonds": {"return": 0.04, "volatility": 0.06},
            "REITs": {"return": 0.08, "volatility": 0.16},
            "Commodities": {"return": 0.05, "volatility": 0.22},
            "Cash": {"return": 0.02, "volatility": 0.01}
        }
    
    def simulate(self, request: SimulationRequest) -> SimulationResponse:
        """Run Monte Carlo simulation"""
        
        print(f"Running {request.num_simulations} simulations...")
        
        # Run simulations for each rebalance strategy
        strategies = [
            "never",
            "annually", 
            "drift_5pct",
            "optimal"
        ]
        
        all_comparisons = []
        
        for strategy in strategies:
            results = self._run_monte_carlo(
                request.current_value,
                request.current_allocations,
                request.target_allocations,
                request.time_horizon_years,
                request.num_simulations,
                strategy,
                request.risk_free_rate
            )
            
            comparison = RebalanceComparison(
                strategy_name=self._strategy_display_name(strategy),
                final_value_median=results['median'],
                sharpe_ratio=results['sharpe'],
                max_drawdown=results['max_drawdown'],
                volatility=results['volatility'],
                tax_cost_estimate=self._estimate_tax_cost(strategy, request.current_value),
                net_benefit=0,
                rank=0
            )
            
            all_comparisons.append((strategy, results, comparison))
        
        # Calculate net benefits and rank
        base_median = all_comparisons[0][1]['median']
        for i, (strategy, results, comparison) in enumerate(all_comparisons):
            benefit = comparison.final_value_median - base_median - comparison.tax_cost_estimate
            comparison.net_benefit = benefit
        
        # Rank by net benefit
        all_comparisons.sort(key=lambda x: x[2].net_benefit, reverse=True)
        for i, (strategy, results, comparison) in enumerate(all_comparisons):
            comparison.rank = i + 1
        
        # Use requested strategy for main results
        main_strategy = request.rebalance_strategy
        main_results = next(r for s, r, c in all_comparisons if s == main_strategy)
        
        # Generate scenarios
        scenarios = self._generate_scenarios(
            request.current_value,
            request.time_horizon_years,
            main_results
        )
        
        # Determine best strategy
        best_comparison = all_comparisons[0][2]
        
        # Generate insights
        insights = self._generate_insights(
            all_comparisons,
            scenarios,
            request.time_horizon_years
        )
        
        # Build simulation result
        sim_result = SimulationResult(
            percentile_5=main_results['p5'],
            percentile_25=main_results['p25'],
            median=main_results['median'],
            percentile_75=main_results['p75'],
            percentile_95=main_results['p95'],
            mean=main_results['mean'],
            std_dev=main_results['std'],
            max_value=main_results['max'],
            min_value=main_results['min'],
            success_probability=main_results['success_prob']
        )
        
        # Generate chart data
        distribution_data = self._generate_distribution_data(main_results['all_outcomes'])
        path_data = self._generate_path_data(
            request.current_value,
            request.time_horizon_years,
            main_results
        )
        
        return SimulationResponse(
            simulation_id=str(uuid.uuid4()),
            portfolio_id=request.portfolio_id,
            timestamp=datetime.now().isoformat(),
            num_simulations=request.num_simulations,
            time_horizon_years=request.time_horizon_years,
            simulation_results=sim_result,
            scenarios=scenarios,
            rebalance_comparisons=[c for _, _, c in all_comparisons],
            recommended_strategy=best_comparison.strategy_name,
            confidence=0.85,
            key_insights=insights,
            distribution_data=distribution_data,
            path_data=path_data
        )
    
    def _run_monte_carlo(
        self,
        initial_value: float,
        current_alloc: Dict,
        target_alloc: Dict,
        years: int,
        num_sims: int,
        rebalance_strategy: str,
        risk_free_rate: float
    ) -> Dict:
        """Run Monte Carlo simulation"""
        
        final_values = []
        paths = []
        
        for sim in range(num_sims):
            # Simulate path
            path = self._simulate_single_path(
                initial_value,
                current_alloc,
                target_alloc,
                years,
                rebalance_strategy
            )
            
            final_values.append(path[-1])
            if sim < 100:  # Store first 100 paths for visualization
                paths.append(path)
        
        final_values = np.array(final_values)
        
        # Calculate statistics
        p5 = np.percentile(final_values, 5)
        p25 = np.percentile(final_values, 25)
        median = np.percentile(final_values, 50)
        p75 = np.percentile(final_values, 75)
        p95 = np.percentile(final_values, 95)
        mean = np.mean(final_values)
        std = np.std(final_values)
        
        # Success probability (beating inflation)
        inflation_adjusted_goal = initial_value * (1.02 ** years)
        success_prob = np.sum(final_values > inflation_adjusted_goal) / num_sims
        
        # Calculate max drawdown
        max_dd = self._calculate_max_drawdown(paths)
        
        # Calculate Sharpe ratio
        returns = (final_values / initial_value) ** (1/years) - 1
        excess_return = np.mean(returns) - risk_free_rate
        sharpe = excess_return / np.std(returns) if np.std(returns) > 0 else 0
        
        # Volatility
        volatility = np.std(returns)
        
        return {
            'p5': p5,
            'p25': p25,
            'median': median,
            'p75': p75,
            'p95': p95,
            'mean': mean,
            'std': std,
            'max': np.max(final_values),
            'min': np.min(final_values),
            'success_prob': success_prob,
            'max_drawdown': max_dd,
            'sharpe': sharpe,
            'volatility': volatility,
            'all_outcomes': final_values.tolist(),
            'sample_paths': paths
        }
    
    def _simulate_single_path(
        self,
        initial_value: float,
        current_alloc: Dict,
        target_alloc: Dict,
        years: int,
        rebalance_strategy: str
    ) -> List[float]:
        """Simulate a single portfolio path"""
        
        path = [initial_value]
        current_value = initial_value
        current_weights = current_alloc.copy()
        
        months = years * 12
        
        for month in range(months):
            # Generate monthly returns for each asset class
            monthly_returns = {}
            for asset_class, weight in current_weights.items():
                assumptions = self.asset_assumptions.get(asset_class, 
                    {"return": 0.08, "volatility": 0.15})
                
                annual_return = assumptions["return"]
                annual_vol = assumptions["volatility"]
                
                # Monthly parameters
                monthly_mu = (annual_return - 0.5 * annual_vol**2) / 12
                monthly_sigma = annual_vol / np.sqrt(12)
                
                # Generate random return
                random_return = np.random.normal(monthly_mu, monthly_sigma)
                monthly_returns[asset_class] = np.exp(random_return) - 1
            
            # Update portfolio value
            new_value = 0
            new_weights = {}
            
            for asset_class, weight in current_weights.items():
                asset_value = current_value * weight * (1 + monthly_returns.get(asset_class, 0))
                new_value += asset_value
                new_weights[asset_class] = asset_value / (current_value * sum(
                    w * (1 + monthly_returns.get(ac, 0)) for ac, w in current_weights.items()
                ))
            
            current_value = new_value
            current_weights = new_weights
            
            # Check if rebalancing needed
            should_rebalance = self._should_rebalance(
                current_weights,
                target_alloc,
                rebalance_strategy,
                month
            )
            
            if should_rebalance:
                current_weights = target_alloc.copy()
            
            path.append(current_value)
        
        return path
    
    def _should_rebalance(
        self,
        current: Dict,
        target: Dict,
        strategy: str,
        month: int
    ) -> bool:
        """Determine if rebalancing is needed"""
        
        if strategy == "never":
            return False
        
        if strategy == "annually":
            return month % 12 == 0 and month > 0
        
        if strategy == "drift_5pct":
            # Check if any asset class drifted more than 5%
            for asset_class, target_weight in target.items():
                current_weight = current.get(asset_class, 0)
                if abs(current_weight - target_weight) > 0.05:
                    return True
            return False
        
        if strategy == "optimal":
            # Optimal strategy: rebalance quarterly or on 7% drift
            if month % 3 == 0 and month > 0:
                return True
            for asset_class, target_weight in target.items():
                current_weight = current.get(asset_class, 0)
                if abs(current_weight - target_weight) > 0.07:
                    return True
            return False
        
        return False
    
    def _calculate_max_drawdown(self, paths: List[List[float]]) -> float:
        """Calculate maximum drawdown from sample paths"""
        
        max_dds = []
        
        for path in paths[:min(100, len(paths))]:
            peak = path[0]
            max_dd = 0
            
            for value in path:
                if value > peak:
                    peak = value
                dd = (peak - value) / peak
                if dd > max_dd:
                    max_dd = dd
            
            max_dds.append(max_dd)
        
        return np.mean(max_dds) if max_dds else 0
    
    def _estimate_tax_cost(self, strategy: str, portfolio_value: float) -> float:
        """Estimate tax cost of rebalancing strategy"""
        
        costs = {
            "never": 0,
            "annually": portfolio_value * 0.005,  # 0.5% per year
            "drift_5pct": portfolio_value * 0.003,  # 0.3%
            "optimal": portfolio_value * 0.007  # 0.7%
        }
        
        return costs.get(strategy, 0)
    
    def _strategy_display_name(self, strategy: str) -> str:
        """Get display name for strategy"""
        
        names = {
            "never": "Never Rebalance",
            "annually": "Annual Rebalancing",
            "drift_5pct": "Drift Threshold (5%)",
            "optimal": "Optimal ML Strategy"
        }
        
        return names.get(strategy, strategy)
    
    def _generate_scenarios(
        self,
        initial_value: float,
        years: int,
        results: Dict
    ) -> List[SimulationScenario]:
        """Generate outcome scenarios"""
        
        scenarios = []
        
        # Bear market scenario
        scenarios.append(SimulationScenario(
            scenario_name="Bear Market (5th percentile)",
            probability=0.05,
            expected_portfolio_value=results['p5'],
            median_value=results['p5'],
            percentile_10=results['p5'] * 0.9,
            percentile_90=results['p5'] * 1.1,
            max_drawdown=-0.35,
            sharpe_ratio=0.3
        ))
        
        # Below average scenario
        scenarios.append(SimulationScenario(
            scenario_name="Below Average (25th percentile)",
            probability=0.20,
            expected_portfolio_value=results['p25'],
            median_value=results['p25'],
            percentile_10=results['p25'] * 0.95,
            percentile_90=results['p25'] * 1.05,
            max_drawdown=-0.18,
            sharpe_ratio=0.8
        ))
        
        # Most likely scenario
        scenarios.append(SimulationScenario(
            scenario_name="Most Likely (Median)",
            probability=0.50,
            expected_portfolio_value=results['median'],
            median_value=results['median'],
            percentile_10=results['median'] * 0.97,
            percentile_90=results['median'] * 1.03,
            max_drawdown=-0.12,
            sharpe_ratio=1.2
        ))
        
        # Above average scenario
        scenarios.append(SimulationScenario(
            scenario_name="Above Average (75th percentile)",
            probability=0.20,
            expected_portfolio_value=results['p75'],
            median_value=results['p75'],
            percentile_10=results['p75'] * 0.95,
            percentile_90=results['p75'] * 1.05,
            max_drawdown=-0.08,
            sharpe_ratio=1.6
        ))
        
        # Bull market scenario
        scenarios.append(SimulationScenario(
            scenario_name="Bull Market (95th percentile)",
            probability=0.05,
            expected_portfolio_value=results['p95'],
            median_value=results['p95'],
            percentile_10=results['p95'] * 0.9,
            percentile_90=results['p95'] * 1.1,
            max_drawdown=-0.05,
            sharpe_ratio=2.2
        ))
        
        return scenarios
    
    def _generate_insights(
        self,
        comparisons: List,
        scenarios: List[SimulationScenario],
        years: int
    ) -> List[str]:
        """Generate key insights"""
        
        insights = []
        
        # Best strategy
        best = comparisons[0][2]
        insights.append(
            f"✅ Recommended: {best.strategy_name} "
            f"(${best.net_benefit:,.0f} higher expected value)"
        )
        
        # Most likely outcome
        median_scenario = next(s for s in scenarios if "Median" in s.scenario_name)
        insights.append(
            f"📊 Most likely outcome: ${median_scenario.median_value:,.0f} "
            f"after {years} years"
        )
        
        # Downside risk
        bear_scenario = next(s for s in scenarios if "Bear" in s.scenario_name)
        insights.append(
            f"⚠️ Downside risk (5%): Portfolio could be ${bear_scenario.median_value:,.0f}"
        )
        
        # Upside potential
        bull_scenario = next(s for s in scenarios if "Bull" in s.scenario_name)
        insights.append(
            f"🚀 Upside potential (5%): Portfolio could reach ${bull_scenario.median_value:,.0f}"
        )
        
        return insights
    
    def _generate_distribution_data(self, outcomes: List[float]) -> Dict:
        """Generate histogram data"""
        
        hist, bins = np.histogram(outcomes, bins=50)
        
        return {
            "bins": bins.tolist(),
            "counts": hist.tolist()
        }
    
    def _generate_path_data(
        self,
        initial_value: float,
        years: int,
        results: Dict
    ) -> Dict:
        """Generate sample path data"""
        
        sample_paths = results.get('sample_paths', [])
        
        if not sample_paths:
            return {"paths": []}
        
        # Take first 10 paths for visualization
        paths_data = []
        for path in sample_paths[:10]:
            paths_data.append({
                "values": path,
                "months": list(range(len(path)))
            })
        
        return {
            "paths": paths_data,
            "median_path": [initial_value * ((results['median'] / initial_value) ** (i / (years * 12))) 
                           for i in range(years * 12 + 1)]
        }

# =============================================================================
# API ENDPOINTS
# =============================================================================

simulator = PortfolioSimulator()

@app.get("/")
async def root():
    return {
        "service": "Portfolio Simulation Service",
        "version": "1.0.0",
        "methods": ["Monte Carlo", "ML-Enhanced"]
    }

@app.post("/api/simulation/monte-carlo", response_model=SimulationResponse)
async def run_simulation(request: SimulationRequest):
    """Run Monte Carlo simulation"""
    try:
        result = simulator.simulate(request)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    print("Starting Portfolio Simulation Service...")
    uvicorn.run(app, host="0.0.0.0", port=5003, log_level="info")
