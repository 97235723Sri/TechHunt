import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:8080/api';

export const fetchHoldings = createAsyncThunk(
  'holdings/fetchAll',
  async (portfolioId) => {
    const response = await axios.get(`${API_BASE_URL}/portfolios/${portfolioId}/holdings`);
    return response.data;
  }
);

export const fetchHoldingDetail = createAsyncThunk(
  'holdings/fetchDetail',
  async ({ portfolioId, holdingId }) => {
    const response = await axios.get(`${API_BASE_URL}/portfolios/${portfolioId}/holdings/${holdingId}`);
    return response.data;
  }
);

const initialState = {
  holdings: [],
  selectedHolding: null,
  filters: {
    assetClass: 'all',
    driftStatus: 'all',
    action: 'all',
    searchQuery: '',
  },
  sortBy: 'drift',
  sortOrder: 'desc',
  loading: false,
  error: null,
};

const holdingsSlice = createSlice({
  name: 'holdings',
  initialState,
  reducers: {
    setFilter: (state, action) => {
      const { filterType, value } = action.payload;
      state.filters[filterType] = value;
    },
    setSearchQuery: (state, action) => {
      state.filters.searchQuery = action.payload;
    },
    setSorting: (state, action) => {
      const { sortBy, sortOrder } = action.payload;
      state.sortBy = sortBy;
      state.sortOrder = sortOrder;
    },
    setSelectedHolding: (state, action) => {
      state.selectedHolding = action.payload;
    },
    clearFilters: (state) => {
      state.filters = initialState.filters;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchHoldings.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchHoldings.fulfilled, (state, action) => {
        state.loading = false;
        state.holdings = action.payload;
      })
      .addCase(fetchHoldings.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      .addCase(fetchHoldingDetail.fulfilled, (state, action) => {
        state.selectedHolding = action.payload;
      });
  },
});

export const { setFilter, setSearchQuery, setSorting, setSelectedHolding, clearFilters } = holdingsSlice.actions;

export default holdingsSlice.reducer;

// Selectors
export const selectFilteredHoldings = (state) => {
  const { holdings, filters, sortBy, sortOrder } = state.holdings;
  
  // Apply filters
  let filtered = holdings.filter((holding) => {
    // Asset class filter
    if (filters.assetClass !== 'all' && holding.assetClass !== filters.assetClass) {
      return false;
    }
    
    // Drift status filter
    if (filters.driftStatus !== 'all') {
      const drift = Math.abs(holding.drift);
      switch (filters.driftStatus) {
        case 'critical':
          if (drift <= 5) return false;
          break;
        case 'warning':
          if (drift <= 3 || drift > 5) return false;
          break;
        case 'normal':
          if (drift > 3) return false;
          break;
        default:
          break;
      }
    }
    
    // Action filter
    if (filters.action !== 'all' && holding.recommendedAction !== filters.action) {
      return false;
    }
    
    // Search query
    if (filters.searchQuery) {
      const query = filters.searchQuery.toLowerCase();
      const matchesTicker = holding.ticker.toLowerCase().includes(query);
      const matchesName = holding.name.toLowerCase().includes(query);
      if (!matchesTicker && !matchesName) {
        return false;
      }
    }
    
    return true;
  });
  
  // Apply sorting
  filtered.sort((a, b) => {
    let aVal, bVal;
    
    switch (sortBy) {
      case 'ticker':
        aVal = a.ticker;
        bVal = b.ticker;
        break;
      case 'value':
        aVal = a.marketValue;
        bVal = b.marketValue;
        break;
      case 'drift':
        aVal = Math.abs(a.drift);
        bVal = Math.abs(b.drift);
        break;
      case 'currentPercent':
        aVal = a.currentPercent;
        bVal = b.currentPercent;
        break;
      default:
        return 0;
    }
    
    if (sortOrder === 'asc') {
      return aVal > bVal ? 1 : -1;
    } else {
      return aVal < bVal ? 1 : -1;
    }
  });
  
  return filtered;
};

export const selectHoldingsLoading = (state) => state.holdings.loading;
export const selectHoldingsError = (state) => state.holdings.error;
export const selectSelectedHolding = (state) => state.holdings.selectedHolding;
