import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:8080/api';

// Async thunks
export const fetchPortfolioSummary = createAsyncThunk(
  'portfolio/fetchSummary',
  async (portfolioId) => {
    const response = await axios.get(`${API_BASE_URL}/portfolios/${portfolioId}/summary`);
    return response.data;
  }
);

export const fetchAllPortfolios = createAsyncThunk(
  'portfolio/fetchAll',
  async () => {
    const response = await axios.get(`${API_BASE_URL}/portfolios`);
    return response.data;
  }
);

const initialState = {
  portfolios: [],
  selectedPortfolioId: null,
  currentPortfolio: {
    id: null,
    name: '',
    totalValue: 0,
    totalCost: 0,
    unrealizedGain: 0,
    unrealizedGainPercent: 0,
    dayChange: 0,
    dayChangePercent: 0,
    lastRebalanceDate: null,
    driftScore: 0,
    riskScore: 0,
  },
  loading: false,
  error: null,
  lastUpdated: null,
};

const portfolioSlice = createSlice({
  name: 'portfolio',
  initialState,
  reducers: {
    setSelectedPortfolio: (state, action) => {
      state.selectedPortfolioId = action.payload;
    },
    updatePortfolioValue: (state, action) => {
      state.currentPortfolio.totalValue = action.payload.totalValue;
      state.currentPortfolio.dayChange = action.payload.dayChange;
      state.currentPortfolio.dayChangePercent = action.payload.dayChangePercent;
      state.lastUpdated = new Date().toISOString();
    },
    clearError: (state) => {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch portfolio summary
      .addCase(fetchPortfolioSummary.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchPortfolioSummary.fulfilled, (state, action) => {
        state.loading = false;
        state.currentPortfolio = action.payload;
        state.lastUpdated = new Date().toISOString();
      })
      .addCase(fetchPortfolioSummary.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      // Fetch all portfolios
      .addCase(fetchAllPortfolios.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchAllPortfolios.fulfilled, (state, action) => {
        state.loading = false;
        state.portfolios = action.payload;
        if (action.payload.length > 0 && !state.selectedPortfolioId) {
          state.selectedPortfolioId = action.payload[0].id;
        }
      })
      .addCase(fetchAllPortfolios.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      });
  },
});

export const { setSelectedPortfolio, updatePortfolioValue, clearError } = portfolioSlice.actions;

export default portfolioSlice.reducer;

// Selectors
export const selectCurrentPortfolio = (state) => state.portfolio.currentPortfolio;
export const selectAllPortfolios = (state) => state.portfolio.portfolios;
export const selectPortfolioLoading = (state) => state.portfolio.loading;
export const selectSelectedPortfolioId = (state) => state.portfolio.selectedPortfolioId;
