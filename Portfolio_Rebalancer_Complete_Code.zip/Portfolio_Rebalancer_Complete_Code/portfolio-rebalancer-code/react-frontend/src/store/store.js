import { configureStore } from '@reduxjs/toolkit';
import portfolioReducer from './slices/portfolioSlice';
import holdingsReducer from './slices/holdingsSlice';
import driftReducer from './slices/driftSlice';
import rebalanceReducer from './slices/rebalanceSlice';
import riskReducer from './slices/riskSlice';
import settingsReducer from './slices/settingsSlice';

export const store = configureStore({
  reducer: {
    portfolio: portfolioReducer,
    holdings: holdingsReducer,
    drift: driftReducer,
    rebalance: rebalanceReducer,
    risk: riskReducer,
    settings: settingsReducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        // Ignore these action types for date serialization
        ignoredActions: ['portfolio/setLastUpdated'],
      },
    }),
});

export default store;
