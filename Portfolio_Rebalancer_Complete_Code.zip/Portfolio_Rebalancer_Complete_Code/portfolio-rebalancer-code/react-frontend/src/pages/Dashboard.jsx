import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  Box,
  Grid,
  Paper,
  Typography,
  Button,
  Alert,
  AlertTitle,
  Container,
  CircularProgress,
} from '@mui/material';
import {
  TrendingUp as TrendingUpIcon,
  Warning as WarningIcon,
  Assessment as AssessmentIcon,
  Refresh as RefreshIcon,
} from '@mui/icons-material';
import { fetchPortfolioSummary, selectCurrentPortfolio, selectPortfolioLoading } from '../store/slices/portfolioSlice';
import { fetchHoldings } from '../store/slices/holdingsSlice';
import { fetchDriftMetrics } from '../store/slices/driftSlice';
import { fetchRebalanceRecommendations } from '../store/slices/rebalanceSlice';
import KPICard from '../components/dashboard/KPICard';
import AllocationChart from '../components/dashboard/AllocationChart';
import HoldingsTable from '../components/dashboard/HoldingsTable';
import DriftIndicator from '../components/dashboard/DriftIndicator';
import { useNavigate } from 'react-router-dom';

const Dashboard = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const portfolio = useSelector(selectCurrentPortfolio);
  const loading = useSelector(selectPortfolioLoading);
  const [showAlert, setShowAlert] = useState(false);

  useEffect(() => {
    if (portfolio.id) {
      refreshData();
    }
  }, [portfolio.id]);

  useEffect(() => {
    // Show alert if drift exceeds threshold
    if (portfolio.driftScore >= 5.0) {
      setShowAlert(true);
    }
  }, [portfolio.driftScore]);

  const refreshData = () => {
    dispatch(fetchPortfolioSummary(portfolio.id));
    dispatch(fetchHoldings(portfolio.id));
    dispatch(fetchDriftMetrics(portfolio.id));
    dispatch(fetchRebalanceRecommendations(portfolio.id));
  };

  if (loading && !portfolio.id) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="60vh">
        <CircularProgress />
      </Box>
    );
  }

  const getDriftSeverity = (drift) => {
    if (drift >= 5) return 'error';
    if (drift >= 3) return 'warning';
    return 'success';
  };

  const dayChangeColor = portfolio.dayChangePercent >= 0 ? 'success.main' : 'error.main';

  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
      {/* Alert Banner */}
      {showAlert && portfolio.driftScore >= 5.0 && (
        <Alert 
          severity={getDriftSeverity(portfolio.driftScore)}
          onClose={() => setShowAlert(false)}
          sx={{ mb: 3 }}
        >
          <AlertTitle>
            <Box display="flex" alignItems="center">
              <WarningIcon sx={{ mr: 1 }} />
              REBALANCE REQUIRED
            </Box>
          </AlertTitle>
          Portfolio drift at {portfolio.driftScore.toFixed(1)}% (threshold: 5.0%).
          {' '}
          <Button 
            size="small" 
            onClick={() => navigate('/rebalance')}
            sx={{ ml: 2 }}
          >
            View Details
          </Button>
          <Button 
            size="small" 
            variant="contained"
            onClick={() => navigate('/rebalance')}
            sx={{ ml: 1 }}
          >
            Rebalance Now
          </Button>
        </Alert>
      )}

      {/* Portfolio Header */}
      <Paper elevation={2} sx={{ p: 3, mb: 3 }}>
        <Grid container alignItems="center" spacing={2}>
          <Grid item xs={12} md={6}>
            <Typography variant="h5" gutterBottom>
              {portfolio.name || 'Main Portfolio'}
            </Typography>
            <Box display="flex" alignItems="baseline" gap={2}>
              <Typography variant="h3" component="span">
                ${portfolio.totalValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </Typography>
              <Typography 
                variant="h6" 
                component="span"
                sx={{ color: dayChangeColor }}
              >
                {portfolio.dayChangePercent >= 0 ? '+' : ''}
                {portfolio.dayChangePercent.toFixed(2)}%
                {' '}
                (${Math.abs(portfolio.dayChange).toLocaleString('en-US', { minimumFractionDigits: 2 })})
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={12} md={6} sx={{ textAlign: { md: 'right' } }}>
            <Typography variant="body2" color="text.secondary">
              Last Rebalance: {portfolio.lastRebalanceDate 
                ? new Date(portfolio.lastRebalanceDate).toLocaleDateString() 
                : 'Never'}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              As of: {new Date().toLocaleString()}
            </Typography>
            <Button
              startIcon={<RefreshIcon />}
              onClick={refreshData}
              sx={{ mt: 1 }}
            >
              Refresh
            </Button>
          </Grid>
        </Grid>
      </Paper>

      {/* KPI Cards */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid item xs={12} sm={6} md={3}>
          <KPICard
            title="DRIFT SCORE"
            value={`${portfolio.driftScore.toFixed(1)}%`}
            subtitle={`Threshold: 5.0%`}
            severity={getDriftSeverity(portfolio.driftScore)}
            icon={<TrendingUpIcon />}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <KPICard
            title="RISK LEVEL"
            value={portfolio.riskScore >= 76 ? 'Good' : portfolio.riskScore >= 61 ? 'Fair' : 'Poor'}
            subtitle={`Score: ${portfolio.riskScore}`}
            severity={portfolio.riskScore >= 76 ? 'success' : 'warning'}
            icon={<AssessmentIcon />}
            actionText="View Details"
            onAction={() => navigate('/risk-analytics')}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <KPICard
            title="REBALANCE STATUS"
            value={portfolio.driftScore >= 5 ? 'Required' : portfolio.driftScore >= 3 ? 'Recommended' : 'Not Needed'}
            subtitle={portfolio.lastRebalanceDate 
              ? `${Math.floor((new Date() - new Date(portfolio.lastRebalanceDate)) / (1000 * 60 * 60 * 24))} days ago`
              : 'Never rebalanced'}
            severity={portfolio.driftScore >= 5 ? 'error' : portfolio.driftScore >= 3 ? 'warning' : 'success'}
            icon={<WarningIcon />}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <KPICard
            title="UNREALIZED GAIN"
            value={`$${portfolio.unrealizedGain.toLocaleString()}`}
            subtitle={`${portfolio.unrealizedGainPercent.toFixed(2)}%`}
            severity={portfolio.unrealizedGainPercent >= 0 ? 'success' : 'error'}
            icon={<TrendingUpIcon />}
          />
        </Grid>
      </Grid>

      {/* Main Content Grid */}
      <Grid container spacing={3}>
        {/* Allocation Chart */}
        <Grid item xs={12} lg={7}>
          <Paper elevation={2} sx={{ p: 3, height: '100%' }}>
            <Typography variant="h6" gutterBottom>
              Current vs Target Allocation
            </Typography>
            <AllocationChart portfolioId={portfolio.id} />
          </Paper>
        </Grid>

        {/* Drift Indicator */}
        <Grid item xs={12} lg={5}>
          <Paper elevation={2} sx={{ p: 3, height: '100%' }}>
            <Typography variant="h6" gutterBottom>
              Portfolio Health
            </Typography>
            <DriftIndicator 
              score={portfolio.riskScore} 
              drift={portfolio.driftScore}
            />
          </Paper>
        </Grid>

        {/* Holdings Table */}
        <Grid item xs={12}>
          <Paper elevation={2} sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Top Holdings
            </Typography>
            <HoldingsTable limit={10} />
          </Paper>
        </Grid>
      </Grid>

      {/* Action Buttons */}
      <Box sx={{ mt: 3, display: 'flex', gap: 2, justifyContent: 'center' }}>
        <Button
          variant="contained"
          color="primary"
          size="large"
          onClick={() => navigate('/rebalance')}
        >
          Rebalance Now
        </Button>
        <Button
          variant="outlined"
          size="large"
          onClick={() => navigate('/simulation')}
        >
          View Simulation
        </Button>
        <Button
          variant="outlined"
          size="large"
        >
          Export Report
        </Button>
      </Box>
    </Container>
  );
};

export default Dashboard;
