import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Provider } from 'react-redux';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { store } from './store/store';
import MainLayout from './components/layout/MainLayout';
import Dashboard from './pages/Dashboard';
import Holdings from './pages/Holdings';
import Rebalance from './pages/Rebalance';
import RiskAnalytics from './pages/RiskAnalytics';
import Settings from './pages/Settings';
import Simulation from './pages/Simulation';
import HistoricalDrift from './pages/HistoricalDrift';
import './App.css';

// Create custom theme matching design specs
const theme = createTheme({
  palette: {
    primary: {
      main: '#2C5AA0',
      light: '#4A7BC8',
      dark: '#1E3F70',
    },
    secondary: {
      main: '#6C757D',
    },
    success: {
      main: '#28A745',
    },
    warning: {
      main: '#FFC107',
    },
    error: {
      main: '#DC3545',
    },
    background: {
      default: '#F8F9FA',
      paper: '#FFFFFF',
    },
    text: {
      primary: '#212529',
      secondary: '#6C757D',
    },
  },
  typography: {
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif',
    h1: {
      fontSize: '2rem',
      fontWeight: 700,
      color: '#212529',
    },
    h2: {
      fontSize: '1.75rem',
      fontWeight: 700,
      color: '#212529',
    },
    h3: {
      fontSize: '1.5rem',
      fontWeight: 600,
      color: '#495057',
    },
    body1: {
      fontSize: '1rem',
    },
    body2: {
      fontSize: '0.875rem',
    },
  },
  spacing: 8, // Base spacing unit
  shape: {
    borderRadius: 8,
  },
});

function App() {
  return (
    <Provider store={store}>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <Router>
          <Routes>
            <Route path="/" element={<MainLayout />}>
              <Route index element={<Navigate to="/dashboard" replace />} />
              <Route path="dashboard" element={<Dashboard />} />
              <Route path="holdings" element={<Holdings />} />
              <Route path="rebalance" element={<Rebalance />} />
              <Route path="risk-analytics" element={<RiskAnalytics />} />
              <Route path="simulation" element={<Simulation />} />
              <Route path="historical-drift" element={<HistoricalDrift />} />
              <Route path="settings" element={<Settings />} />
            </Route>
          </Routes>
        </Router>
      </ThemeProvider>
    </Provider>
  );
}

export default App;
