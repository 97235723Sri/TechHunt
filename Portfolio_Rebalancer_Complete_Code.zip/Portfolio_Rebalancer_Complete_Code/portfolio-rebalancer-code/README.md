# Smart Portfolio Rebalancer

A comprehensive portfolio management system that monitors allocation drift, generates intelligent rebalancing recommendations, and provides advanced risk analytics.

## 🎯 Features

### Core Functionality
- **Real-time Portfolio Monitoring**: Track portfolio value, drift, and performance metrics
- **Drift Detection**: Automatic detection when allocations deviate from targets
- **Intelligent Rebalancing**: ML-driven trade recommendations with tax optimization
- **Risk Analytics**: Comprehensive risk metrics including VaR, Sharpe ratio, stress testing
- **Historical Analysis**: Track drift trends and rebalancing effectiveness over time
- **Multi-Portfolio Support**: Manage multiple portfolios with different strategies

### Advanced Features
- **ML-Powered Recommendations**: Tax-loss harvesting, market timing insights
- **Simulation Engine**: Preview rebalancing impact before execution
- **Target Allocation Management**: Preset strategies or custom allocations
- **Automated Price Updates**: Real-time market data integration
- **Alert System**: Notifications for drift thresholds and rebalance triggers
- **Responsive Design**: Full mobile support with progressive web app capabilities

## 🏗️ Architecture

### Technology Stack

**Frontend:**
- React 18.2
- Redux Toolkit for state management
- Material-UI (MUI) v5 for components
- Recharts & Chart.js for visualizations
- Axios for API communication
- Vite for build tooling

**Backend:**
- Java 17
- Spring Boot 3.2
- Spring Data JPA with Hibernate
- PostgreSQL database
- Apache Commons Math for calculations
- Micrometer for metrics
- SpringDoc OpenAPI for documentation

**Infrastructure:**
- Docker & Docker Compose
- Prometheus for monitoring
- Grafana for dashboards (optional)
- CI/CD ready

## 📁 Project Structure

```
portfolio-rebalancer/
├── react-frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── dashboard/
│   │   │   │   ├── KPICard.jsx
│   │   │   │   ├── AllocationChart.jsx
│   │   │   │   ├── HoldingsTable.jsx
│   │   │   │   └── DriftIndicator.jsx
│   │   │   ├── holdings/
│   │   │   ├── rebalance/
│   │   │   ├── risk/
│   │   │   └── layout/
│   │   │       ├── MainLayout.jsx
│   │   │       ├── Header.jsx
│   │   │       └── Sidebar.jsx
│   │   ├── pages/
│   │   │   ├── Dashboard.jsx
│   │   │   ├── Holdings.jsx
│   │   │   ├── Rebalance.jsx
│   │   │   ├── RiskAnalytics.jsx
│   │   │   ├── Simulation.jsx
│   │   │   ├── HistoricalDrift.jsx
│   │   │   └── Settings.jsx
│   │   ├── store/
│   │   │   ├── store.js
│   │   │   └── slices/
│   │   │       ├── portfolioSlice.js
│   │   │       ├── holdingsSlice.js
│   │   │       ├── driftSlice.js
│   │   │       ├── rebalanceSlice.js
│   │   │       ├── riskSlice.js
│   │   │       └── settingsSlice.js
│   │   ├── services/
│   │   │   └── api.js
│   │   ├── utils/
│   │   ├── App.jsx
│   │   └── main.jsx
│   ├── public/
│   ├── package.json
│   └── vite.config.js
│
├── java-backend/
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/portfolio/rebalancer/
│   │   │   │   ├── PortfolioRebalancerApplication.java
│   │   │   │   ├── controller/
│   │   │   │   │   ├── PortfolioController.java
│   │   │   │   │   ├── RebalanceController.java
│   │   │   │   │   ├── RiskAnalyticsController.java
│   │   │   │   │   └── DriftController.java
│   │   │   │   ├── service/
│   │   │   │   │   ├── PortfolioService.java
│   │   │   │   │   ├── RebalanceService.java
│   │   │   │   │   ├── DriftCalculationService.java
│   │   │   │   │   ├── RiskAnalyticsService.java
│   │   │   │   │   ├── PriceService.java
│   │   │   │   │   └── MLRecommendationService.java
│   │   │   │   ├── model/
│   │   │   │   │   ├── Portfolio.java
│   │   │   │   │   ├── Holding.java
│   │   │   │   │   ├── TargetAllocation.java
│   │   │   │   │   ├── Trade.java
│   │   │   │   │   └── DriftHistory.java
│   │   │   │   ├── repository/
│   │   │   │   │   ├── PortfolioRepository.java
│   │   │   │   │   ├── HoldingRepository.java
│   │   │   │   │   ├── TargetAllocationRepository.java
│   │   │   │   │   ├── TradeRepository.java
│   │   │   │   │   └── DriftHistoryRepository.java
│   │   │   │   ├── dto/
│   │   │   │   │   ├── PortfolioDTO.java
│   │   │   │   │   ├── HoldingDTO.java
│   │   │   │   │   ├── RebalanceRecommendationDTO.java
│   │   │   │   │   ├── RiskMetricsDTO.java
│   │   │   │   │   └── (many more DTOs)
│   │   │   │   ├── exception/
│   │   │   │   │   ├── ResourceNotFoundException.java
│   │   │   │   │   ├── ValidationException.java
│   │   │   │   │   └── GlobalExceptionHandler.java
│   │   │   │   ├── config/
│   │   │   │   │   ├── CacheConfig.java
│   │   │   │   │   ├── SchedulerConfig.java
│   │   │   │   │   └── OpenAPIConfig.java
│   │   │   │   └── scheduler/
│   │   │   │       ├── PriceUpdateScheduler.java
│   │   │   │       └── DriftCalculationScheduler.java
│   │   │   └── resources/
│   │   │       ├── application.properties
│   │   │       └── db/migration/ (Flyway migrations)
│   │   └── test/
│   │       └── java/com/portfolio/rebalancer/
│   ├── pom.xml
│   └── README.md
│
├── docker/
│   ├── docker-compose.yml
│   ├── Dockerfile.backend
│   └── Dockerfile.frontend
│
└── docs/
    ├── API.md
    ├── SETUP.md
    ├── DEPLOYMENT.md
    └── UI_DESIGN.docx
```

## 🚀 Getting Started

### Prerequisites

- Node.js 18+ and npm/yarn
- Java 17+
- Maven 3.8+
- PostgreSQL 14+
- Docker & Docker Compose (optional)

### Quick Start with Docker

```bash
# Clone the repository
git clone https://github.com/yourusername/portfolio-rebalancer.git
cd portfolio-rebalancer

# Start all services
docker-compose up -d

# Frontend: http://localhost:3000
# Backend API: http://localhost:8080
# API Docs: http://localhost:8080/swagger-ui.html
```

### Manual Setup

#### Backend Setup

```bash
cd java-backend

# Create PostgreSQL database
createdb portfolio_rebalancer

# Update application.properties with your database credentials
vim src/main/resources/application.properties

# Build and run
mvn clean install
mvn spring-boot:run

# API will be available at http://localhost:8080
```

#### Frontend Setup

```bash
cd react-frontend

# Install dependencies
npm install

# Start development server
npm run dev

# Frontend will be available at http://localhost:3000
```

## 📊 Database Schema

### Core Tables

**portfolios**
- id (PK)
- name
- user_id
- total_value
- total_cost
- drift_score
- risk_score
- drift_threshold
- created_at, updated_at

**holdings**
- id (PK)
- portfolio_id (FK)
- ticker
- name
- asset_class
- quantity
- current_price
- market_value
- cost_basis
- current_percent
- target_percent
- drift_percent
- recommended_action
- created_at, updated_at

**target_allocations**
- id (PK)
- portfolio_id (FK)
- asset_class
- target_percent

**trades**
- id (PK)
- portfolio_id (FK)
- holding_id (FK)
- action (BUY/SELL)
- quantity
- price
- executed_at

**drift_history**
- id (PK)
- portfolio_id (FK)
- drift_score
- recorded_at

## 🔧 Configuration

### Environment Variables

**Backend:**
```bash
MARKET_DATA_API_KEY=your_api_key
DATABASE_URL=jdbc:postgresql://localhost:5432/portfolio_rebalancer
DATABASE_USERNAME=postgres
DATABASE_PASSWORD=your_password
JWT_SECRET=your_secret_key
EMAIL_USERNAME=your_email
EMAIL_PASSWORD=your_email_password
ML_SERVICE_URL=http://localhost:5000
```

**Frontend:**
```bash
REACT_APP_API_BASE_URL=http://localhost:8080/api
REACT_APP_WS_URL=ws://localhost:8080/ws
```

## 📡 API Endpoints

### Portfolios
- `GET /api/portfolios` - Get all portfolios
- `GET /api/portfolios/{id}` - Get portfolio details
- `GET /api/portfolios/{id}/summary` - Get portfolio summary
- `POST /api/portfolios` - Create portfolio
- `PUT /api/portfolios/{id}` - Update portfolio
- `DELETE /api/portfolios/{id}` - Delete portfolio

### Holdings
- `GET /api/portfolios/{id}/holdings` - Get all holdings
- `GET /api/portfolios/{id}/holdings/{holdingId}` - Get holding detail
- `POST /api/portfolios/{id}/holdings` - Add holding
- `PUT /api/portfolios/{id}/holdings/{holdingId}` - Update holding
- `DELETE /api/portfolios/{id}/holdings/{holdingId}` - Delete holding

### Drift & Analytics
- `GET /api/portfolios/{id}/drift-metrics` - Get drift metrics
- `GET /api/portfolios/{id}/drift-history` - Get historical drift
- `GET /api/portfolios/{id}/allocation` - Get allocation data
- `POST /api/portfolios/{id}/recalculate-drift` - Recalculate drift

### Rebalancing
- `GET /api/portfolios/{id}/recommendations` - Get rebalance recommendations
- `POST /api/portfolios/{id}/simulate` - Simulate rebalancing
- `POST /api/portfolios/{id}/execute-rebalance` - Execute rebalancing

### Risk Analytics
- `GET /api/portfolios/{id}/risk-metrics` - Get risk metrics
- `GET /api/portfolios/{id}/stress-test` - Run stress tests
- `GET /api/portfolios/{id}/correlation-matrix` - Get correlation matrix

Full API documentation: http://localhost:8080/swagger-ui.html

## 🧪 Testing

### Backend Tests
```bash
cd java-backend
mvn test                    # Unit tests
mvn verify                  # Integration tests
mvn test jacoco:report     # Code coverage
```

### Frontend Tests
```bash
cd react-frontend
npm test                   # Jest tests
npm run test:coverage      # Coverage report
```

## 📈 Performance

- **API Response Time**: < 200ms for most endpoints
- **Price Updates**: Every 15 minutes (configurable)
- **Drift Calculation**: Hourly (configurable)
- **Database Queries**: Optimized with indexing and caching
- **Frontend Loading**: First Contentful Paint < 1.5s

## 🔒 Security

- CORS configuration for allowed origins
- Input validation on all endpoints
- SQL injection prevention via JPA
- Prepared statements for all queries
- Rate limiting on API endpoints
- JWT authentication (optional, not implemented in MVP)

## 📝 License

MIT License - see LICENSE file for details

## 👥 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

## 📞 Support

- Documentation: See `/docs` folder
- Issues: GitHub Issues
- Email: support@portfoliorebalancer.com

## 🎓 Learning Resources

- [Spring Boot Documentation](https://spring.io/projects/spring-boot)
- [React Documentation](https://react.dev/)
- [Material-UI Documentation](https://mui.com/)
- [Redux Toolkit Documentation](https://redux-toolkit.js.org/)
- [Portfolio Theory](https://en.wikipedia.org/wiki/Modern_portfolio_theory)

## 🗺️ Roadmap

### Phase 1 (MVP) ✅
- Portfolio management
- Drift detection
- Basic rebalancing recommendations
- Holdings table
- Simple dashboard

### Phase 2 (Current)
- ML-driven recommendations
- Advanced risk analytics
- Tax optimization
- Historical analysis
- Simulation engine

### Phase 3 (Planned)
- Multi-currency support
- Options strategies
- ESG scoring
- Social features
- Mobile app (React Native)
- Voice commands

## 📊 Metrics & Monitoring

- Application metrics via Micrometer
- Prometheus scraping endpoint: `/actuator/prometheus`
- Health check endpoint: `/actuator/health`
- Custom business metrics tracked
- Grafana dashboards (optional)

---

**Built with ❤️ for better portfolio management**
