package com.portfolio.rebalancer.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "holdings")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Holding {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "portfolio_id", nullable = false)
    private Portfolio portfolio;

    @Column(nullable = false, length = 20)
    private String ticker;

    @Column(nullable = false, length = 200)
    private String name;

    @Column(name = "asset_class", nullable = false, length = 50)
    private String assetClass;

    @Column(precision = 15, scale = 6)
    private BigDecimal quantity;

    @Column(name = "current_price", precision = 15, scale = 4)
    private BigDecimal currentPrice;

    @Column(name = "market_value", precision = 15, scale = 2)
    private BigDecimal marketValue;

    @Column(name = "cost_basis", precision = 15, scale = 2)
    private BigDecimal costBasis;

    @Column(name = "average_cost", precision = 15, scale = 4)
    private BigDecimal averageCost;

    @Column(name = "unrealized_gain", precision = 15, scale = 2)
    private BigDecimal unrealizedGain;

    @Column(name = "unrealized_gain_percent", precision = 10, scale = 4)
    private BigDecimal unrealizedGainPercent;

    @Column(name = "current_percent", precision = 10, scale = 4)
    private BigDecimal currentPercent;

    @Column(name = "target_percent", precision = 10, scale = 4)
    private BigDecimal targetPercent;

    @Column(name = "drift_percent", precision = 10, scale = 4)
    private BigDecimal driftPercent;

    @Column(name = "recommended_action", length = 20)
    private String recommendedAction; // BUY, SELL, HOLD

    @Column(name = "recommended_quantity", precision = 15, scale = 6)
    private BigDecimal recommendedQuantity;

    @Column(name = "day_change", precision = 15, scale = 2)
    private BigDecimal dayChange;

    @Column(name = "day_change_percent", precision = 10, scale = 4)
    private BigDecimal dayChangePercent;

    @Column(name = "dividend_yield", precision = 10, scale = 4)
    private BigDecimal dividendYield;

    @Column(name = "last_price_update")
    private LocalDateTime lastPriceUpdate;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    // Calculated fields
    @Transient
    private BigDecimal beta;

    @Transient
    private BigDecimal sharpeRatio;

    // Helper methods
    public void calculateMetrics(BigDecimal portfolioTotalValue) {
        if (portfolioTotalValue == null || portfolioTotalValue.compareTo(BigDecimal.ZERO) == 0) {
            this.currentPercent = BigDecimal.ZERO;
            this.driftPercent = BigDecimal.ZERO;
            return;
        }

        // Calculate current percent
        this.currentPercent = this.marketValue
            .divide(portfolioTotalValue, 6, BigDecimal.ROUND_HALF_UP)
            .multiply(new BigDecimal("100"));

        // Calculate drift
        if (this.targetPercent != null) {
            this.driftPercent = this.currentPercent.subtract(this.targetPercent);
        }

        // Calculate unrealized gain
        if (this.costBasis != null) {
            this.unrealizedGain = this.marketValue.subtract(this.costBasis);
            if (this.costBasis.compareTo(BigDecimal.ZERO) > 0) {
                this.unrealizedGainPercent = this.unrealizedGain
                    .divide(this.costBasis, 6, BigDecimal.ROUND_HALF_UP)
                    .multiply(new BigDecimal("100"));
            }
        }

        // Determine recommended action
        determineRecommendedAction();
    }

    private void determineRecommendedAction() {
        if (this.driftPercent == null) {
            this.recommendedAction = "HOLD";
            this.recommendedQuantity = BigDecimal.ZERO;
            return;
        }

        BigDecimal driftThreshold = new BigDecimal("1.0"); // 1% threshold
        
        if (this.driftPercent.abs().compareTo(driftThreshold) < 0) {
            this.recommendedAction = "HOLD";
            this.recommendedQuantity = BigDecimal.ZERO;
        } else if (this.driftPercent.compareTo(BigDecimal.ZERO) > 0) {
            // Overweight - SELL
            this.recommendedAction = "SELL";
            BigDecimal excessValue = this.marketValue.multiply(this.driftPercent.abs())
                .divide(this.currentPercent, 2, BigDecimal.ROUND_HALF_UP);
            this.recommendedQuantity = excessValue.divide(this.currentPrice, 6, BigDecimal.ROUND_HALF_UP);
        } else {
            // Underweight - BUY
            this.recommendedAction = "BUY";
            BigDecimal deficitValue = this.marketValue.multiply(this.driftPercent.abs())
                .divide(this.currentPercent, 2, BigDecimal.ROUND_HALF_UP);
            this.recommendedQuantity = deficitValue.divide(this.currentPrice, 6, BigDecimal.ROUND_HALF_UP);
        }
    }

    public void updatePrice(BigDecimal newPrice) {
        if (newPrice != null && this.currentPrice != null) {
            this.dayChange = newPrice.subtract(this.currentPrice)
                .multiply(this.quantity);
            
            if (this.currentPrice.compareTo(BigDecimal.ZERO) > 0) {
                this.dayChangePercent = newPrice.subtract(this.currentPrice)
                    .divide(this.currentPrice, 6, BigDecimal.ROUND_HALF_UP)
                    .multiply(new BigDecimal("100"));
            }
        }
        
        this.currentPrice = newPrice;
        this.marketValue = this.quantity.multiply(newPrice);
        this.lastPriceUpdate = LocalDateTime.now();
    }
}
