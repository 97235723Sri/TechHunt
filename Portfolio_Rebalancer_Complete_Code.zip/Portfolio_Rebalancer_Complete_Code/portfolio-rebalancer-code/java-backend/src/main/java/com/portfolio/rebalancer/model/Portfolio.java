package com.portfolio.rebalancer.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "portfolios")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Portfolio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String name;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "total_value", precision = 15, scale = 2)
    private BigDecimal totalValue;

    @Column(name = "total_cost", precision = 15, scale = 2)
    private BigDecimal totalCost;

    @Column(name = "unrealized_gain", precision = 15, scale = 2)
    private BigDecimal unrealizedGain;

    @Column(name = "unrealized_gain_percent", precision = 10, scale = 4)
    private BigDecimal unrealizedGainPercent;

    @Column(name = "day_change", precision = 15, scale = 2)
    private BigDecimal dayChange;

    @Column(name = "day_change_percent", precision = 10, scale = 4)
    private BigDecimal dayChangePercent;

    @Column(name = "last_rebalance_date")
    private LocalDateTime lastRebalanceDate;

    @Column(name = "drift_score", precision = 10, scale = 4)
    private BigDecimal driftScore;

    @Column(name = "risk_score", precision = 10, scale = 2)
    private BigDecimal riskScore;

    @Column(name = "drift_threshold", precision = 10, scale = 4)
    private BigDecimal driftThreshold = new BigDecimal("5.0");

    @Column(name = "rebalance_frequency_days")
    private Integer rebalanceFrequencyDays = 30;

    @Column(name = "is_active")
    private Boolean isActive = true;

    @OneToMany(mappedBy = "portfolio", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Holding> holdings = new ArrayList<>();

    @OneToMany(mappedBy = "portfolio", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<TargetAllocation> targetAllocations = new ArrayList<>();

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    // Helper methods
    public void addHolding(Holding holding) {
        holdings.add(holding);
        holding.setPortfolio(this);
    }

    public void removeHolding(Holding holding) {
        holdings.remove(holding);
        holding.setPortfolio(null);
    }

    public void addTargetAllocation(TargetAllocation allocation) {
        targetAllocations.add(allocation);
        allocation.setPortfolio(this);
    }

    public void calculateDriftScore() {
        if (holdings.isEmpty() || targetAllocations.isEmpty()) {
            this.driftScore = BigDecimal.ZERO;
            return;
        }

        BigDecimal totalDrift = BigDecimal.ZERO;
        int count = 0;

        for (Holding holding : holdings) {
            BigDecimal currentPercent = holding.getCurrentPercent();
            BigDecimal targetPercent = getTargetPercentForAssetClass(holding.getAssetClass());
            
            if (targetPercent != null) {
                BigDecimal drift = currentPercent.subtract(targetPercent).abs();
                totalDrift = totalDrift.add(drift);
                count++;
            }
        }

        this.driftScore = count > 0 ? totalDrift.divide(new BigDecimal(count), 4, BigDecimal.ROUND_HALF_UP) : BigDecimal.ZERO;
    }

    private BigDecimal getTargetPercentForAssetClass(String assetClass) {
        return targetAllocations.stream()
            .filter(ta -> ta.getAssetClass().equalsIgnoreCase(assetClass))
            .findFirst()
            .map(TargetAllocation::getTargetPercent)
            .orElse(null);
    }
}
