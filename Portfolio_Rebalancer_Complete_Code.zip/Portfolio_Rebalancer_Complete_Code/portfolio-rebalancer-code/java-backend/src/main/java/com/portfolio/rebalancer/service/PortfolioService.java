package com.portfolio.rebalancer.service;

import com.portfolio.rebalancer.dto.*;
import com.portfolio.rebalancer.exception.ResourceNotFoundException;
import com.portfolio.rebalancer.model.Holding;
import com.portfolio.rebalancer.model.Portfolio;
import com.portfolio.rebalancer.model.TargetAllocation;
import com.portfolio.rebalancer.repository.HoldingRepository;
import com.portfolio.rebalancer.repository.PortfolioRepository;
import com.portfolio.rebalancer.repository.TargetAllocationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class PortfolioService {

    private final PortfolioRepository portfolioRepository;
    private final HoldingRepository holdingRepository;
    private final TargetAllocationRepository targetAllocationRepository;
    private final PriceService priceService;
    private final DriftCalculationService driftCalculationService;

    public List<PortfolioSummaryDTO> getAllPortfolios(Long userId) {
        List<Portfolio> portfolios = userId != null 
            ? portfolioRepository.findByUserId(userId)
            : portfolioRepository.findAll();
        
        return portfolios.stream()
            .map(this::convertToSummaryDTO)
            .collect(Collectors.toList());
    }

    public PortfolioDTO getPortfolioById(Long portfolioId) {
        Portfolio portfolio = findPortfolioOrThrow(portfolioId);
        return convertToDTO(portfolio);
    }

    public PortfolioSummaryDTO getPortfolioSummary(Long portfolioId) {
        Portfolio portfolio = findPortfolioOrThrow(portfolioId);
        return convertToSummaryDTO(portfolio);
    }

    public PortfolioDTO createPortfolio(CreatePortfolioRequest request) {
        Portfolio portfolio = new Portfolio();
        portfolio.setName(request.getName());
        portfolio.setUserId(request.getUserId());
        portfolio.setTotalValue(BigDecimal.ZERO);
        portfolio.setTotalCost(BigDecimal.ZERO);
        portfolio.setDriftThreshold(request.getDriftThreshold() != null 
            ? request.getDriftThreshold() 
            : new BigDecimal("5.0"));
        portfolio.setRebalanceFrequencyDays(request.getRebalanceFrequencyDays() != null 
            ? request.getRebalanceFrequencyDays() 
            : 30);
        
        Portfolio saved = portfolioRepository.save(portfolio);
        log.info("Created new portfolio: {}", saved.getId());
        
        return convertToDTO(saved);
    }

    public PortfolioDTO updatePortfolio(Long portfolioId, UpdatePortfolioRequest request) {
        Portfolio portfolio = findPortfolioOrThrow(portfolioId);
        
        if (request.getName() != null) {
            portfolio.setName(request.getName());
        }
        if (request.getDriftThreshold() != null) {
            portfolio.setDriftThreshold(request.getDriftThreshold());
        }
        if (request.getRebalanceFrequencyDays() != null) {
            portfolio.setRebalanceFrequencyDays(request.getRebalanceFrequencyDays());
        }
        
        Portfolio saved = portfolioRepository.save(portfolio);
        log.info("Updated portfolio: {}", portfolioId);
        
        return convertToDTO(saved);
    }

    public void deletePortfolio(Long portfolioId) {
        if (!portfolioRepository.existsById(portfolioId)) {
            throw new ResourceNotFoundException("Portfolio not found with id: " + portfolioId);
        }
        portfolioRepository.deleteById(portfolioId);
        log.info("Deleted portfolio: {}", portfolioId);
    }

    public List<HoldingDTO> getHoldings(Long portfolioId) {
        findPortfolioOrThrow(portfolioId);
        List<Holding> holdings = holdingRepository.findByPortfolioIdOrderByMarketValueDesc(portfolioId);
        return holdings.stream()
            .map(this::convertToHoldingDTO)
            .collect(Collectors.toList());
    }

    public HoldingDetailDTO getHoldingDetail(Long portfolioId, Long holdingId) {
        Holding holding = findHoldingOrThrow(portfolioId, holdingId);
        return convertToHoldingDetailDTO(holding);
    }

    public HoldingDTO addHolding(Long portfolioId, CreateHoldingRequest request) {
        Portfolio portfolio = findPortfolioOrThrow(portfolioId);
        
        Holding holding = new Holding();
        holding.setPortfolio(portfolio);
        holding.setTicker(request.getTicker());
        holding.setName(request.getName());
        holding.setAssetClass(request.getAssetClass());
        holding.setQuantity(request.getQuantity());
        holding.setAverageCost(request.getAverageCost());
        holding.setCostBasis(request.getQuantity().multiply(request.getAverageCost()));
        
        // Fetch current price
        BigDecimal currentPrice = priceService.getCurrentPrice(request.getTicker());
        holding.setCurrentPrice(currentPrice);
        holding.setMarketValue(request.getQuantity().multiply(currentPrice));
        holding.setLastPriceUpdate(LocalDateTime.now());
        
        // Get target allocation for this asset class
        TargetAllocation targetAllocation = targetAllocationRepository
            .findByPortfolioIdAndAssetClass(portfolioId, request.getAssetClass())
            .orElse(null);
        
        if (targetAllocation != null) {
            holding.setTargetPercent(targetAllocation.getTargetPercent());
        }
        
        Holding saved = holdingRepository.save(holding);
        
        // Recalculate portfolio metrics
        recalculatePortfolioMetrics(portfolio);
        
        log.info("Added holding {} to portfolio {}", saved.getTicker(), portfolioId);
        
        return convertToHoldingDTO(saved);
    }

    public HoldingDTO updateHolding(Long portfolioId, Long holdingId, UpdateHoldingRequest request) {
        Holding holding = findHoldingOrThrow(portfolioId, holdingId);
        
        if (request.getQuantity() != null) {
            holding.setQuantity(request.getQuantity());
            holding.setMarketValue(request.getQuantity().multiply(holding.getCurrentPrice()));
            holding.setCostBasis(request.getQuantity().multiply(holding.getAverageCost()));
        }
        
        if (request.getAverageCost() != null) {
            holding.setAverageCost(request.getAverageCost());
            holding.setCostBasis(holding.getQuantity().multiply(request.getAverageCost()));
        }
        
        Holding saved = holdingRepository.save(holding);
        
        // Recalculate portfolio metrics
        recalculatePortfolioMetrics(holding.getPortfolio());
        
        log.info("Updated holding {} in portfolio {}", holdingId, portfolioId);
        
        return convertToHoldingDTO(saved);
    }

    public void deleteHolding(Long portfolioId, Long holdingId) {
        Holding holding = findHoldingOrThrow(portfolioId, holdingId);
        Portfolio portfolio = holding.getPortfolio();
        
        holdingRepository.delete(holding);
        
        // Recalculate portfolio metrics
        recalculatePortfolioMetrics(portfolio);
        
        log.info("Deleted holding {} from portfolio {}", holdingId, portfolioId);
    }

    public DriftMetricsDTO getDriftMetrics(Long portfolioId) {
        Portfolio portfolio = findPortfolioOrThrow(portfolioId);
        return driftCalculationService.calculateDriftMetrics(portfolio);
    }

    public List<DriftHistoryDTO> getDriftHistory(Long portfolioId, String period) {
        findPortfolioOrThrow(portfolioId);
        return driftCalculationService.getDriftHistory(portfolioId, period);
    }

    public AllocationDataDTO getAllocationData(Long portfolioId) {
        Portfolio portfolio = findPortfolioOrThrow(portfolioId);
        return driftCalculationService.calculateAllocationData(portfolio);
    }

    public List<TargetAllocationDTO> getTargetAllocations(Long portfolioId) {
        findPortfolioOrThrow(portfolioId);
        List<TargetAllocation> allocations = targetAllocationRepository.findByPortfolioId(portfolioId);
        return allocations.stream()
            .map(this::convertToTargetAllocationDTO)
            .collect(Collectors.toList());
    }

    public List<TargetAllocationDTO> updateTargetAllocations(
            Long portfolioId, 
            List<UpdateTargetAllocationRequest> requests) {
        
        Portfolio portfolio = findPortfolioOrThrow(portfolioId);
        
        // Validate total equals 100%
        BigDecimal total = requests.stream()
            .map(UpdateTargetAllocationRequest::getTargetPercent)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        if (total.compareTo(new BigDecimal("100.00")) != 0) {
            throw new IllegalArgumentException("Target allocations must sum to 100%. Current sum: " + total);
        }
        
        // Clear existing allocations
        targetAllocationRepository.deleteByPortfolioId(portfolioId);
        
        // Create new allocations
        List<TargetAllocation> allocations = requests.stream()
            .map(req -> {
                TargetAllocation allocation = new TargetAllocation();
                allocation.setPortfolio(portfolio);
                allocation.setAssetClass(req.getAssetClass());
                allocation.setTargetPercent(req.getTargetPercent());
                return allocation;
            })
            .collect(Collectors.toList());
        
        List<TargetAllocation> saved = targetAllocationRepository.saveAll(allocations);
        
        // Update target percentages in holdings
        updateHoldingsTargetPercents(portfolio);
        
        // Recalculate drift
        recalculatePortfolioMetrics(portfolio);
        
        log.info("Updated target allocations for portfolio {}", portfolioId);
        
        return saved.stream()
            .map(this::convertToTargetAllocationDTO)
            .collect(Collectors.toList());
    }

    public PortfolioSummaryDTO refreshPrices(Long portfolioId) {
        Portfolio portfolio = findPortfolioOrThrow(portfolioId);
        List<Holding> holdings = holdingRepository.findByPortfolioId(portfolioId);
        
        for (Holding holding : holdings) {
            BigDecimal newPrice = priceService.getCurrentPrice(holding.getTicker());
            holding.updatePrice(newPrice);
            holdingRepository.save(holding);
        }
        
        recalculatePortfolioMetrics(portfolio);
        
        log.info("Refreshed prices for portfolio {}", portfolioId);
        
        return convertToSummaryDTO(portfolio);
    }

    public DriftMetricsDTO recalculateDrift(Long portfolioId) {
        Portfolio portfolio = findPortfolioOrThrow(portfolioId);
        recalculatePortfolioMetrics(portfolio);
        return driftCalculationService.calculateDriftMetrics(portfolio);
    }

    // Private helper methods
    
    private Portfolio findPortfolioOrThrow(Long portfolioId) {
        return portfolioRepository.findById(portfolioId)
            .orElseThrow(() -> new ResourceNotFoundException("Portfolio not found with id: " + portfolioId));
    }

    private Holding findHoldingOrThrow(Long portfolioId, Long holdingId) {
        return holdingRepository.findByIdAndPortfolioId(holdingId, portfolioId)
            .orElseThrow(() -> new ResourceNotFoundException(
                "Holding not found with id: " + holdingId + " in portfolio: " + portfolioId));
    }

    private void recalculatePortfolioMetrics(Portfolio portfolio) {
        List<Holding> holdings = holdingRepository.findByPortfolioId(portfolio.getId());
        
        // Calculate total value and cost
        BigDecimal totalValue = holdings.stream()
            .map(Holding::getMarketValue)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        BigDecimal totalCost = holdings.stream()
            .map(Holding::getCostBasis)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        portfolio.setTotalValue(totalValue);
        portfolio.setTotalCost(totalCost);
        portfolio.setUnrealizedGain(totalValue.subtract(totalCost));
        
        if (totalCost.compareTo(BigDecimal.ZERO) > 0) {
            portfolio.setUnrealizedGainPercent(
                portfolio.getUnrealizedGain()
                    .divide(totalCost, 6, BigDecimal.ROUND_HALF_UP)
                    .multiply(new BigDecimal("100"))
            );
        }
        
        // Calculate day change
        BigDecimal dayChange = holdings.stream()
            .map(Holding::getDayChange)
            .filter(dc -> dc != null)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        portfolio.setDayChange(dayChange);
        
        if (totalValue.compareTo(BigDecimal.ZERO) > 0) {
            portfolio.setDayChangePercent(
                dayChange.divide(totalValue.subtract(dayChange), 6, BigDecimal.ROUND_HALF_UP)
                    .multiply(new BigDecimal("100"))
            );
        }
        
        // Update holding metrics
        for (Holding holding : holdings) {
            holding.calculateMetrics(totalValue);
            holdingRepository.save(holding);
        }
        
        // Calculate drift score
        portfolio.calculateDriftScore();
        
        // Calculate risk score (simplified)
        portfolio.setRiskScore(driftCalculationService.calculateRiskScore(portfolio));
        
        portfolioRepository.save(portfolio);
    }

    private void updateHoldingsTargetPercents(Portfolio portfolio) {
        List<Holding> holdings = holdingRepository.findByPortfolioId(portfolio.getId());
        
        for (Holding holding : holdings) {
            TargetAllocation targetAllocation = targetAllocationRepository
                .findByPortfolioIdAndAssetClass(portfolio.getId(), holding.getAssetClass())
                .orElse(null);
            
            if (targetAllocation != null) {
                holding.setTargetPercent(targetAllocation.getTargetPercent());
                holding.calculateMetrics(portfolio.getTotalValue());
                holdingRepository.save(holding);
            }
        }
    }

    // DTO conversion methods
    
    private PortfolioDTO convertToDTO(Portfolio portfolio) {
        return PortfolioDTO.builder()
            .id(portfolio.getId())
            .name(portfolio.getName())
            .userId(portfolio.getUserId())
            .totalValue(portfolio.getTotalValue())
            .totalCost(portfolio.getTotalCost())
            .unrealizedGain(portfolio.getUnrealizedGain())
            .unrealizedGainPercent(portfolio.getUnrealizedGainPercent())
            .dayChange(portfolio.getDayChange())
            .dayChangePercent(portfolio.getDayChangePercent())
            .lastRebalanceDate(portfolio.getLastRebalanceDate())
            .driftScore(portfolio.getDriftScore())
            .riskScore(portfolio.getRiskScore())
            .driftThreshold(portfolio.getDriftThreshold())
            .rebalanceFrequencyDays(portfolio.getRebalanceFrequencyDays())
            .createdAt(portfolio.getCreatedAt())
            .updatedAt(portfolio.getUpdatedAt())
            .build();
    }

    private PortfolioSummaryDTO convertToSummaryDTO(Portfolio portfolio) {
        return PortfolioSummaryDTO.builder()
            .id(portfolio.getId())
            .name(portfolio.getName())
            .totalValue(portfolio.getTotalValue())
            .unrealizedGain(portfolio.getUnrealizedGain())
            .unrealizedGainPercent(portfolio.getUnrealizedGainPercent())
            .dayChange(portfolio.getDayChange())
            .dayChangePercent(portfolio.getDayChangePercent())
            .lastRebalanceDate(portfolio.getLastRebalanceDate())
            .driftScore(portfolio.getDriftScore())
            .riskScore(portfolio.getRiskScore())
            .build();
    }

    private HoldingDTO convertToHoldingDTO(Holding holding) {
        return HoldingDTO.builder()
            .id(holding.getId())
            .ticker(holding.getTicker())
            .name(holding.getName())
            .assetClass(holding.getAssetClass())
            .quantity(holding.getQuantity())
            .currentPrice(holding.getCurrentPrice())
            .marketValue(holding.getMarketValue())
            .costBasis(holding.getCostBasis())
            .unrealizedGain(holding.getUnrealizedGain())
            .unrealizedGainPercent(holding.getUnrealizedGainPercent())
            .currentPercent(holding.getCurrentPercent())
            .targetPercent(holding.getTargetPercent())
            .drift(holding.getDriftPercent())
            .recommendedAction(holding.getRecommendedAction())
            .recommendedQuantity(holding.getRecommendedQuantity())
            .dayChange(holding.getDayChange())
            .dayChangePercent(holding.getDayChangePercent())
            .build();
    }

    private HoldingDetailDTO convertToHoldingDetailDTO(Holding holding) {
        HoldingDetailDTO dto = new HoldingDetailDTO();
        // Copy all fields from HoldingDTO
        dto.setId(holding.getId());
        dto.setTicker(holding.getTicker());
        dto.setName(holding.getName());
        dto.setAssetClass(holding.getAssetClass());
        dto.setQuantity(holding.getQuantity());
        dto.setCurrentPrice(holding.getCurrentPrice());
        dto.setMarketValue(holding.getMarketValue());
        dto.setCostBasis(holding.getCostBasis());
        dto.setUnrealizedGain(holding.getUnrealizedGain());
        dto.setUnrealizedGainPercent(holding.getUnrealizedGainPercent());
        dto.setCurrentPercent(holding.getCurrentPercent());
        dto.setTargetPercent(holding.getTargetPercent());
        dto.setDrift(holding.getDriftPercent());
        dto.setRecommendedAction(holding.getRecommendedAction());
        dto.setDayChange(holding.getDayChange());
        dto.setDayChangePercent(holding.getDayChangePercent());
        
        // Additional detail fields
        dto.setAverageCost(holding.getAverageCost());
        dto.setDividendYield(holding.getDividendYield());
        dto.setLastPriceUpdate(holding.getLastPriceUpdate());
        
        return dto;
    }

    private TargetAllocationDTO convertToTargetAllocationDTO(TargetAllocation allocation) {
        return TargetAllocationDTO.builder()
            .id(allocation.getId())
            .assetClass(allocation.getAssetClass())
            .targetPercent(allocation.getTargetPercent())
            .build();
    }
}
