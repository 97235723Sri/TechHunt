package com.portfolio.rebalancer.controller;

import com.portfolio.rebalancer.dto.*;
import com.portfolio.rebalancer.service.PortfolioService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/portfolios")
@RequiredArgsConstructor
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:3001"})
public class PortfolioController {

    private final PortfolioService portfolioService;

    @GetMapping
    public ResponseEntity<List<PortfolioSummaryDTO>> getAllPortfolios(
            @RequestParam(required = false) Long userId) {
        List<PortfolioSummaryDTO> portfolios = portfolioService.getAllPortfolios(userId);
        return ResponseEntity.ok(portfolios);
    }

    @GetMapping("/{portfolioId}")
    public ResponseEntity<PortfolioDTO> getPortfolio(@PathVariable Long portfolioId) {
        PortfolioDTO portfolio = portfolioService.getPortfolioById(portfolioId);
        return ResponseEntity.ok(portfolio);
    }

    @GetMapping("/{portfolioId}/summary")
    public ResponseEntity<PortfolioSummaryDTO> getPortfolioSummary(@PathVariable Long portfolioId) {
        PortfolioSummaryDTO summary = portfolioService.getPortfolioSummary(portfolioId);
        return ResponseEntity.ok(summary);
    }

    @PostMapping
    public ResponseEntity<PortfolioDTO> createPortfolio(@Valid @RequestBody CreatePortfolioRequest request) {
        PortfolioDTO portfolio = portfolioService.createPortfolio(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(portfolio);
    }

    @PutMapping("/{portfolioId}")
    public ResponseEntity<PortfolioDTO> updatePortfolio(
            @PathVariable Long portfolioId,
            @Valid @RequestBody UpdatePortfolioRequest request) {
        PortfolioDTO portfolio = portfolioService.updatePortfolio(portfolioId, request);
        return ResponseEntity.ok(portfolio);
    }

    @DeleteMapping("/{portfolioId}")
    public ResponseEntity<Void> deletePortfolio(@PathVariable Long portfolioId) {
        portfolioService.deletePortfolio(portfolioId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{portfolioId}/holdings")
    public ResponseEntity<List<HoldingDTO>> getHoldings(@PathVariable Long portfolioId) {
        List<HoldingDTO> holdings = portfolioService.getHoldings(portfolioId);
        return ResponseEntity.ok(holdings);
    }

    @GetMapping("/{portfolioId}/holdings/{holdingId}")
    public ResponseEntity<HoldingDetailDTO> getHoldingDetail(
            @PathVariable Long portfolioId,
            @PathVariable Long holdingId) {
        HoldingDetailDTO holding = portfolioService.getHoldingDetail(portfolioId, holdingId);
        return ResponseEntity.ok(holding);
    }

    @PostMapping("/{portfolioId}/holdings")
    public ResponseEntity<HoldingDTO> addHolding(
            @PathVariable Long portfolioId,
            @Valid @RequestBody CreateHoldingRequest request) {
        HoldingDTO holding = portfolioService.addHolding(portfolioId, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(holding);
    }

    @PutMapping("/{portfolioId}/holdings/{holdingId}")
    public ResponseEntity<HoldingDTO> updateHolding(
            @PathVariable Long portfolioId,
            @PathVariable Long holdingId,
            @Valid @RequestBody UpdateHoldingRequest request) {
        HoldingDTO holding = portfolioService.updateHolding(portfolioId, holdingId, request);
        return ResponseEntity.ok(holding);
    }

    @DeleteMapping("/{portfolioId}/holdings/{holdingId}")
    public ResponseEntity<Void> deleteHolding(
            @PathVariable Long portfolioId,
            @PathVariable Long holdingId) {
        portfolioService.deleteHolding(portfolioId, holdingId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{portfolioId}/drift-metrics")
    public ResponseEntity<DriftMetricsDTO> getDriftMetrics(@PathVariable Long portfolioId) {
        DriftMetricsDTO metrics = portfolioService.getDriftMetrics(portfolioId);
        return ResponseEntity.ok(metrics);
    }

    @GetMapping("/{portfolioId}/drift-history")
    public ResponseEntity<List<DriftHistoryDTO>> getDriftHistory(
            @PathVariable Long portfolioId,
            @RequestParam(required = false) String period) {
        List<DriftHistoryDTO> history = portfolioService.getDriftHistory(portfolioId, period);
        return ResponseEntity.ok(history);
    }

    @GetMapping("/{portfolioId}/allocation")
    public ResponseEntity<AllocationDataDTO> getAllocationData(@PathVariable Long portfolioId) {
        AllocationDataDTO allocation = portfolioService.getAllocationData(portfolioId);
        return ResponseEntity.ok(allocation);
    }

    @GetMapping("/{portfolioId}/target-allocations")
    public ResponseEntity<List<TargetAllocationDTO>> getTargetAllocations(@PathVariable Long portfolioId) {
        List<TargetAllocationDTO> allocations = portfolioService.getTargetAllocations(portfolioId);
        return ResponseEntity.ok(allocations);
    }

    @PutMapping("/{portfolioId}/target-allocations")
    public ResponseEntity<List<TargetAllocationDTO>> updateTargetAllocations(
            @PathVariable Long portfolioId,
            @Valid @RequestBody List<UpdateTargetAllocationRequest> requests) {
        List<TargetAllocationDTO> allocations = portfolioService.updateTargetAllocations(portfolioId, requests);
        return ResponseEntity.ok(allocations);
    }

    @PostMapping("/{portfolioId}/refresh-prices")
    public ResponseEntity<PortfolioSummaryDTO> refreshPrices(@PathVariable Long portfolioId) {
        PortfolioSummaryDTO summary = portfolioService.refreshPrices(portfolioId);
        return ResponseEntity.ok(summary);
    }

    @PostMapping("/{portfolioId}/recalculate-drift")
    public ResponseEntity<DriftMetricsDTO> recalculateDrift(@PathVariable Long portfolioId) {
        DriftMetricsDTO metrics = portfolioService.recalculateDrift(portfolioId);
        return ResponseEntity.ok(metrics);
    }
}
