# Quick Start Guide - Engine Integration

## 🚀 5-Minute Integration

### Step 1: Download Files (30 seconds)
Download the complete integration package from `/mnt/user-data/outputs/integrated_codebase/`

### Step 2: Backup Your Code (30 seconds)
```bash
git checkout -b backup-before-engine-integration
git commit -am "Backup before engine integration"
```

### Step 3: Copy Files (1 minute)
```bash
# Copy modified files (these REPLACE existing files)
cp PortfolioController.java src/main/java/com/portfolio/rebalancer/controller/
cp RebalanceService.java src/main/java/com/portfolio/rebalancer/service/
cp SimulationService.java src/main/java/com/portfolio/rebalancer/service/

# Copy new engine modules (these are ALL NEW)
cp -r engines/* src/main/java/com/portfolio/rebalancer/engine/
cp EngineConfiguration.java src/main/java/com/portfolio/rebalancer/config/
```

### Step 4: Update Configuration (1 minute)
Add to `application.yml`:
```yaml
portfolio:
  rebalancer:
    engines:
      enabled: true
```

### Step 5: Update Main Class (30 seconds)
```java
@SpringBootApplication
@ComponentScan(basePackages = {
    "com.portfolio.rebalancer",
    "com.portfolio.rebalancer.engine"  // ADD THIS LINE
})
public class PortfolioRebalancerApplication { ... }
```

### Step 6: Build & Test (2 minutes)
```bash
mvn clean install
mvn spring-boot:run
```

### Step 7: Verify (30 seconds)
```bash
# Test recommendation engine
curl http://localhost:8080/api/portfolios/123/rebalance/recommendations

# Test simulation engine
curl -X POST http://localhost:8080/api/portfolios/123/simulate \
  -H "Content-Type: application/json" \
  -d '{"scenarioName":"Test","trades":[]}'
```

---

## ✅ Done!

You now have:
- ✅ 11 new API endpoints
- ✅ Recommendation Engine (ML-powered rebalancing)
- ✅ Simulation Engine (What-if analysis)
- ✅ All existing functionality preserved
- ✅ Backward compatible
- ✅ Production ready

---

## 🆘 Troubleshooting

**Issue:** Compilation errors
**Fix:** Run `mvn clean install -U` to update dependencies

**Issue:** Beans not found
**Fix:** Verify `@ComponentScan` includes `com.portfolio.rebalancer.engine`

**Issue:** 404 on new endpoints
**Fix:** Check controller mapping in logs: `grep "Mapped.*rebalance" logs/app.log`

---

## 📞 Support

See `INTEGRATION_COMPLETE_PACKAGE.md` for detailed documentation
