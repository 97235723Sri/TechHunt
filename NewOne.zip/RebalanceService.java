package com.portfolio.rebalancer.service;

import com.portfolio.rebalancer.dto.*;
import com.portfolio.rebalancer.model.*;
import com.portfolio.rebalancer.repository.*;
import com.portfolio.rebalancer.engine.recommendation.RecommendationEngine;
import com.portfolio.rebalancer.engine.recommendation.model.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * MODIFIED Rebalance Service with Recommendation Engine Integration
 * 
 * This service now uses the Recommendation Engine for all rebalancing logic:
 * - Generating recommendations
 * - Tax optimization
 * - ML-driven insights
 * - Cost calculation
 * - Risk analysis
 */
@Service
@Slf4j
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class RebalanceService {

    // Existing repositories
    private final PortfolioRepository portfolioRepository;
    private final HoldingRepository holdingRepository;
    private final TargetAllocationRepository targetAllocationRepository;
    private final RebalanceHistoryRepository rebalanceHistoryRepository;
    private final TradeExecutionRepository tradeExecutionRepository;
    
    // NEW: Recommendation Engine injection
    private final RecommendationEngine recommendationEngine;
    
    /**
     * Get comprehensive rebalancing recommendations
     * NOW POWERED BY RECOMMENDATION ENGINE
     */
    public RebalanceRecommendationDTO getRecommendations(
            Long portfolioId,
            String strategy,
            Double driftThreshold,
            Boolean considerTaxes) {
        
        log.info("Getting recommendations for portfolio {} using strategy {}", 
            portfolioId, strategy);
        
        // Load portfolio data
        Portfolio portfolio = portfolioRepository.findById(portfolioId)
            .orElseThrow(() -> new ResourceNotFoundException("Portfolio not found: " + portfolioId));
        
        List<Holding> holdings = holdingRepository.findByPortfolioId(portfolioId);
        if (holdings.isEmpty()) {
            throw new BusinessException("Portfolio has no holdings");
        }
        
        List<TargetAllocation> targets = targetAllocationRepository.findByPortfolioId(portfolioId);
        if (targets.isEmpty()) {
            throw new BusinessException("Portfolio has no target allocations defined");
        }
        
        // Build options for recommendation engine
        RecommendationOptions options = RecommendationOptions.builder()
            .considerTaxes(considerTaxes != null ? considerTaxes : true)
            .driftThreshold(driftThreshold != null ? 
                BigDecimal.valueOf(driftThreshold) : 
                BigDecimal.valueOf(5.0))
            .minTradeValue(BigDecimal.valueOf(100))
            .maxTradesPerAssetClass(5)
            .preferredLotMethod(LotSelectionMethod.HIFO)
            .build();
        
        // Parse strategy
        RecommendationStrategy recommendationStrategy;
        try {
            recommendationStrategy = RecommendationStrategy.valueOf(strategy.toUpperCase());
        } catch (IllegalArgumentException e) {
            log.warn("Invalid strategy '{}', defaulting to RECOMMENDED", strategy);
            recommendationStrategy = RecommendationStrategy.RECOMMENDED;
        }
        
        // ** USE RECOMMENDATION ENGINE **
        RecommendationResult engineResult = recommendationEngine.generateRecommendations(
            portfolio,
            holdings,
            targets,
            recommendationStrategy,
            options
        );
        
        log.info("Recommendation engine generated {} trades", engineResult.getTrades().size());
        
        // Convert engine result to DTO
        return convertEngineResultToDTO(engineResult);
    }
    
    /**
     * Get detailed trade recommendations
     */
    public List<TradeRecommendationDTO> getTradeDetails(
            Long portfolioId,
            String strategy) {
        
        // Get recommendations from engine
        RebalanceRecommendationDTO recommendations = getRecommendations(
            portfolioId, strategy, null, true);
        
        // Combine sell and buy orders
        List<TradeRecommendationDTO> allTrades = new ArrayList<>();
        allTrades.addAll(recommendations.getSellOrders());
        allTrades.addAll(recommendations.getBuyOrders());
        
        return allTrades;
    }
    
    /**
     * Execute rebalancing trades
     */
    @Transactional
    public ExecutionResultDTO executeRebalance(
            Long portfolioId,
            ExecuteRebalanceRequest request) {
        
        log.info("Executing rebalance for portfolio {} with {} trades", 
            portfolioId, request.getTrades().size());
        
        Portfolio portfolio = portfolioRepository.findById(portfolioId)
            .orElseThrow(() -> new ResourceNotFoundException("Portfolio not found"));
        
        // Validate mode
        if (request.getValidateOnly()) {
            log.info("Validation mode - not executing trades");
            return performValidation(portfolio, request);
        }
        
        // Create execution record
        RebalanceHistory execution = RebalanceHistory.builder()
            .portfolioId(portfolioId)
            .recommendationId(request.getRecommendationId())
            .strategy(request.getExecutionStrategy())
            .status(ExecutionStatus.IN_PROGRESS)
            .totalTrades(request.getTrades().size())
            .startedAt(LocalDateTime.now())
            .build();
        execution = rebalanceHistoryRepository.save(execution);
        
        // Execute trades
        List<TradeResultDTO> results = new ArrayList<>();
        int successCount = 0;
        int failureCount = 0;
        BigDecimal totalCost = BigDecimal.ZERO;
        
        for (TradeExecutionDTO tradeRequest : request.getTrades()) {
            if (!tradeRequest.getExecute()) {
                log.info("Skipping trade {}", tradeRequest.getTradeId());
                continue;
            }
            
            try {
                TradeResultDTO result = executeSingleTrade(
                    portfolio, tradeRequest, execution.getId());
                results.add(result);
                
                if ("SUCCESS".equals(result.getStatus())) {
                    successCount++;
                    totalCost = totalCost.add(result.getFees());
                } else {
                    failureCount++;
                }
            } catch (Exception e) {
                log.error("Failed to execute trade {}: {}", tradeRequest.getTradeId(), e.getMessage());
                failureCount++;
                results.add(TradeResultDTO.builder()
                    .tradeId(tradeRequest.getTradeId())
                    .status("FAILED")
                    .errorMessage(e.getMessage())
                    .build());
            }
        }
        
        // Calculate new drift
        List<Holding> updatedHoldings = holdingRepository.findByPortfolioId(portfolioId);
        BigDecimal newDrift = calculatePortfolioDrift(updatedHoldings, portfolioId);
        
        // Update execution record
        execution.setStatus(failureCount == 0 ? 
            ExecutionStatus.COMPLETED : ExecutionStatus.PARTIAL);
        execution.setExecutedTrades(successCount);
        execution.setFailedTrades(failureCount);
        execution.setTotalCost(totalCost);
        execution.setDriftAfter(newDrift);
        execution.setCompletedAt(LocalDateTime.now());
        rebalanceHistoryRepository.save(execution);
        
        // Recalculate portfolio metrics
        portfolio.setCurrentDrift(newDrift);
        portfolioRepository.save(portfolio);
        
        return ExecutionResultDTO.builder()
            .executionId(execution.getId().toString())
            .status(execution.getStatus().name())
            .executedTrades(successCount)
            .failedTrades(failureCount)
            .totalCost(totalCost)
            .results(results)
            .newDrift(newDrift)
            .newRiskScore(calculateRiskScore(updatedHoldings))
            .executedAt(LocalDateTime.now())
            .build();
    }
    
    /**
     * Calculate tax impact
     */
    public TaxImpactDTO calculateTaxImpact(
            Long portfolioId,
            String recommendationId,
            List<Long> tradeIds) {
        
        log.info("Calculating tax impact for portfolio {}", portfolioId);
        
        // Get holdings
        List<Holding> holdings = holdingRepository.findByPortfolioId(portfolioId);
        
        // Get recommendations if ID provided
        List<TradeRecommendationDTO> trades = new ArrayList<>();
        if (recommendationId != null) {
            RebalanceRecommendationDTO recommendations = getRecommendations(
                portfolioId, "RECOMMENDED", null, true);
            trades.addAll(recommendations.getSellOrders());
        }
        
        // Calculate realized gains/losses
        BigDecimal totalGains = BigDecimal.ZERO;
        BigDecimal totalLosses = BigDecimal.ZERO;
        List<TaxBreakdownDTO> breakdown = new ArrayList<>();
        
        for (TradeRecommendationDTO trade : trades) {
            if (!"SELL".equals(trade.getAction())) continue;
            
            Holding holding = holdings.stream()
                .filter(h -> h.getTicker().equals(trade.getTicker()))
                .findFirst()
                .orElse(null);
            
            if (holding != null) {
                BigDecimal costBasis = holding.getAverageCost()
                    .multiply(BigDecimal.valueOf(trade.getRecommendedQuantity()));
                BigDecimal proceeds = trade.getCurrentPrice()
                    .multiply(BigDecimal.valueOf(trade.getRecommendedQuantity()));
                BigDecimal gain = proceeds.subtract(costBasis);
                
                if (gain.compareTo(BigDecimal.ZERO) > 0) {
                    totalGains = totalGains.add(gain);
                } else {
                    totalLosses = totalLosses.add(gain);
                }
                
                String holdingPeriod = trade.getHoldingPeriodDays() > 365 ? 
                    "LONG_TERM" : "SHORT_TERM";
                BigDecimal taxRate = holdingPeriod.equals("LONG_TERM") ? 
                    BigDecimal.valueOf(0.20) : BigDecimal.valueOf(0.35);
                
                breakdown.add(TaxBreakdownDTO.builder()
                    .ticker(trade.getTicker())
                    .costBasis(costBasis)
                    .saleProceeds(proceeds)
                    .gain(gain)
                    .holdingPeriod(holdingPeriod)
                    .taxRate(taxRate)
                    .estimatedTax(gain.multiply(taxRate))
                    .build());
            }
        }
        
        BigDecimal netGains = totalGains.add(totalLosses);
        BigDecimal estimatedTax = netGains.multiply(BigDecimal.valueOf(0.35));
        
        // Find tax-loss harvesting opportunities
        List<TaxLossHarvestingDTO> harvestingOps = findTaxLossHarvestingOpportunities(holdings);
        
        return TaxImpactDTO.builder()
            .totalRealizedGains(totalGains)
            .totalRealizedLosses(totalLosses)
            .netGains(netGains)
            .estimatedTaxLiability(estimatedTax)
            .taxRate(BigDecimal.valueOf(35.0))
            .breakdown(breakdown)
            .taxLossHarvestingOpportunities(harvestingOps)
            .build();
    }
    
    /**
     * Get ML insights
     */
    public MLInsightsDTO getMLInsights(Long portfolioId) {
        // Get recommendations which include ML insights
        RebalanceRecommendationDTO recommendations = getRecommendations(
            portfolioId, "ML_OPTIMIZED", null, true);
        
        return MLInsightsDTO.builder()
            .insights(recommendations.getMlInsights())
            .confidenceScore(85.0)
            .build();
    }
    
    // ========================================================================
    // CONVERSION METHODS
    // ========================================================================
    
    /**
     * Convert Recommendation Engine result to DTO
     */
    private RebalanceRecommendationDTO convertEngineResultToDTO(
            RecommendationResult engineResult) {
        
        // Separate sell and buy orders
        List<TradeRecommendationDTO> sellOrders = engineResult.getTrades().stream()
            .filter(t -> t.getAction() == TradeAction.SELL)
            .map(this::convertEngineTradeToDTO)
            .collect(Collectors.toList());
        
        List<TradeRecommendationDTO> buyOrders = engineResult.getTrades().stream()
            .filter(t -> t.getAction() == TradeAction.BUY)
            .map(this::convertEngineTradeToDTO)
            .collect(Collectors.toList());
        
        // Build summary
        BigDecimal totalSellValue = sellOrders.stream()
            .map(TradeRecommendationDTO::getEstimatedValue)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        BigDecimal totalBuyValue = buyOrders.stream()
            .map(TradeRecommendationDTO::getEstimatedValue)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        BigDecimal estimatedFees = BigDecimal.valueOf(engineResult.getTrades().size() * 7);
        BigDecimal estimatedTax = engineResult.getCosts() != null ? 
            engineResult.getCosts().getEstimatedTax() : BigDecimal.ZERO;
        
        RebalanceSummaryDTO summary = RebalanceSummaryDTO.builder()
            .totalTrades(engineResult.getTrades().size())
            .totalSellValue(totalSellValue)
            .totalBuyValue(totalBuyValue)
            .estimatedFees(estimatedFees)
            .netCashFlow(totalSellValue.subtract(totalBuyValue).subtract(estimatedFees))
            .expectedDriftReduction(engineResult.getExpectedImpact() != null ?
                engineResult.getExpectedImpact().getDriftReduction() : BigDecimal.ZERO)
            .estimatedTaxImpact(estimatedTax)
            .breakEvenDays(calculateBreakEvenDays(estimatedFees, engineResult))
            .build();
        
        // Build expected impact
        ExpectedImpactDTO impact = buildExpectedImpact(engineResult.getExpectedImpact());
        
        // Convert ML insights
        List<MLInsightDTO> insights = convertMLInsights(engineResult.getMlInsights());
        
        return RebalanceRecommendationDTO.builder()
            .recommendationId(engineResult.getRecommendationId())
            .portfolioId(engineResult.getPortfolioId())
            .currentDrift(engineResult.getCurrentState().getOverallDrift())
            .targetDrift(BigDecimal.ZERO)
            .strategy(engineResult.getStrategy().name())
            .sellOrders(sellOrders)
            .buyOrders(buyOrders)
            .summary(summary)
            .expectedImpact(impact)
            .mlInsights(insights)
            .warnings(engineResult.getWarnings())
            .generatedAt(LocalDateTime.now())
            .expiresAt(LocalDateTime.now().plusHours(2))
            .build();
    }
    
    /**
     * Convert engine trade to DTO
     */
    private TradeRecommendationDTO convertEngineTradeToDTO(RecommendedTrade engineTrade) {
        return TradeRecommendationDTO.builder()
            .tradeId(engineTrade.getTradeId())
            .ticker(engineTrade.getTicker())
            .companyName(engineTrade.getCompanyName())
            .assetClass(engineTrade.getAssetClass())
            .action(engineTrade.getAction().name())
            .currentQuantity(engineTrade.getCurrentQuantity())
            .recommendedQuantity(engineTrade.getRecommendedQuantity())
            .currentPrice(engineTrade.getCurrentPrice())
            .estimatedValue(engineTrade.getEstimatedValue())
            .currentAllocation(engineTrade.getCurrentAllocation())
            .targetAllocation(engineTrade.getTargetAllocation())
            .drift(engineTrade.getDrift())
            .reason(engineTrade.getReason())
            .priority(engineTrade.getPriority().name())
            .taxImpact(engineTrade.getTaxImpact())
            .lotSelection(engineTrade.getLotSelection() != null ? 
                engineTrade.getLotSelection().name() : "FIFO")
            .holdingPeriodDays(engineTrade.getHoldingPeriodDays())
            .build();
    }
    
    /**
     * Build expected impact DTO
     */
    private ExpectedImpactDTO buildExpectedImpact(ExpectedImpact engineImpact) {
        if (engineImpact == null) {
            return ExpectedImpactDTO.builder().build();
        }
        
        return ExpectedImpactDTO.builder()
            .beforeRisk(engineImpact.getRiskScoreBefore())
            .afterRisk(engineImpact.getRiskScoreAfter())
            .riskImprovement(calculateImprovement(
                engineImpact.getRiskScoreBefore(),
                engineImpact.getRiskScoreAfter()))
            .beforeSharpe(engineImpact.getSharpeRatioBefore())
            .afterSharpe(engineImpact.getSharpeRatioAfter())
            .beforeVolatility(engineImpact.getVolatilityBefore())
            .afterVolatility(engineImpact.getVolatilityAfter())
            .beforeVar(engineImpact.getVarBefore())
            .afterVar(engineImpact.getVarAfter())
            .build();
    }
    
    /**
     * Convert ML insights
     */
    private List<MLInsightDTO> convertMLInsights(List<MLInsight> engineInsights) {
        if (engineInsights == null) {
            return Collections.emptyList();
        }
        
        return engineInsights.stream()
            .map(insight -> MLInsightDTO.builder()
                .type(insight.getType())
                .confidence(insight.getConfidence())
                .message(insight.getMessage())
                .potentialSavings(insight.getPotentialSavings())
                .expectedImpact(insight.getExpectedImpact())
                .actionItems(insight.getActionItems())
                .build())
            .collect(Collectors.toList());
    }
    
    // ========================================================================
    // HELPER METHODS
    // ========================================================================
    
    private TradeResultDTO executeSingleTrade(
            Portfolio portfolio,
            TradeExecutionDTO tradeRequest,
            Long executionId) {
        
        // Implementation would integrate with actual brokerage API
        // For now, simulate successful execution
        
        return TradeResultDTO.builder()
            .tradeId(tradeRequest.getTradeId())
            .ticker("AAPL") // Would come from trade request
            .status("SUCCESS")
            .requestedQuantity(10)
            .executedQuantity(10)
            .requestedPrice(BigDecimal.valueOf(182.45))
            .executedPrice(BigDecimal.valueOf(182.50))
            .totalValue(BigDecimal.valueOf(1825.00))
            .fees(BigDecimal.valueOf(7.00))
            .build();
    }
    
    private ExecutionResultDTO performValidation(
            Portfolio portfolio,
            ExecuteRebalanceRequest request) {
        // Validate trades without executing
        return ExecutionResultDTO.builder()
            .executionId("validation-" + UUID.randomUUID())
            .status("VALIDATED")
            .executedTrades(0)
            .failedTrades(0)
            .totalCost(BigDecimal.ZERO)
            .results(Collections.emptyList())
            .build();
    }
    
    private BigDecimal calculatePortfolioDrift(List<Holding> holdings, Long portfolioId) {
        // Simplified drift calculation
        return BigDecimal.valueOf(2.5);
    }
    
    private Integer calculateRiskScore(List<Holding> holdings) {
        // Simplified risk score
        return 78;
    }
    
    private Integer calculateBreakEvenDays(BigDecimal costs, RecommendationResult result) {
        // Estimate days to recover transaction costs
        return 45;
    }
    
    private Double calculateImprovement(Integer before, Integer after) {
        if (before == 0) return 0.0;
        return ((after - before) * 100.0) / before;
    }
    
    private List<TaxLossHarvestingDTO> findTaxLossHarvestingOpportunities(
            List<Holding> holdings) {
        
        return holdings.stream()
            .filter(h -> {
                BigDecimal currentValue = h.getCurrentPrice()
                    .multiply(BigDecimal.valueOf(h.getQuantity()));
                return currentValue.compareTo(h.getCostBasis()) < 0;
            })
            .map(h -> {
                BigDecimal loss = h.getCostBasis().subtract(
                    h.getCurrentPrice().multiply(BigDecimal.valueOf(h.getQuantity())));
                
                return TaxLossHarvestingDTO.builder()
                    .ticker(h.getTicker())
                    .unrealizedLoss(loss)
                    .potentialTaxSavings(loss.multiply(BigDecimal.valueOf(0.35)))
                    .replacementSuggestions(suggestReplacements(h))
                    .washSaleRisk("LOW")
                    .build();
            })
            .collect(Collectors.toList());
    }
    
    private List<String> suggestReplacements(Holding holding) {
        // Suggest similar securities to avoid wash sale
        return Arrays.asList("SPY", "VOO", "IVV");
    }
}
