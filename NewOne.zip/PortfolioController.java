package com.portfolio.rebalancer.controller;

import com.portfolio.rebalancer.dto.*;
import com.portfolio.rebalancer.service.PortfolioService;
import com.portfolio.rebalancer.service.RebalanceService;
import com.portfolio.rebalancer.service.SimulationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;

/**
 * MODIFIED Portfolio Controller with Engine Integration
 * 
 * Now includes:
 * - Rebalancing recommendations via Recommendation Engine
 * - Simulation capabilities via Simulation Engine
 * - All existing portfolio management features
 */
@RestController
@RequestMapping("/api/portfolios")
@RequiredArgsConstructor
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:3001"})
public class PortfolioController {

    private final PortfolioService portfolioService;
    // NEW: Inject engine-backed services
    private final RebalanceService rebalanceService;
    private final SimulationService simulationService;

    // ========================================================================
    // EXISTING ENDPOINTS (Unchanged)
    // ========================================================================
    
    @GetMapping
    public ResponseEntity<List<PortfolioSummaryDTO>> getAllPortfolios(
            @RequestParam(required = false) Long userId) {
        List<PortfolioSummaryDTO> portfolios = portfolioService.getAllPortfolios(userId);
        return ResponseEntity.ok(portfolios);
    }

    @GetMapping("/{portfolioId}")
    public ResponseEntity<PortfolioDTO> getPortfolio(@PathVariable Long portfolioId) {
        PortfolioDTO portfolio = portfolioService.getPortfolioById(portfolioId);
        return ResponseEntity.ok(portfolio);
    }

    @GetMapping("/{portfolioId}/summary")
    public ResponseEntity<PortfolioSummaryDTO> getPortfolioSummary(@PathVariable Long portfolioId) {
        PortfolioSummaryDTO summary = portfolioService.getPortfolioSummary(portfolioId);
        return ResponseEntity.ok(summary);
    }

    @PostMapping
    public ResponseEntity<PortfolioDTO> createPortfolio(@Valid @RequestBody CreatePortfolioRequest request) {
        PortfolioDTO portfolio = portfolioService.createPortfolio(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(portfolio);
    }

    @PutMapping("/{portfolioId}")
    public ResponseEntity<PortfolioDTO> updatePortfolio(
            @PathVariable Long portfolioId,
            @Valid @RequestBody UpdatePortfolioRequest request) {
        PortfolioDTO portfolio = portfolioService.updatePortfolio(portfolioId, request);
        return ResponseEntity.ok(portfolio);
    }

    @DeleteMapping("/{portfolioId}")
    public ResponseEntity<Void> deletePortfolio(@PathVariable Long portfolioId) {
        portfolioService.deletePortfolio(portfolioId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{portfolioId}/holdings")
    public ResponseEntity<List<HoldingDTO>> getHoldings(@PathVariable Long portfolioId) {
        List<HoldingDTO> holdings = portfolioService.getHoldings(portfolioId);
        return ResponseEntity.ok(holdings);
    }

    @GetMapping("/{portfolioId}/holdings/{holdingId}")
    public ResponseEntity<HoldingDetailDTO> getHoldingDetail(
            @PathVariable Long portfolioId,
            @PathVariable Long holdingId) {
        HoldingDetailDTO holding = portfolioService.getHoldingDetail(portfolioId, holdingId);
        return ResponseEntity.ok(holding);
    }

    @PostMapping("/{portfolioId}/holdings")
    public ResponseEntity<HoldingDTO> addHolding(
            @PathVariable Long portfolioId,
            @Valid @RequestBody CreateHoldingRequest request) {
        HoldingDTO holding = portfolioService.addHolding(portfolioId, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(holding);
    }

    @PutMapping("/{portfolioId}/holdings/{holdingId}")
    public ResponseEntity<HoldingDTO> updateHolding(
            @PathVariable Long portfolioId,
            @PathVariable Long holdingId,
            @Valid @RequestBody UpdateHoldingRequest request) {
        HoldingDTO holding = portfolioService.updateHolding(portfolioId, holdingId, request);
        return ResponseEntity.ok(holding);
    }

    @DeleteMapping("/{portfolioId}/holdings/{holdingId}")
    public ResponseEntity<Void> deleteHolding(
            @PathVariable Long portfolioId,
            @PathVariable Long holdingId) {
        portfolioService.deleteHolding(portfolioId, holdingId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{portfolioId}/drift-metrics")
    public ResponseEntity<DriftMetricsDTO> getDriftMetrics(@PathVariable Long portfolioId) {
        DriftMetricsDTO metrics = portfolioService.getDriftMetrics(portfolioId);
        return ResponseEntity.ok(metrics);
    }

    @GetMapping("/{portfolioId}/drift-history")
    public ResponseEntity<List<DriftHistoryDTO>> getDriftHistory(
            @PathVariable Long portfolioId,
            @RequestParam(required = false) String period) {
        List<DriftHistoryDTO> history = portfolioService.getDriftHistory(portfolioId, period);
        return ResponseEntity.ok(history);
    }

    @GetMapping("/{portfolioId}/allocation")
    public ResponseEntity<AllocationDataDTO> getAllocationData(@PathVariable Long portfolioId) {
        AllocationDataDTO allocation = portfolioService.getAllocationData(portfolioId);
        return ResponseEntity.ok(allocation);
    }

    @GetMapping("/{portfolioId}/target-allocations")
    public ResponseEntity<List<TargetAllocationDTO>> getTargetAllocations(@PathVariable Long portfolioId) {
        List<TargetAllocationDTO> allocations = portfolioService.getTargetAllocations(portfolioId);
        return ResponseEntity.ok(allocations);
    }

    @PutMapping("/{portfolioId}/target-allocations")
    public ResponseEntity<List<TargetAllocationDTO>> updateTargetAllocations(
            @PathVariable Long portfolioId,
            @Valid @RequestBody List<UpdateTargetAllocationRequest> requests) {
        List<TargetAllocationDTO> allocations = portfolioService.updateTargetAllocations(portfolioId, requests);
        return ResponseEntity.ok(allocations);
    }

    @PostMapping("/{portfolioId}/refresh-prices")
    public ResponseEntity<PortfolioSummaryDTO> refreshPrices(@PathVariable Long portfolioId) {
        PortfolioSummaryDTO summary = portfolioService.refreshPrices(portfolioId);
        return ResponseEntity.ok(summary);
    }

    @PostMapping("/{portfolioId}/recalculate-drift")
    public ResponseEntity<DriftMetricsDTO> recalculateDrift(@PathVariable Long portfolioId) {
        DriftMetricsDTO metrics = portfolioService.recalculateDrift(portfolioId);
        return ResponseEntity.ok(metrics);
    }
    
    // ========================================================================
    // NEW ENDPOINTS: RECOMMENDATION ENGINE INTEGRATION
    // ========================================================================
    
    /**
     * Get AI-powered rebalancing recommendations
     * Uses Recommendation Engine under the hood
     * 
     * GET /api/portfolios/{portfolioId}/rebalance/recommendations
     */
    @GetMapping("/{portfolioId}/rebalance/recommendations")
    public ResponseEntity<RebalanceRecommendationDTO> getRebalanceRecommendations(
            @PathVariable Long portfolioId,
            @RequestParam(required = false, defaultValue = "RECOMMENDED") String strategy,
            @RequestParam(required = false) Double driftThreshold,
            @RequestParam(required = false, defaultValue = "true") Boolean considerTaxes) {
        
        RebalanceRecommendationDTO recommendations = rebalanceService.getRecommendations(
            portfolioId, strategy, driftThreshold, considerTaxes);
        return ResponseEntity.ok(recommendations);
    }
    
    /**
     * Get detailed trade breakdown
     * 
     * GET /api/portfolios/{portfolioId}/rebalance/trades
     */
    @GetMapping("/{portfolioId}/rebalance/trades")
    public ResponseEntity<List<TradeRecommendationDTO>> getTradeDetails(
            @PathVariable Long portfolioId,
            @RequestParam(required = false, defaultValue = "RECOMMENDED") String strategy) {
        
        List<TradeRecommendationDTO> trades = rebalanceService.getTradeDetails(
            portfolioId, strategy);
        return ResponseEntity.ok(trades);
    }
    
    /**
     * Execute rebalancing trades
     * 
     * POST /api/portfolios/{portfolioId}/rebalance/execute
     */
    @PostMapping("/{portfolioId}/rebalance/execute")
    public ResponseEntity<ExecutionResultDTO> executeRebalance(
            @PathVariable Long portfolioId,
            @Valid @RequestBody ExecuteRebalanceRequest request) {
        
        ExecutionResultDTO result = rebalanceService.executeRebalance(portfolioId, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(result);
    }
    
    /**
     * Calculate tax impact of rebalancing
     * 
     * GET /api/portfolios/{portfolioId}/rebalance/tax-impact
     */
    @GetMapping("/{portfolioId}/rebalance/tax-impact")
    public ResponseEntity<TaxImpactDTO> calculateTaxImpact(
            @PathVariable Long portfolioId,
            @RequestParam(required = false) String recommendationId) {
        
        TaxImpactDTO impact = rebalanceService.calculateTaxImpact(
            portfolioId, recommendationId, null);
        return ResponseEntity.ok(impact);
    }
    
    /**
     * Get ML insights for rebalancing
     * 
     * GET /api/portfolios/{portfolioId}/rebalance/ml-insights
     */
    @GetMapping("/{portfolioId}/rebalance/ml-insights")
    public ResponseEntity<MLInsightsDTO> getMLInsights(@PathVariable Long portfolioId) {
        MLInsightsDTO insights = rebalanceService.getMLInsights(portfolioId);
        return ResponseEntity.ok(insights);
    }
    
    // ========================================================================
    // NEW ENDPOINTS: SIMULATION ENGINE INTEGRATION
    // ========================================================================
    
    /**
     * Run portfolio rebalancing simulation
     * Uses Simulation Engine under the hood
     * 
     * POST /api/portfolios/{portfolioId}/simulate
     */
    @PostMapping("/{portfolioId}/simulate")
    public ResponseEntity<SimulationResultDTO> runSimulation(
            @PathVariable Long portfolioId,
            @Valid @RequestBody SimulationRequest request) {
        
        SimulationResultDTO result = simulationService.runSimulation(portfolioId, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(result);
    }
    
    /**
     * Get existing simulation results
     * 
     * GET /api/portfolios/{portfolioId}/simulations/{simulationId}
     */
    @GetMapping("/{portfolioId}/simulations/{simulationId}")
    public ResponseEntity<SimulationResultDTO> getSimulation(
            @PathVariable Long portfolioId,
            @PathVariable Long simulationId) {
        
        SimulationResultDTO result = simulationService.getSimulation(portfolioId, simulationId);
        return ResponseEntity.ok(result);
    }
    
    /**
     * Compare multiple scenarios
     * 
     * POST /api/portfolios/{portfolioId}/simulate/compare
     */
    @PostMapping("/{portfolioId}/simulate/compare")
    public ResponseEntity<ComparisonResultDTO> compareScenarios(
            @PathVariable Long portfolioId,
            @Valid @RequestBody CompareRequest request) {
        
        ComparisonResultDTO comparison = simulationService.compareScenarios(portfolioId, request);
        return ResponseEntity.ok(comparison);
    }
    
    /**
     * ML-optimized allocation simulation
     * 
     * POST /api/portfolios/{portfolioId}/simulate/optimize
     */
    @PostMapping("/{portfolioId}/simulate/optimize")
    public ResponseEntity<OptimizedSimulationDTO> optimizeAllocation(
            @PathVariable Long portfolioId,
            @Valid @RequestBody OptimizationRequest request) {
        
        OptimizedSimulationDTO result = simulationService.optimizeAllocation(portfolioId, request);
        return ResponseEntity.ok(result);
    }
    
    /**
     * Quick impact preview (no save)
     * 
     * POST /api/portfolios/{portfolioId}/simulate/preview
     */
    @PostMapping("/{portfolioId}/simulate/preview")
    public ResponseEntity<ImpactPreviewDTO> previewImpact(
            @PathVariable Long portfolioId,
            @Valid @RequestBody List<TradeDTO> trades) {
        
        ImpactPreviewDTO preview = simulationService.previewImpact(portfolioId, trades);
        return ResponseEntity.ok(preview);
    }
    
    /**
     * List simulation history
     * 
     * GET /api/portfolios/{portfolioId}/simulations
     */
    @GetMapping("/{portfolioId}/simulations")
    public ResponseEntity<List<SimulationSummaryDTO>> listSimulations(
            @PathVariable Long portfolioId,
            @RequestParam(required = false, defaultValue = "10") Integer limit) {
        
        List<SimulationSummaryDTO> simulations = simulationService.listSimulations(
            portfolioId, limit, null);
        return ResponseEntity.ok(simulations);
    }
}
