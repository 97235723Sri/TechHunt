package com.portfolio.rebalancer.engine.recommendation;

import com.portfolio.rebalancer.model.*;
import com.portfolio.rebalancer.dto.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Recommendation Engine
 * 
 * Core engine that generates intelligent rebalancing recommendations based on:
 * - Portfolio drift analysis
 * - Target allocation strategy
 * - Risk optimization
 * - Tax efficiency
 * - ML-driven insights
 * - Market conditions
 * 
 * Features:
 * - Multiple recommendation strategies (RECOMMENDED, ML_OPTIMIZED, TAX_EFFICIENT, COST_MINIMIZED)
 * - Lot selection optimization (FIFO, LIFO, HIFO, SPECIFIC_ID)
 * - Tax-loss harvesting opportunities
 * - Market timing insights
 * - Cost optimization
 */
@Slf4j
@Component
public class RecommendationEngine {

    private final DriftCalculator driftCalculator;
    private final RiskAnalyzer riskAnalyzer;
    private final TaxOptimizer taxOptimizer;
    private final MLRecommender mlRecommender;
    private final CostCalculator costCalculator;
    
    public RecommendationEngine(
            DriftCalculator driftCalculator,
            RiskAnalyzer riskAnalyzer,
            TaxOptimizer taxOptimizer,
            MLRecommender mlRecommender,
            CostCalculator costCalculator) {
        this.driftCalculator = driftCalculator;
        this.riskAnalyzer = riskAnalyzer;
        this.taxOptimizer = taxOptimizer;
        this.mlRecommender = mlRecommender;
        this.costCalculator = costCalculator;
    }
    
    /**
     * Generate comprehensive rebalancing recommendations
     */
    public RecommendationResult generateRecommendations(
            Portfolio portfolio,
            List<Holding> holdings,
            List<TargetAllocation> targets,
            RecommendationStrategy strategy,
            RecommendationOptions options) {
        
        log.info("Generating recommendations for portfolio {} using strategy {}", 
            portfolio.getId(), strategy);
        
        // Step 1: Calculate current state
        PortfolioState currentState = analyzeCurrentState(portfolio, holdings, targets);
        
        // Step 2: Generate trades based on strategy
        List<RecommendedTrade> trades = switch(strategy) {
            case RECOMMENDED -> generateStandardRecommendations(currentState, holdings, targets);
            case ML_OPTIMIZED -> generateMLOptimizedRecommendations(currentState, holdings, targets, options);
            case TAX_EFFICIENT -> generateTaxEfficientRecommendations(currentState, holdings, targets, options);
            case COST_MINIMIZED -> generateCostMinimizedRecommendations(currentState, holdings, targets);
        };
        
        // Step 3: Optimize trades
        trades = optimizeTrades(trades, currentState, options);
        
        // Step 4: Calculate expected impact
        ExpectedImpact impact = calculateExpectedImpact(currentState, trades, holdings);
        
        // Step 5: Calculate costs
        CostAnalysis costs = costCalculator.calculateCosts(trades, options);
        
        // Step 6: Generate ML insights
        List<MLInsight> insights = mlRecommender.generateInsights(
            portfolio, holdings, trades, currentState);
        
        // Step 7: Validate and add warnings
        List<String> warnings = validateRecommendations(trades, currentState, options);
        
        // Build result
        return RecommendationResult.builder()
            .recommendationId(UUID.randomUUID().toString())
            .portfolioId(portfolio.getId())
            .strategy(strategy)
            .currentState(currentState)
            .trades(trades)
            .expectedImpact(impact)
            .costs(costs)
            .mlInsights(insights)
            .warnings(warnings)
            .build();
    }
    
    /**
     * Analyze current portfolio state
     */
    private PortfolioState analyzeCurrentState(
            Portfolio portfolio, 
            List<Holding> holdings, 
            List<TargetAllocation> targets) {
        
        // Calculate total value
        BigDecimal totalValue = holdings.stream()
            .map(h -> h.getCurrentPrice().multiply(BigDecimal.valueOf(h.getQuantity())))
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        // Calculate current allocations
        Map<String, AllocationInfo> allocations = calculateAllocations(holdings, totalValue, targets);
        
        // Calculate overall drift
        BigDecimal overallDrift = driftCalculator.calculateOverallDrift(allocations);
        
        // Calculate risk metrics
        RiskMetrics risk = riskAnalyzer.analyzeRisk(holdings, portfolio);
        
        return PortfolioState.builder()
            .totalValue(totalValue)
            .allocations(allocations)
            .overallDrift(overallDrift)
            .riskMetrics(risk)
            .holdingsCount(holdings.size())
            .build();
    }
    
    /**
     * Generate standard rebalancing recommendations
     */
    private List<RecommendedTrade> generateStandardRecommendations(
            PortfolioState state,
            List<Holding> holdings,
            List<TargetAllocation> targets) {
        
        List<RecommendedTrade> trades = new ArrayList<>();
        
        // Group holdings by asset class
        Map<String, List<Holding>> byAssetClass = holdings.stream()
            .collect(Collectors.groupingBy(Holding::getAssetClass));
        
        for (TargetAllocation target : targets) {
            String assetClass = target.getAssetClass();
            AllocationInfo allocation = state.getAllocations().get(assetClass);
            
            if (allocation == null) continue;
            
            BigDecimal drift = allocation.getCurrentPct()
                .subtract(allocation.getTargetPct());
            
            // Check if rebalancing is needed
            if (drift.abs().compareTo(target.getDriftTolerance()) > 0) {
                
                // Determine action
                if (drift.compareTo(BigDecimal.ZERO) > 0) {
                    // Overweight - need to SELL
                    trades.addAll(generateSellTrades(
                        byAssetClass.get(assetClass), 
                        allocation, 
                        target,
                        state.getTotalValue()
                    ));
                } else {
                    // Underweight - need to BUY
                    trades.addAll(generateBuyTrades(
                        byAssetClass.get(assetClass),
                        allocation,
                        target,
                        state.getTotalValue()
                    ));
                }
            }
        }
        
        return trades;
    }
    
    /**
     * Generate ML-optimized recommendations
     */
    private List<RecommendedTrade> generateMLOptimizedRecommendations(
            PortfolioState state,
            List<Holding> holdings,
            List<TargetAllocation> targets,
            RecommendationOptions options) {
        
        log.info("Generating ML-optimized recommendations");
        
        // Get ML suggestions for optimal allocation
        OptimalAllocation optimal = mlRecommender.findOptimalAllocation(
            state, holdings, targets, options);
        
        // Generate trades to achieve optimal allocation
        List<RecommendedTrade> trades = generateTradesForAllocation(
            holdings, optimal, state.getTotalValue());
        
        // Apply ML-based optimizations
        trades = mlRecommender.optimizeTrades(trades, state, options);
        
        return trades;
    }
    
    /**
     * Generate tax-efficient recommendations
     */
    private List<RecommendedTrade> generateTaxEfficientRecommendations(
            PortfolioState state,
            List<Holding> holdings,
            List<TargetAllocation> targets,
            RecommendationOptions options) {
        
        log.info("Generating tax-efficient recommendations");
        
        // First get standard recommendations
        List<RecommendedTrade> trades = generateStandardRecommendations(state, holdings, targets);
        
        // Apply tax optimization
        trades = taxOptimizer.optimizeForTaxes(trades, holdings, options);
        
        // Add tax-loss harvesting opportunities
        List<RecommendedTrade> harvestingTrades = taxOptimizer.findTaxLossHarvestingOpportunities(
            holdings, state);
        trades.addAll(harvestingTrades);
        
        return trades;
    }
    
    /**
     * Generate cost-minimized recommendations
     */
    private List<RecommendedTrade> generateCostMinimizedRecommendations(
            PortfolioState state,
            List<Holding> holdings,
            List<TargetAllocation> targets) {
        
        log.info("Generating cost-minimized recommendations");
        
        // Get standard recommendations
        List<RecommendedTrade> trades = generateStandardRecommendations(state, holdings, targets);
        
        // Minimize number of trades
        trades = costCalculator.minimizeTrades(trades, state);
        
        // Batch similar orders
        trades = costCalculator.batchOrders(trades);
        
        return trades;
    }
    
    /**
     * Generate SELL trades for overweight positions
     */
    private List<RecommendedTrade> generateSellTrades(
            List<Holding> holdings,
            AllocationInfo allocation,
            TargetAllocation target,
            BigDecimal totalValue) {
        
        List<RecommendedTrade> trades = new ArrayList<>();
        
        // Calculate how much to sell
        BigDecimal targetValue = totalValue.multiply(target.getTargetPercentage())
            .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
        BigDecimal currentValue = allocation.getCurrentValue();
        BigDecimal sellValue = currentValue.subtract(targetValue);
        
        // Sort holdings by priority (e.g., highest gain first, or tax-efficient)
        List<Holding> sorted = holdings.stream()
            .sorted((h1, h2) -> {
                // Sell positions with highest gains first (can be customized)
                BigDecimal gain1 = calculateGain(h1);
                BigDecimal gain2 = calculateGain(h2);
                return gain2.compareTo(gain1);
            })
            .toList();
        
        BigDecimal remainingToSell = sellValue;
        
        for (Holding holding : sorted) {
            if (remainingToSell.compareTo(BigDecimal.ZERO) <= 0) break;
            
            BigDecimal holdingValue = holding.getCurrentPrice()
                .multiply(BigDecimal.valueOf(holding.getQuantity()));
            
            // Calculate quantity to sell
            int quantityToSell = remainingToSell.divide(holding.getCurrentPrice(), 0, RoundingMode.DOWN)
                .min(BigDecimal.valueOf(holding.getQuantity()))
                .intValue();
            
            if (quantityToSell > 0) {
                trades.add(RecommendedTrade.builder()
                    .tradeId(UUID.randomUUID().toString())
                    .ticker(holding.getTicker())
                    .companyName(holding.getCompanyName())
                    .assetClass(holding.getAssetClass())
                    .action(TradeAction.SELL)
                    .currentQuantity(holding.getQuantity())
                    .recommendedQuantity(quantityToSell)
                    .currentPrice(holding.getCurrentPrice())
                    .estimatedValue(holding.getCurrentPrice()
                        .multiply(BigDecimal.valueOf(quantityToSell)))
                    .currentAllocation(allocation.getCurrentPct())
                    .targetAllocation(target.getTargetPercentage())
                    .drift(allocation.getDrift())
                    .reason("Overweight - reduce to target allocation")
                    .priority(determinePriority(allocation.getDrift()))
                    .build());
                
                remainingToSell = remainingToSell.subtract(
                    holding.getCurrentPrice().multiply(BigDecimal.valueOf(quantityToSell)));
            }
        }
        
        return trades;
    }
    
    /**
     * Generate BUY trades for underweight positions
     */
    private List<RecommendedTrade> generateBuyTrades(
            List<Holding> holdings,
            AllocationInfo allocation,
            TargetAllocation target,
            BigDecimal totalValue) {
        
        List<RecommendedTrade> trades = new ArrayList<>();
        
        // Calculate how much to buy
        BigDecimal targetValue = totalValue.multiply(target.getTargetPercentage())
            .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
        BigDecimal currentValue = allocation.getCurrentValue();
        BigDecimal buyValue = targetValue.subtract(currentValue);
        
        // If no existing holdings in this asset class, need to suggest what to buy
        if (holdings == null || holdings.isEmpty()) {
            // Suggest representative ETF for this asset class
            String suggestedTicker = suggestRepresentativeETF(target.getAssetClass());
            BigDecimal suggestedPrice = BigDecimal.valueOf(100); // Placeholder
            
            int quantityToBuy = buyValue.divide(suggestedPrice, 0, RoundingMode.DOWN).intValue();
            
            trades.add(RecommendedTrade.builder()
                .tradeId(UUID.randomUUID().toString())
                .ticker(suggestedTicker)
                .assetClass(target.getAssetClass())
                .action(TradeAction.BUY)
                .recommendedQuantity(quantityToBuy)
                .currentPrice(suggestedPrice)
                .estimatedValue(buyValue)
                .currentAllocation(allocation.getCurrentPct())
                .targetAllocation(target.getTargetPercentage())
                .drift(allocation.getDrift())
                .reason("Underweight - increase " + target.getAssetClass() + " exposure")
                .priority(determinePriority(allocation.getDrift()))
                .build());
        } else {
            // Distribute purchases across existing holdings proportionally
            BigDecimal totalCurrentValue = holdings.stream()
                .map(h -> h.getCurrentPrice().multiply(BigDecimal.valueOf(h.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
            
            for (Holding holding : holdings) {
                BigDecimal holdingValue = holding.getCurrentPrice()
                    .multiply(BigDecimal.valueOf(holding.getQuantity()));
                BigDecimal proportion = holdingValue.divide(totalCurrentValue, 4, RoundingMode.HALF_UP);
                BigDecimal thisHoldingBuyValue = buyValue.multiply(proportion);
                
                int quantityToBuy = thisHoldingBuyValue
                    .divide(holding.getCurrentPrice(), 0, RoundingMode.DOWN)
                    .intValue();
                
                if (quantityToBuy > 0) {
                    trades.add(RecommendedTrade.builder()
                        .tradeId(UUID.randomUUID().toString())
                        .ticker(holding.getTicker())
                        .companyName(holding.getCompanyName())
                        .assetClass(holding.getAssetClass())
                        .action(TradeAction.BUY)
                        .currentQuantity(holding.getQuantity())
                        .recommendedQuantity(quantityToBuy)
                        .currentPrice(holding.getCurrentPrice())
                        .estimatedValue(thisHoldingBuyValue)
                        .currentAllocation(allocation.getCurrentPct())
                        .targetAllocation(target.getTargetPercentage())
                        .drift(allocation.getDrift())
                        .reason("Underweight - increase to target allocation")
                        .priority(determinePriority(allocation.getDrift()))
                        .build());
                }
            }
        }
        
        return trades;
    }
    
    /**
     * Optimize trades (combine, minimize, reorder)
     */
    private List<RecommendedTrade> optimizeTrades(
            List<RecommendedTrade> trades,
            PortfolioState state,
            RecommendationOptions options) {
        
        // Combine trades for same ticker
        trades = combineSameTicker(trades);
        
        // Remove very small trades
        trades = removeSmallTrades(trades, options.getMinTradeValue());
        
        // Sort by priority
        trades.sort((t1, t2) -> t2.getPriority().compareTo(t1.getPriority()));
        
        return trades;
    }
    
    /**
     * Calculate expected impact of recommendations
     */
    private ExpectedImpact calculateExpectedImpact(
            PortfolioState currentState,
            List<RecommendedTrade> trades,
            List<Holding> holdings) {
        
        // Simulate applying trades
        PortfolioState afterState = simulateTradeApplication(currentState, trades, holdings);
        
        return ExpectedImpact.builder()
            .driftBefore(currentState.getOverallDrift())
            .driftAfter(afterState.getOverallDrift())
            .driftReduction(currentState.getOverallDrift().subtract(afterState.getOverallDrift()))
            .riskScoreBefore(currentState.getRiskMetrics().getRiskScore())
            .riskScoreAfter(afterState.getRiskMetrics().getRiskScore())
            .sharpeRatioBefore(currentState.getRiskMetrics().getSharpeRatio())
            .sharpeRatioAfter(afterState.getRiskMetrics().getSharpeRatio())
            .volatilityBefore(currentState.getRiskMetrics().getVolatility())
            .volatilityAfter(afterState.getRiskMetrics().getVolatility())
            .build();
    }
    
    /**
     * Validate recommendations and generate warnings
     */
    private List<String> validateRecommendations(
            List<RecommendedTrade> trades,
            PortfolioState state,
            RecommendationOptions options) {
        
        List<String> warnings = new ArrayList<>();
        
        // Check if too many trades
        if (trades.size() > 20) {
            warnings.add("Large number of trades (" + trades.size() + ") may incur significant costs");
        }
        
        // Check market conditions
        if (state.getRiskMetrics().getVixLevel() != null && 
            state.getRiskMetrics().getVixLevel().compareTo(BigDecimal.valueOf(30)) > 0) {
            warnings.add("High market volatility (VIX > 30) - consider delaying execution");
        }
        
        // Check for wash sale risk
        // ... additional validation logic
        
        return warnings;
    }
    
    // ========================================================================
    // HELPER METHODS
    // ========================================================================
    
    private Map<String, AllocationInfo> calculateAllocations(
            List<Holding> holdings,
            BigDecimal totalValue,
            List<TargetAllocation> targets) {
        
        Map<String, AllocationInfo> allocations = new HashMap<>();
        
        // Group by asset class
        Map<String, BigDecimal> valueByClass = holdings.stream()
            .collect(Collectors.groupingBy(
                Holding::getAssetClass,
                Collectors.reducing(
                    BigDecimal.ZERO,
                    h -> h.getCurrentPrice().multiply(BigDecimal.valueOf(h.getQuantity())),
                    BigDecimal::add
                )
            ));
        
        // Build allocation info
        for (TargetAllocation target : targets) {
            BigDecimal currentValue = valueByClass.getOrDefault(
                target.getAssetClass(), BigDecimal.ZERO);
            BigDecimal currentPct = currentValue.divide(totalValue, 4, RoundingMode.HALF_UP)
                .multiply(BigDecimal.valueOf(100));
            BigDecimal drift = currentPct.subtract(target.getTargetPercentage());
            
            allocations.put(target.getAssetClass(), AllocationInfo.builder()
                .assetClass(target.getAssetClass())
                .currentValue(currentValue)
                .currentPct(currentPct)
                .targetPct(target.getTargetPercentage())
                .drift(drift)
                .driftTolerance(target.getDriftTolerance())
                .build());
        }
        
        return allocations;
    }
    
    private BigDecimal calculateGain(Holding holding) {
        BigDecimal currentValue = holding.getCurrentPrice()
            .multiply(BigDecimal.valueOf(holding.getQuantity()));
        return currentValue.subtract(holding.getCostBasis());
    }
    
    private TradePriority determinePriority(BigDecimal drift) {
        BigDecimal absDrift = drift.abs();
        if (absDrift.compareTo(BigDecimal.valueOf(10)) >= 0) {
            return TradePriority.CRITICAL;
        } else if (absDrift.compareTo(BigDecimal.valueOf(7)) >= 0) {
            return TradePriority.HIGH;
        } else if (absDrift.compareTo(BigDecimal.valueOf(4)) >= 0) {
            return TradePriority.MEDIUM;
        } else {
            return TradePriority.LOW;
        }
    }
    
    private String suggestRepresentativeETF(String assetClass) {
        return switch(assetClass.toUpperCase()) {
            case "US EQUITY" -> "VTI";
            case "INTERNATIONAL EQUITY" -> "VXUS";
            case "BONDS" -> "BND";
            case "REITS" -> "VNQ";
            case "COMMODITIES" -> "GLD";
            default -> "SPY";
        };
    }
    
    private List<RecommendedTrade> combineSameTicker(List<RecommendedTrade> trades) {
        Map<String, RecommendedTrade> combined = new LinkedHashMap<>();
        
        for (RecommendedTrade trade : trades) {
            String key = trade.getTicker() + "-" + trade.getAction();
            if (combined.containsKey(key)) {
                RecommendedTrade existing = combined.get(key);
                existing.setRecommendedQuantity(
                    existing.getRecommendedQuantity() + trade.getRecommendedQuantity());
                existing.setEstimatedValue(
                    existing.getEstimatedValue().add(trade.getEstimatedValue()));
            } else {
                combined.put(key, trade);
            }
        }
        
        return new ArrayList<>(combined.values());
    }
    
    private List<RecommendedTrade> removeSmallTrades(
            List<RecommendedTrade> trades, 
            BigDecimal minValue) {
        return trades.stream()
            .filter(t -> t.getEstimatedValue().compareTo(minValue) >= 0)
            .collect(Collectors.toList());
    }
    
    private PortfolioState simulateTradeApplication(
            PortfolioState currentState,
            List<RecommendedTrade> trades,
            List<Holding> holdings) {
        // Create copies and apply trades
        // Calculate new state
        // This is a simplified version
        return currentState; // Would return new state after trades
    }
    
    private List<RecommendedTrade> generateTradesForAllocation(
            List<Holding> holdings,
            OptimalAllocation optimal,
            BigDecimal totalValue) {
        // Generate trades to move to optimal allocation
        return new ArrayList<>();
    }
}

// ============================================================================
// SUPPORTING ENUMS
// ============================================================================

enum RecommendationStrategy {
    RECOMMENDED,
    ML_OPTIMIZED,
    TAX_EFFICIENT,
    COST_MINIMIZED
}

enum TradeAction {
    BUY,
    SELL,
    HOLD
}

enum TradePriority {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}
