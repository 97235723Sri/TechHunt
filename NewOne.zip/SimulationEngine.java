package com.portfolio.rebalancer.engine.simulation;

import com.portfolio.rebalancer.model.*;
import com.portfolio.rebalancer.dto.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Simulation Engine
 * 
 * Core engine for portfolio rebalancing simulations and what-if analysis.
 * 
 * Features:
 * - Before/after comparison
 * - Risk metrics projection
 * - Cost analysis
 * - Backtesting
 * - Scenario comparison
 * - Monte Carlo simulation
 * - Expected return calculation
 * 
 * The engine creates isolated simulations without affecting actual portfolio data.
 */
@Slf4j
@Component
public class SimulationEngine {

    private final PortfolioCloner portfolioCloner;
    private final RiskCalculator riskCalculator;
    private final PerformanceProjector performanceProjector;
    private final CostEstimator costEstimator;
    private final BacktestRunner backtestRunner;
    private final MonteCarloSimulator monteCarloSimulator;
    
    public SimulationEngine(
            PortfolioCloner portfolioCloner,
            RiskCalculator riskCalculator,
            PerformanceProjector performanceProjector,
            CostEstimator costEstimator,
            BacktestRunner backtestRunner,
            MonteCarloSimulator monteCarloSimulator) {
        this.portfolioCloner = portfolioCloner;
        this.riskCalculator = riskCalculator;
        this.performanceProjector = performanceProjector;
        this.costEstimator = costEstimator;
        this.backtestRunner = backtestRunner;
        this.monteCarloSimulator = monteCarloSimulator;
    }
    
    /**
     * Run a comprehensive portfolio rebalancing simulation
     */
    public SimulationResult runSimulation(SimulationRequest request) {
        log.info("Running simulation: {}", request.getScenarioName());
        
        // Step 1: Create portfolio snapshot (before state)
        PortfolioSnapshot beforeSnapshot = createSnapshot(
            request.getPortfolio(),
            request.getHoldings(),
            request.getTargets()
        );
        
        // Step 2: Clone portfolio and apply trades
        Portfolio simulatedPortfolio = portfolioCloner.clone(request.getPortfolio());
        List<Holding> simulatedHoldings = applyTradesToClone(
            request.getHoldings(),
            request.getTrades()
        );
        
        // Step 3: Apply custom allocations if specified
        if (request.getCustomAllocations() != null && !request.getCustomAllocations().isEmpty()) {
            simulatedHoldings = applyCustomAllocations(
                simulatedHoldings,
                request.getCustomAllocations(),
                beforeSnapshot.getTotalValue()
            );
        }
        
        // Step 4: Create after snapshot
        PortfolioSnapshot afterSnapshot = createSnapshot(
            simulatedPortfolio,
            simulatedHoldings,
            request.getTargets()
        );
        
        // Step 5: Calculate detailed impact
        ImpactAnalysis impact = calculateImpact(beforeSnapshot, afterSnapshot);
        
        // Step 6: Estimate costs
        CostEstimate costs = costEstimator.estimateCosts(
            request.getTrades(),
            request.getOptions()
        );
        
        // Step 7: Run backtest if requested
        BacktestResult backtest = null;
        if (request.isIncludeBacktest()) {
            backtest = backtestRunner.runBacktest(
                simulatedHoldings,
                request.getBacktestPeriodMonths(),
                request.getOptions()
            );
        }
        
        // Step 8: Run Monte Carlo if requested
        MonteCarloResult monteCarlo = null;
        if (request.isIncludeMonteCarlo()) {
            monteCarlo = monteCarloSimulator.runSimulation(
                simulatedHoldings,
                request.getMonteCarloIterations(),
                request.getProjectionYears()
            );
        }
        
        // Step 9: Calculate expected returns
        ExpectedReturns returns = performanceProjector.projectReturns(
            afterSnapshot,
            request.getProjectionPeriod()
        );
        
        // Step 10: Generate insights
        List<SimulationInsight> insights = generateInsights(
            beforeSnapshot,
            afterSnapshot,
            impact,
            costs,
            backtest
        );
        
        // Build comprehensive result
        return SimulationResult.builder()
            .simulationId(UUID.randomUUID().toString())
            .scenarioName(request.getScenarioName())
            .beforeSnapshot(beforeSnapshot)
            .afterSnapshot(afterSnapshot)
            .impact(impact)
            .costs(costs)
            .backtest(backtest)
            .monteCarlo(monteCarlo)
            .expectedReturns(returns)
            .insights(insights)
            .timestamp(LocalDate.now())
            .build();
    }
    
    /**
     * Compare multiple scenarios side-by-side
     */
    public ComparisonResult compareScenarios(List<SimulationRequest> scenarios) {
        log.info("Comparing {} scenarios", scenarios.size());
        
        List<SimulationResult> results = new ArrayList<>();
        
        for (SimulationRequest request : scenarios) {
            SimulationResult result = runSimulation(request);
            results.add(result);
        }
        
        // Analyze comparison
        ScenarioComparison comparison = analyzeScenarios(results);
        
        // Determine best scenario
        BestScenario best = determineBestScenario(results, comparison);
        
        return ComparisonResult.builder()
            .scenarios(results)
            .comparison(comparison)
            .bestScenario(best)
            .build();
    }
    
    /**
     * Quick preview of impact without full simulation
     */
    public ImpactPreview previewImpact(
            Portfolio portfolio,
            List<Holding> holdings,
            List<Trade> trades) {
        
        log.info("Generating impact preview");
        
        // Calculate current drift
        BigDecimal currentDrift = calculateCurrentDrift(holdings, portfolio);
        
        // Apply trades in memory
        List<Holding> afterHoldings = applyTradesTemporary(holdings, trades);
        
        // Calculate new drift
        BigDecimal afterDrift = calculateCurrentDrift(afterHoldings, portfolio);
        
        // Estimate costs
        BigDecimal estimatedCost = costEstimator.quickEstimate(trades);
        
        // Calculate risk change (simplified)
        RiskMetrics beforeRisk = riskCalculator.calculateQuick(holdings);
        RiskMetrics afterRisk = riskCalculator.calculateQuick(afterHoldings);
        
        return ImpactPreview.builder()
            .driftReduction(currentDrift.subtract(afterDrift))
            .currentDrift(currentDrift)
            .projectedDrift(afterDrift)
            .estimatedCost(estimatedCost)
            .tradesRequired(trades.size())
            .riskScoreChange(afterRisk.getRiskScore() - beforeRisk.getRiskScore())
            .sharpeChange(afterRisk.getSharpeRatio().subtract(beforeRisk.getSharpeRatio()))
            .build();
    }
    
    /**
     * Optimize allocation using ML
     */
    public OptimizationResult optimizeAllocation(
            Portfolio portfolio,
            List<Holding> holdings,
            OptimizationObjective objective,
            OptimizationConstraints constraints) {
        
        log.info("Optimizing allocation for objective: {}", objective);
        
        // Run optimization algorithm
        OptimalAllocation optimal = runOptimization(
            holdings,
            objective,
            constraints
        );
        
        // Generate trades to achieve optimal allocation
        List<Trade> trades = generateOptimalTrades(
            holdings,
            optimal,
            portfolio.getTotalValue()
        );
        
        // Run simulation with optimal trades
        SimulationRequest request = SimulationRequest.builder()
            .scenarioName("ML-Optimized: " + objective)
            .portfolio(portfolio)
            .holdings(holdings)
            .trades(trades)
            .customAllocations(optimal.getAllocations())
            .includeBacktest(true)
            .backtestPeriodMonths(12)
            .build();
        
        SimulationResult simulation = runSimulation(request);
        
        return OptimizationResult.builder()
            .optimalAllocation(optimal)
            .recommendedTrades(trades)
            .simulation(simulation)
            .confidenceScore(optimal.getConfidence())
            .build();
    }
    
    // ========================================================================
    // SNAPSHOT CREATION
    // ========================================================================
    
    /**
     * Create comprehensive portfolio snapshot
     */
    private PortfolioSnapshot createSnapshot(
            Portfolio portfolio,
            List<Holding> holdings,
            List<TargetAllocation> targets) {
        
        // Calculate total value
        BigDecimal totalValue = holdings.stream()
            .map(h -> h.getCurrentPrice().multiply(BigDecimal.valueOf(h.getQuantity())))
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        // Calculate allocations
        Map<String, AllocationSnapshot> allocations = calculateAllocationSnapshots(
            holdings, totalValue, targets);
        
        // Calculate drift
        BigDecimal overallDrift = calculateDriftFromSnapshots(allocations);
        
        // Calculate risk metrics
        RiskMetrics risk = riskCalculator.calculateComprehensive(holdings, portfolio);
        
        // Calculate diversification
        DiversificationMetrics diversification = calculateDiversification(holdings);
        
        // Build snapshot
        return PortfolioSnapshot.builder()
            .totalValue(totalValue)
            .cashBalance(portfolio.getCashBalance())
            .investedValue(totalValue.subtract(portfolio.getCashBalance()))
            .holdingsCount(holdings.size())
            .allocations(allocations)
            .overallDrift(overallDrift)
            .riskMetrics(risk)
            .diversification(diversification)
            .timestamp(LocalDate.now())
            .build();
    }
    
    /**
     * Calculate allocation snapshots for each asset class
     */
    private Map<String, AllocationSnapshot> calculateAllocationSnapshots(
            List<Holding> holdings,
            BigDecimal totalValue,
            List<TargetAllocation> targets) {
        
        Map<String, AllocationSnapshot> snapshots = new LinkedHashMap<>();
        
        // Group holdings by asset class
        Map<String, List<Holding>> byClass = holdings.stream()
            .collect(Collectors.groupingBy(Holding::getAssetClass));
        
        // Calculate for each target allocation
        for (TargetAllocation target : targets) {
            List<Holding> classHoldings = byClass.getOrDefault(
                target.getAssetClass(), Collections.emptyList());
            
            BigDecimal currentValue = classHoldings.stream()
                .map(h -> h.getCurrentPrice().multiply(BigDecimal.valueOf(h.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
            
            BigDecimal currentPct = totalValue.compareTo(BigDecimal.ZERO) == 0 
                ? BigDecimal.ZERO
                : currentValue.divide(totalValue, 4, RoundingMode.HALF_UP)
                    .multiply(BigDecimal.valueOf(100));
            
            BigDecimal targetPct = target.getTargetPercentage();
            BigDecimal drift = currentPct.subtract(targetPct);
            
            snapshots.put(target.getAssetClass(), AllocationSnapshot.builder()
                .assetClass(target.getAssetClass())
                .currentValue(currentValue)
                .currentPercentage(currentPct)
                .targetPercentage(targetPct)
                .drift(drift)
                .driftTolerance(target.getDriftTolerance())
                .holdingsCount(classHoldings.size())
                .build());
        }
        
        return snapshots;
    }
    
    // ========================================================================
    // TRADE APPLICATION
    // ========================================================================
    
    /**
     * Apply trades to cloned holdings (non-destructive)
     */
    private List<Holding> applyTradesToClone(
            List<Holding> originalHoldings,
            List<Trade> trades) {
        
        // Create mutable map of holdings
        Map<String, Holding> holdingMap = originalHoldings.stream()
            .collect(Collectors.toMap(
                Holding::getTicker,
                h -> h.deepCopy(),
                (h1, h2) -> h1,
                LinkedHashMap::new
            ));
        
        // Apply each trade
        for (Trade trade : trades) {
            Holding holding = holdingMap.get(trade.getTicker());
            
            if (trade.getAction() == TradeAction.BUY) {
                if (holding != null) {
                    // Add to existing position
                    int newQuantity = holding.getQuantity() + trade.getQuantity();
                    BigDecimal newCostBasis = calculateNewCostBasis(
                        holding, trade.getQuantity(), trade.getPrice());
                    
                    holding.setQuantity(newQuantity);
                    holding.setCostBasis(newCostBasis);
                } else {
                    // Create new holding
                    holding = Holding.builder()
                        .ticker(trade.getTicker())
                        .companyName(trade.getCompanyName())
                        .assetClass(trade.getAssetClass())
                        .quantity(trade.getQuantity())
                        .currentPrice(trade.getPrice())
                        .averageCost(trade.getPrice())
                        .costBasis(trade.getPrice().multiply(
                            BigDecimal.valueOf(trade.getQuantity())))
                        .build();
                    
                    holdingMap.put(trade.getTicker(), holding);
                }
            } else if (trade.getAction() == TradeAction.SELL) {
                if (holding != null) {
                    int newQuantity = Math.max(0, holding.getQuantity() - trade.getQuantity());
                    
                    if (newQuantity == 0) {
                        holdingMap.remove(trade.getTicker());
                    } else {
                        holding.setQuantity(newQuantity);
                        // Cost basis proportionally reduced
                        BigDecimal proportion = BigDecimal.valueOf(newQuantity)
                            .divide(BigDecimal.valueOf(holding.getQuantity()), 4, RoundingMode.HALF_UP);
                        holding.setCostBasis(holding.getCostBasis().multiply(proportion));
                    }
                }
            }
        }
        
        return new ArrayList<>(holdingMap.values());
    }
    
    /**
     * Apply custom allocations
     */
    private List<Holding> applyCustomAllocations(
            List<Holding> holdings,
            Map<String, Double> customAllocations,
            BigDecimal totalValue) {
        
        log.info("Applying custom allocations: {}", customAllocations);
        
        // This is a complex operation that redistributes holdings
        // to match custom allocation percentages
        
        // Group by asset class
        Map<String, List<Holding>> byClass = holdings.stream()
            .collect(Collectors.groupingBy(Holding::getAssetClass));
        
        List<Holding> adjusted = new ArrayList<>();
        
        for (Map.Entry<String, Double> entry : customAllocations.entrySet()) {
            String assetClass = entry.getKey();
            Double targetPct = entry.getValue();
            
            BigDecimal targetValue = totalValue
                .multiply(BigDecimal.valueOf(targetPct))
                .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
            
            List<Holding> classHoldings = byClass.getOrDefault(assetClass, new ArrayList<>());
            
            if (classHoldings.isEmpty()) {
                // Need to add holdings for this class
                // This is simplified - real implementation would suggest specific securities
                continue;
            }
            
            // Distribute target value proportionally across holdings
            BigDecimal currentClassValue = classHoldings.stream()
                .map(h -> h.getCurrentPrice().multiply(BigDecimal.valueOf(h.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
            
            for (Holding holding : classHoldings) {
                BigDecimal holdingValue = holding.getCurrentPrice()
                    .multiply(BigDecimal.valueOf(holding.getQuantity()));
                BigDecimal proportion = currentClassValue.compareTo(BigDecimal.ZERO) == 0
                    ? BigDecimal.ZERO
                    : holdingValue.divide(currentClassValue, 4, RoundingMode.HALF_UP);
                
                BigDecimal newValue = targetValue.multiply(proportion);
                int newQuantity = newValue.divide(holding.getCurrentPrice(), 0, RoundingMode.DOWN).intValue();
                
                Holding adjusted Holding = holding.deepCopy();
                adjustedHolding.setQuantity(newQuantity);
                adjusted.add(adjustedHolding);
            }
        }
        
        return adjusted;
    }
    
    // ========================================================================
    // IMPACT CALCULATION
    // ========================================================================
    
    /**
     * Calculate comprehensive impact of simulation
     */
    private ImpactAnalysis calculateImpact(
            PortfolioSnapshot before,
            PortfolioSnapshot after) {
        
        RiskMetrics beforeRisk = before.getRiskMetrics();
        RiskMetrics afterRisk = after.getRiskMetrics();
        
        return ImpactAnalysis.builder()
            // Drift
            .driftBefore(before.getOverallDrift())
            .driftAfter(after.getOverallDrift())
            .driftReduction(before.getOverallDrift().subtract(after.getOverallDrift()))
            .driftReductionPct(calculatePercentageChange(
                before.getOverallDrift(), after.getOverallDrift()))
            
            // Risk Score
            .riskScoreBefore(beforeRisk.getRiskScore())
            .riskScoreAfter(afterRisk.getRiskScore())
            .riskScoreChange(afterRisk.getRiskScore() - beforeRisk.getRiskScore())
            
            // Sharpe Ratio
            .sharpeRatioBefore(beforeRisk.getSharpeRatio())
            .sharpeRatioAfter(afterRisk.getSharpeRatio())
            .sharpeRatioChange(afterRisk.getSharpeRatio().subtract(beforeRisk.getSharpeRatio()))
            
            // Volatility
            .volatilityBefore(beforeRisk.getVolatility())
            .volatilityAfter(afterRisk.getVolatility())
            .volatilityChange(afterRisk.getVolatility().subtract(beforeRisk.getVolatility()))
            
            // VaR
            .varBefore(beforeRisk.getVar95())
            .varAfter(afterRisk.getVar95())
            .varChange(afterRisk.getVar95().subtract(beforeRisk.getVar95()))
            
            // Beta
            .betaBefore(beforeRisk.getBeta())
            .betaAfter(afterRisk.getBeta())
            .betaChange(afterRisk.getBeta().subtract(beforeRisk.getBeta()))
            
            // Overall assessment
            .overallImprovement(assessOverallImprovement(beforeRisk, afterRisk))
            .riskReductionPct(calculateRiskReduction(beforeRisk, afterRisk))
            
            .build();
    }
    
    /**
     * Assess overall improvement
     */
    private String assessOverallImprovement(RiskMetrics before, RiskMetrics after) {
        int improvements = 0;
        int total = 0;
        
        // Check drift (lower is better)
        // Check risk score (higher is better)
        if (after.getRiskScore() > before.getRiskScore()) improvements++;
        total++;
        
        // Check Sharpe (higher is better)
        if (after.getSharpeRatio().compareTo(before.getSharpeRatio()) > 0) improvements++;
        total++;
        
        // Check volatility (lower is better)
        if (after.getVolatility().compareTo(before.getVolatility()) < 0) improvements++;
        total++;
        
        double improvementRate = (double) improvements / total;
        
        if (improvementRate >= 0.8) return "EXCELLENT";
        if (improvementRate >= 0.6) return "GOOD";
        if (improvementRate >= 0.4) return "MODERATE";
        return "MINIMAL";
    }
    
    // ========================================================================
    // INSIGHTS GENERATION
    // ========================================================================
    
    /**
     * Generate simulation insights
     */
    private List<SimulationInsight> generateInsights(
            PortfolioSnapshot before,
            PortfolioSnapshot after,
            ImpactAnalysis impact,
            CostEstimate costs,
            BacktestResult backtest) {
        
        List<SimulationInsight> insights = new ArrayList<>();
        
        // Drift insight
        if (impact.getDriftReduction().compareTo(BigDecimal.ZERO) > 0) {
            insights.add(SimulationInsight.builder()
                .type(InsightType.DRIFT_IMPROVEMENT)
                .severity(InsightSeverity.POSITIVE)
                .message(String.format("Portfolio drift reduced by %.2f%% (from %.2f%% to %.2f%%)",
                    impact.getDriftReduction(),
                    impact.getDriftBefore(),
                    impact.getDriftAfter()))
                .impact("HIGH")
                .build());
        }
        
        // Risk insight
        if (impact.getRiskScoreChange() > 0) {
            insights.add(SimulationInsight.builder()
                .type(InsightType.RISK_IMPROVEMENT)
                .severity(InsightSeverity.POSITIVE)
                .message(String.format("Risk score improved by %d points (from %d to %d)",
                    impact.getRiskScoreChange(),
                    impact.getRiskScoreBefore(),
                    impact.getRiskScoreAfter()))
                .impact("HIGH")
                .build());
        }
        
        // Cost insight
        BigDecimal costPct = costs.getTotalCost()
            .divide(before.getTotalValue(), 4, RoundingMode.HALF_UP)
            .multiply(BigDecimal.valueOf(100));
        
        if (costPct.compareTo(BigDecimal.valueOf(0.5)) > 0) {
            insights.add(SimulationInsight.builder()
                .type(InsightType.COST_WARNING)
                .severity(InsightSeverity.WARNING)
                .message(String.format("Transaction costs are %.2f%% of portfolio value",
                    costPct))
                .impact("MEDIUM")
                .recommendation("Consider reducing number of trades or using VWAP orders")
                .build());
        }
        
        // Backtest insight
        if (backtest != null && backtest.getExpectedReturn().compareTo(BigDecimal.ZERO) > 0) {
            insights.add(SimulationInsight.builder()
                .type(InsightType.PERFORMANCE_PROJECTION)
                .severity(InsightSeverity.INFO)
                .message(String.format("Backtest shows expected return of %.2f%% over %d months",
                    backtest.getExpectedReturn(),
                    backtest.getPeriodMonths()))
                .impact("MEDIUM")
                .build());
        }
        
        return insights;
    }
    
    // ========================================================================
    // HELPER METHODS
    // ========================================================================
    
    private BigDecimal calculateCurrentDrift(List<Holding> holdings, Portfolio portfolio) {
        // Simplified drift calculation
        return BigDecimal.valueOf(5.0); // Placeholder
    }
    
    private List<Holding> applyTradesTemporary(List<Holding> holdings, List<Trade> trades) {
        return applyTradesToClone(holdings, trades);
    }
    
    private BigDecimal calculateNewCostBasis(Holding holding, int newQuantity, BigDecimal newPrice) {
        BigDecimal existingCost = holding.getCostBasis();
        BigDecimal additionalCost = newPrice.multiply(BigDecimal.valueOf(newQuantity));
        return existingCost.add(additionalCost);
    }
    
    private BigDecimal calculateDriftFromSnapshots(Map<String, AllocationSnapshot> snapshots) {
        return snapshots.values().stream()
            .map(AllocationSnapshot::getDrift)
            .map(BigDecimal::abs)
            .reduce(BigDecimal.ZERO, BigDecimal::add)
            .divide(BigDecimal.valueOf(snapshots.size()), 2, RoundingMode.HALF_UP);
    }
    
    private DiversificationMetrics calculateDiversification(List<Holding> holdings) {
        // Calculate Herfindahl index and other diversification metrics
        return DiversificationMetrics.builder()
            .holdingsCount(holdings.size())
            .herfindahlIndex(BigDecimal.valueOf(0.15))
            .effectiveN(BigDecimal.valueOf(6.7))
            .build();
    }
    
    private BigDecimal calculatePercentageChange(BigDecimal before, BigDecimal after) {
        if (before.compareTo(BigDecimal.ZERO) == 0) return BigDecimal.ZERO;
        return after.subtract(before)
            .divide(before, 4, RoundingMode.HALF_UP)
            .multiply(BigDecimal.valueOf(100));
    }
    
    private BigDecimal calculateRiskReduction(RiskMetrics before, RiskMetrics after) {
        // Composite risk reduction calculation
        return BigDecimal.valueOf(15.0); // Placeholder
    }
    
    private ScenarioComparison analyzeScenarios(List<SimulationResult> results) {
        // Detailed comparison logic
        return ScenarioComparison.builder().build();
    }
    
    private BestScenario determineBestScenario(
            List<SimulationResult> results, 
            ScenarioComparison comparison) {
        // Logic to determine best scenario
        return BestScenario.builder()
            .scenarioName(results.get(0).getScenarioName())
            .reason("Best risk-adjusted return")
            .build();
    }
    
    private OptimalAllocation runOptimization(
            List<Holding> holdings,
            OptimizationObjective objective,
            OptimizationConstraints constraints) {
        // ML optimization logic
        return OptimalAllocation.builder().build();
    }
    
    private List<Trade> generateOptimalTrades(
            List<Holding> holdings,
            OptimalAllocation optimal,
            BigDecimal totalValue) {
        // Generate trades to reach optimal allocation
        return new ArrayList<>();
    }
}

// ============================================================================
// SUPPORTING ENUMS
// ============================================================================

enum OptimizationObjective {
    MAXIMIZE_SHARPE,
    MINIMIZE_RISK,
    MAXIMIZE_RETURN,
    BALANCE_RISK_RETURN
}

enum InsightType {
    DRIFT_IMPROVEMENT,
    RISK_IMPROVEMENT,
    COST_WARNING,
    PERFORMANCE_PROJECTION,
    DIVERSIFICATION,
    TAX_IMPACT
}

enum InsightSeverity {
    POSITIVE,
    INFO,
    WARNING,
    CRITICAL
}
